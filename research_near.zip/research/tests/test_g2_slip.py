"""g2_slip 합성 검증: 호가단위 경계, 수기 대조, UNI0=Gate 2 기준, 균일 슬리피지 선형 항등, 브루트포스, break-even 영점, 모듈 분리, 입력 불변."""
import ast, copy, os, tempfile
import numpy as np
import pandas as pd
from research import config as C
from research import gate2 as G
from research import g2_slip as S
from research.tests.test_gate2 import synth_prep

ROOT = os.path.dirname(os.path.dirname(__file__))


def test_tick_bands():
    p = np.array([1, 999, 1000, 4999, 5000, 9999, 10000, 49999, 50000, 120000.0])
    np.testing.assert_array_equal(S.tick_size(p), [1, 1, 5, 5, 10, 10, 50, 50, 100, 100])


def test_hand_adjust_and_models():
    T1 = np.array([[0.10, np.nan], [-0.05, 0.02]]); s = np.array([[0.001, 0.002], [0.0, 0.005]])
    exp = np.array([[1.10 * 0.999 / 1.001 - 1, np.nan], [-0.05, 1.02 * 0.995 / 1.005 - 1]])
    np.testing.assert_allclose(S.adjust(T1, s), exp, atol=1e-15)
    px = np.array([[500.0, 2000.0], [8000.0, 30000.0]])                    # 틱 1,5,10,50
    np.testing.assert_allclose(S.slip_matrix("TICK1", px, None), np.array([[1 / 1000, 5 / 4000], [10 / 16000, 50 / 60000]]), atol=1e-15)
    np.testing.assert_allclose(S.slip_matrix("TICK2", px, None), 2 * S.slip_matrix("TICK1", px, None), atol=1e-18)
    TL = np.array([[1, 2], [3, 0]], np.int8)
    np.testing.assert_allclose(S.slip_matrix("TIER", px, TL), np.array([[20, 10], [5, 20]]) * 1e-4, atol=1e-18)
    np.testing.assert_allclose(S.slip_matrix("UNI15", px, None), 15e-4)


def test_uni0_equals_gate2_and_linear_identity():
    prep = synth_prep(T=900, M=70, seed=13)
    for k, h in S.SLIP_CANDS:
        P = prep["h"][h]; pool, q5, _ = G.select_masks(P["F"][k], C.FEATURE_DIRECTION[k])
        E, mq, mp, _ = G.excess_days(q5, pool, P["T1"], 0); ok = np.isfinite(E)
        main, year = S.eval_one(prep, k, h)
        u0 = main[main["모델"] == "UNI0"].iloc[0]
        assert abs(u0["E_both"] - E[ok].mean()) < 1e-13 and abs(u0["E_Q5only"] - E[ok].mean()) < 1e-13
        assert abs(u0["Q5절대순수익"] - (mq[ok].mean() - C.G2_COST_RT)) < 1e-13
        for b in S.UNI_BP:                                                      # 균일 s: 양쪽 부담 시 E_both = c*E0 (c=(1-s)/(1+s)), 정확 항등
            s = b * 1e-4; c = (1 - s) / (1 + s); r = main[main["모델"] == f"UNI{b}"].iloc[0]
            assert abs(r["E_both"] - c * E[ok].mean()) < 1e-13, (b, r["E_both"], c * E[ok].mean())
            assert abs(r["Q5절대순수익"] - (c * (1 + mq[ok].mean()) - 1 - C.G2_COST_RT)) < 1e-13
        v = main[main["모델"].str.startswith("UNI")]["Q5절대순수익"].values
        assert all(v[i] >= v[i + 1] - 1e-15 for i in range(len(v) - 1))         # bp↑ → 순수익↓
        for m_, g in year.groupby("모델"):                                       # 연도 가중평균 = 전체
            e = main[main["모델"] == m_].iloc[0]
            assert abs((g["E_both"] * g["평가일"]).sum() / g["평가일"].sum() - e["E_both"]) < 1e-12
            assert abs((g["Q5절대순수익"] * g["평가일"]).sum() / g["평가일"].sum() - e["Q5절대순수익"]) < 1e-12


def test_bruteforce_tick_and_tier():
    prep = synth_prep(T=500, M=50, seed=21); k, h = "LIQ", 10
    P = prep["h"][h]; T1 = P["T1"]; pool, q5, _ = G.select_masks(P["F"][k], +1)
    px = prep["Clf"][P["tpos"]]; TL = G.tercile_pool(pool, P["DV"]); fin = np.isfinite(T1)
    main, _ = S.eval_one(prep, k, h, models=["TICK1", "TICK2", "TIER"])
    for m in ("TICK1", "TICK2", "TIER"):
        s = np.zeros(px.shape)
        for t in range(px.shape[0]):
            for j in range(px.shape[1]):
                if m.startswith("TICK"):
                    p = px[t, j]; tk = 1 if p < 1000 else 5 if p < 5000 else 10 if p < 10000 else 50 if p < 50000 else 100
                    s[t, j] = float(m[4:]) * tk / (2 * p)
                else:
                    s[t, j] = {1: 20, 2: 10, 3: 5, 0: 20}[int(TL[t, j])] * 1e-4
        eb, eq, ab = [], [], []
        for t in range(T1.shape[0]):
            qi = np.where(q5[t] & fin[t])[0]; pi = np.where(pool[t] & fin[t])[0]
            if len(qi) and len(pi):
                ya = lambda i: (1 + T1[t, i]) * (1 - s[t, i]) / (1 + s[t, i]) - 1
                qa = np.mean([ya(i) for i in qi]); pa = np.mean([ya(i) for i in pi]); pg = T1[t, pi].mean()
                eb.append(qa - pa); eq.append(qa - pg); ab.append(qa)
        r = main[main["모델"] == m].iloc[0]
        assert abs(r["E_both"] - np.mean(eb)) < 1e-12 and abs(r["E_Q5only"] - np.mean(eq)) < 1e-12
        assert abs(r["Q5절대순수익"] - (np.mean(ab) - C.G2_COST_RT)) < 1e-12
    assert main[main["모델"] == "TICK2"].iloc[0]["Q5절대순수익"] < main[main["모델"] == "TICK1"].iloc[0]["Q5절대순수익"]


def test_break_even_root():
    prep = synth_prep(T=800, M=70, seed=31); k, h = "LIQ", 5
    be = S.break_even(prep, k, h)
    P = prep["h"][h]; pool, q5, _ = G.select_masks(P["F"][k], +1); T1 = P["T1"]
    E0, mq0, mp0, _ = G.excess_days(q5, pool, T1, 0); ok = np.isfinite(E0)
    s = be["UNI_절대0_편도bp"] * 1e-4
    if np.isfinite(s) and s > 0:
        mq = G.excess_days(q5, pool, S.adjust(T1, np.full(T1.shape, s)), 0)[1][ok].mean()
        assert abs(mq - C.G2_COST_RT) < 1e-9
    s2 = be["UNI_Q5만부담_초과0_편도bp"] * 1e-4
    if np.isfinite(s2) and s2 > 0:
        mq = G.excess_days(q5, pool, S.adjust(T1, np.full(T1.shape, s2)), 0)[1]
        assert abs((mq - mp0)[ok].mean()) < 1e-9
    px = prep["Clf"][P["tpos"]]; unit = S.slip_matrix("TICK1", px, None)
    x = be["TICK_절대0_배수k"]
    if np.isfinite(x) and x > 0:
        mq = G.excess_days(q5, pool, S.adjust(T1, x * unit), 0)[1][ok].mean()
        assert abs(mq - C.G2_COST_RT) < 1e-9
    # 기준에서 이미 음인 경우 nan
    assert np.isnan(S._solve(lambda x: -1.0 - x, 1.0)) and np.isinf(S._solve(lambda x: 1.0, 1.0))


def test_inputs_not_mutated_report_and_check():
    prep = synth_prep(T=500, M=70, seed=41)
    b1 = prep["h"][5]["T1"].copy(); b2 = copy.deepcopy(prep["h"][5]["F"]["LIQ"]); b3 = prep["Clf"].copy()
    res = S.run_slip(prep, cands=[("LIQ", 5), ("LIQ", 10)], log=lambda *_: None)
    assert np.array_equal(b1, prep["h"][5]["T1"], equal_nan=True) and np.array_equal(b2, prep["h"][5]["F"]["LIQ"], equal_nan=True)
    assert np.array_equal(b3, prep["Clf"], equal_nan=True)
    assert len(res["main"]) == 2 * len(S.MODELS) and len(res["be"]) == 2
    with tempfile.TemporaryDirectory() as d:
        u0 = res["main"][res["main"]["모델"] == "UNI0"]
        rows = [{"feature": r.feature, "h": r.h, "평균E_gross(트랜치,h일)": r.E_both, "Q5절대순수익(트랜치,h일)": r.Q5절대순수익} for r in u0.itertuples()]
        pd.DataFrame(rows).to_csv(os.path.join(d, "g.csv"), index=False)
        assert S.check_against_gate2(res, os.path.join(d, "g.csv")) == 2
        rows[0]["평균E_gross(트랜치,h일)"] += 1e-6; pd.DataFrame(rows).to_csv(os.path.join(d, "g2.csv"), index=False)
        try:
            S.check_against_gate2(res, os.path.join(d, "g2.csv")); raise RuntimeError("불일치를 거부해야 함")
        except AssertionError:
            pass
        S.save_report(res, os.path.join(d, "o"))
        for f in ("main", "year", "be"):
            assert os.path.exists(os.path.join(d, "o", f"g2_slip_{f}.csv"))
        lines = []; S.print_report(res, out=lines.append); assert any("(B)" in x for x in lines) and any("(C)" in x for x in lines)


def test_nan_price_guard():
    prep = synth_prep(T=400, M=70, seed=51); P = prep["h"][5]
    pool, q5, _ = G.select_masks(P["F"]["LIQ"], +1); j = int(np.argmax(q5.sum(0))); t = int(np.where(q5[:, j] & np.isfinite(P["T1"][:, j]))[0][0])
    prep["Clf"] = prep["Clf"].copy(); prep["Clf"][P["tpos"][t], j] = np.nan
    try:
        S.eval_one(prep, "LIQ", 5, models=["TICK1"]); raise RuntimeError("가격 결측을 거부해야 함")
    except AssertionError:
        pass


def test_module_separation():
    tree = ast.parse(open(os.path.join(ROOT, "g2_slip.py")).read()); im = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom) and n.module is not None and n.level >= 1:
            im.add(n.module)
    assert "features" not in im and "targets" not in im and "gate2_run" not in im, im


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("ok", name)
    print("ALL PASS")
