"""Gate 2 후속 진단 2: LIQ 슬리피지 민감도(읽기 전용, 자본 규모 비의존).
Gate 2 판정·후보·임계·비용(왕복 0.206%)·선택 규칙을 바꾸지 않는다(재판정 없음, null 재실행 없음).
선택(Q5·풀)은 gate2.select_masks 그대로. features/targets를 import하지 않는다(입력은 prepare_g2 결과).
종목별 편도 슬리피지 s_i를 사전 고정 모델로 부과: 순수익 = (1+T1)*(1-s)/(1+s)-1 (매수 +s, 매도 -s), 기존 왕복 0.206%에 추가.
E_both  : Q5·풀 모두 각자의 s_i 부담(풀=거래 가능한 비교군)  /  E_Q5only: Q5만 부담, 풀은 비용 없음(Gate 2 break-even_초과 정의와 동일, 보수적).
모델(결과 열람 전 고정): UNI<bp> 균일 편도 bp, TICK<k> s=k*호가단위/(2*가격), TIER 거래대금 3분위(저/중/고)별 편도 bp."""
import numpy as np
import pandas as pd
from . import config as C
from .gate2 import select_masks, excess_days, tercile_pool

SLIP_CANDS = [("LIQ", 5), ("LIQ", 10), ("LIQ", 20)]
UNI_BP = (0, 5, 10, 15, 20, 30, 50)          # 균일 편도 bp (0 = Gate 2 기준)
TICK_K = (1.0, 2.0)                          # 1=반호가, 2=1호가 편도
TIER_BP = {1: 20.0, 2: 10.0, 3: 5.0}         # 거래대금 저/중/고 편도 bp (TL=0 해당없음은 저분위 값)
MODELS = [f"UNI{b}" for b in UNI_BP] + [f"TICK{k:g}" for k in TICK_K] + ["TIER"]


def tick_size(p):
    """호가단위(원): <1천:1, <5천:5, <1만:10, <5만:50, 그 이상 100(KOSPI 10만원 이상 구간은 500·1000이나 과소 반영; Q5 p90은 2만원대). KRX 규정 대조 필요."""
    p = np.asarray(p, float)
    return np.select([p < 1000, p < 5000, p < 10000, p < 50000], [1.0, 5.0, 10.0, 50.0], 100.0)


def slip_matrix(model, px, TL):
    """종목별 편도 슬리피지(비율) T×M. px: 신호일 종가(ffill), TL: 거래대금 3분위(0=해당없음)."""
    if model.startswith("UNI"):
        return np.full(px.shape, float(model[3:]) * 1e-4)
    if model.startswith("TICK"):
        k = float(model[4:])
        with np.errstate(invalid="ignore", divide="ignore"):
            return k * tick_size(px) / (2.0 * px)
    if model == "TIER":
        lo, mid, hi = TIER_BP[1], TIER_BP[2], TIER_BP[3]
        return np.select([TL == 2, TL == 3], [mid * 1e-4, hi * 1e-4], lo * 1e-4)
    raise ValueError(model)


def adjust(T1, S):
    """슬리피지 반영 수익률. T1 NaN 유지."""
    with np.errstate(invalid="ignore"):
        return (1.0 + T1) * (1.0 - S) / (1.0 + S) - 1.0


def _prep_inputs(prep, k, h):
    P = prep["h"][h]; d = C.FEATURE_DIRECTION[k]; T1 = P["T1"]
    pool, q5, _ = select_masks(P["F"][k], d)
    fin = np.isfinite(T1)
    px = prep["Clf"][P["tpos"]]
    TL = tercile_pool(pool, P["DV"])
    return P, T1, pool, q5, fin, px, TL


def _S(model, px, TL, pool, fin):
    S = slip_matrix(model, px, TL)
    assert np.isfinite(S[pool & fin]).all(), f"{model}: 유효 거래에 슬리피지 NaN(가격 결측)"
    return np.where(np.isfinite(S), S, 0.0)


def _stats(T1, Ya, pool, q5, fin, E0, mq0, mp0, h):
    E1, mq1, mp1, _ = excess_days(q5, pool, Ya, 0)
    ok = np.isfinite(E0)
    assert np.array_equal(ok, np.isfinite(E1)), "슬리피지 반영 후 평가일 집합이 달라짐"
    return {"E_both": float(E1[ok].mean()), "E_Q5only": float((mq1 - mp0)[ok].mean()),
            "Q5절대순수익": float(mq1[ok].mean() - C.G2_COST_RT)}


def eval_one(prep, k, h, models=None):
    P, T1, pool, q5, fin, px, TL = _prep_inputs(prep, k, h)
    E0, mq0, mp0, nq0 = excess_days(q5, pool, T1, 0)
    ok = np.isfinite(E0); yrs = pd.DatetimeIndex(P["dates"]).year.values
    main, year = [], []
    for m in (models or MODELS):
        S = _S(m, px, TL, pool, fin); Ya = adjust(T1, S)
        E1, mq1, mp1, _ = excess_days(q5, pool, Ya, 0)
        assert np.array_equal(ok, np.isfinite(E1))
        r = _stats(T1, Ya, pool, q5, fin, E0, mq0, mp0, h)
        r.update({"feature": k, "h": h, "모델": m, "Q5평균편도bp": float(S[q5 & fin].mean() * 1e4),
                  "풀평균편도bp": float(S[pool & fin].mean() * 1e4),
                  "Q5절대순수익_단순연환산": r["Q5절대순수익"] * C.G2_ANN_DAYS / h,
                  "E_both_단순연환산": r["E_both"] * C.G2_ANN_DAYS / h, "E_Q5only_단순연환산": r["E_Q5only"] * C.G2_ANN_DAYS / h,
                  "평가일": int(ok.sum())})
        main.append(r)
        for y in sorted(set(yrs)):
            mk = (yrs == y) & ok
            if mk.any():
                year.append({"feature": k, "h": h, "모델": m, "연도": int(y), "평가일": int(mk.sum()),
                             "Q5절대순수익": float(mq1[mk].mean() - C.G2_COST_RT), "E_both": float(E1[mk].mean()),
                             "E_Q5only": float((mq1 - mp0)[mk].mean())})
    return pd.DataFrame(main), pd.DataFrame(year)


def _solve(fn, hi):
    """fn(x) 단조감소. fn(0)<=0이면 nan(이미 음), fn(hi)>0이면 inf."""
    if fn(0.0) <= 0:
        return np.nan
    if fn(hi) > 0:
        return np.inf
    lo = 0.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if fn(mid) > 0: lo = mid
        else: hi = mid
    return 0.5 * (lo + hi)


def break_even(prep, k, h):
    """균일 편도 bp(절대 순수익 0 / Q5만 부담 초과 0), TICK 배수 k*(절대 0 / E_both 0)."""
    P, T1, pool, q5, fin, px, TL = _prep_inputs(prep, k, h)
    E0, mq0, mp0, _ = excess_days(q5, pool, T1, 0); ok = np.isfinite(E0)
    unit = _S("TICK1", px, TL, pool, fin)
    def f_abs_uni(s): return excess_days(q5, pool, adjust(T1, np.full(T1.shape, s)), 0)[1][ok].mean() - C.G2_COST_RT
    def f_exc_uni(s): return (excess_days(q5, pool, adjust(T1, np.full(T1.shape, s)), 0)[1] - mp0)[ok].mean()
    def f_abs_tick(x): return excess_days(q5, pool, adjust(T1, x * unit), 0)[1][ok].mean() - C.G2_COST_RT
    def f_both_tick(x): return excess_days(q5, pool, adjust(T1, x * unit), 0)[0][ok].mean()
    return {"feature": k, "h": h,
            "UNI_절대0_편도bp": _solve(f_abs_uni, 0.05) * 1e4, "UNI_Q5만부담_초과0_편도bp": _solve(f_exc_uni, 0.05) * 1e4,
            "TICK_절대0_배수k": _solve(f_abs_tick, 200.0), "TICK_E_both0_배수k": _solve(f_both_tick, 200.0)}


def run_slip(prep, cands=None, models=None, log=print):
    mains, years, bes = [], [], []
    for k, h in (cands or SLIP_CANDS):
        a, b = eval_one(prep, k, h, models); mains.append(a); years.append(b); bes.append(break_even(prep, k, h))
        log(f"슬리피지 진단 완료: {k} h={h}")
    return {"main": pd.concat(mains, ignore_index=True), "year": pd.concat(years, ignore_index=True), "be": pd.DataFrame(bes)}


def check_against_gate2(res, csv_path, atol=1e-12):
    """UNI0 행이 gate2_results.csv(평균E·Q5절대순수익)와 일치하는지 확인. 불일치 시 중단."""
    df = pd.read_csv(csv_path); m = res["main"]; n = 0
    for (k, h), g in m[m["모델"] == "UNI0"].groupby(["feature", "h"]):
        row = df[(df["feature"] == k) & (df["h"] == h)]
        assert len(row) == 1, f"gate2_results.csv에 {k} h={h} 없음"
        assert abs(row["평균E_gross(트랜치,h일)"].iloc[0] - g["E_both"].iloc[0]) < atol, (k, h, "평균E")
        assert abs(row["평균E_gross(트랜치,h일)"].iloc[0] - g["E_Q5only"].iloc[0]) < atol, (k, h, "평균E(Q5only)")
        assert abs(row["Q5절대순수익(트랜치,h일)"].iloc[0] - g["Q5절대순수익"].iloc[0]) < atol, (k, h, "Q5절대순수익")
        n += 1
    return n


def save_report(res, out_dir):
    import os
    os.makedirs(out_dir, exist_ok=True)
    for tag in ("main", "year", "be"):
        res[tag].to_csv(os.path.join(out_dir, f"g2_slip_{tag}.csv"), index=False, encoding="utf-8-sig")


def print_report(res, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
    m = res["main"]
    out("\n===== (A) 모델별: Q5 절대 순수익·초과 (기존 왕복 0.206% + 추가 슬리피지) =====")
    for (k, h), g in m.groupby(["feature", "h"], sort=False):
        out(f"\n[{k} h={h}]  (E_both: Q5·풀 모두 부담 / E_Q5only: Q5만 부담, 풀 무비용)")
        out(g[["모델", "Q5평균편도bp", "풀평균편도bp", "Q5절대순수익", "Q5절대순수익_단순연환산", "E_both", "E_Q5only", "E_Q5only_단순연환산"]].round(4).to_string(index=False))
    out("\n===== (B) break-even (추가 슬리피지 한계; nan=기준에서 이미 음, inf=상한 초과) =====")
    out(res["be"].round(3).to_string(index=False))
    out("\n===== (C) 연도별 (모델: TICK1·TICK2·TIER·UNI20) =====")
    y = res["year"]; y = y[y["모델"].isin(["TICK1", "TICK2", "TIER", "UNI20"])]
    for (k, h), g in y.groupby(["feature", "h"], sort=False):
        for col in ("Q5절대순수익", "E_both"):
            out(f"\n[{k} h={h}] {col}")
            out(g.pivot(index="연도", columns="모델", values=col).round(4).to_string())
