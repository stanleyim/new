import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from scipy.stats import rankdata
from research import config as C, d5_run as R, tl008 as X
from research.gate1 import block_ids

rng = np.random.default_rng(5)
res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f):
    try: f(); return False
    except AssertionError: return True

T, M = 120, 200
DV = np.exp(rng.normal(20, 1.5, (T, M))); CL = np.exp(rng.normal(8.5, 1.0, (T, M)))
noise = rng.normal(size=(T, M))
rd = pd.DataFrame(DV).rank(axis=1, pct=True).values; rc = pd.DataFrame(CL).rank(axis=1, pct=True).values
F = np.exp(1.5 * (-1.2 * rd + 0.6 * rc) + 0.8 * noise)              # LIQ는 거래대금 역·종가 정(+) 노출 + 독립 성분(noise)
RES, dg = X.residualize(F, DV, CL)
# 1) 직교성·형상·결측 패턴
ok("직교(순위상관≈0)", dg["corr_res_dv"].abs().max() < 1e-9 and dg["corr_res_close"].abs().max() < 1e-9)
ok("독립성분 회복(잔차~noise 순위상관>0.9)", np.nanmean([np.corrcoef(RES[t], noise[t])[0, 1] for t in range(T)]) > 0.9)
ok("원본은 노출과 강한 상관", dg["corr_liq_dv"].mean() < -0.5 and dg["r2"].mean() > 0.3)
# 2) 단조변환 불변(순위 기반)·일별 독립(다른 날 값 변경이 이 날 결과를 안 바꿈)
R2, _ = X.residualize(np.exp(F / F.max() * 5), DV, CL)
ok("LIQ 단조변환 불변", np.allclose(np.nan_to_num(R2, nan=9), np.nan_to_num(RES, nan=9), atol=1e-12))
F2 = F.copy(); F2[50:] = rng.normal(size=(T - 50, M)); R3, _ = X.residualize(F2, DV, CL)
ok("일별 독립(미래 행 변경이 과거 불변)", np.array_equal(R3[:50], RES[:50]))
# 3) 결측·하한·비정상 입력
Fm = F.copy(); Fm[10, 5:] = np.nan                                    # 유효 5개 <50 → 그날 결측
DVm = DV.copy(); DVm[20, :150] = np.nan                               # 거래대금 결측 종목 제외, 50개 남음
CLm = CL.copy(); CLm[30, :10] = -1.0                                  # 종가<=0 제외
Rm, dm = X.residualize(Fm, DVm, CLm)
ok("유효<50이면 그날 전부 NaN", np.isnan(Rm[10]).all())
ok("거래대금 결측 종목은 NaN·나머지 유효", np.isnan(Rm[20, :150]).all() and np.isfinite(Rm[20, 150:]).all())
ok("종가<=0 종목 제외", np.isnan(Rm[30, :10]).all() and np.isfinite(Rm[30, 10:]).all() and dm.loc[30, "n_used"] == M - 10)
ok("형상 불일치 중단", raises(lambda: X.residualize(F[:, :10], DV, CL)))
# 4) 동률 처리: 같은 값은 같은 순위 → 같은 잔차(노출도 같을 때)
Ft = F.copy(); Ft[0, :] = 1.0; Rt, _ = X.residualize(Ft, DV, CL)
ok("동률 입력도 유한·직교", np.isfinite(Rt[0]).all())

# 5) 종단: 합성 prep(원본 LIQ 포함)으로 선행조건·Gate 1(K 축소) 수행
class small_k:
    def __init__(self, k=20): self.k = k
    def __enter__(self):
        self.old = C.K_SHIFTS; C.K_SHIFTS = self.k; self.o2 = dict(R.PREREG); R.PREREG["K_SHIFTS"] = self.k
    def __exit__(self, *a):
        C.K_SHIFTS = self.old; R.PREREG.clear(); R.PREREG.update(self.o2)
T2_, M2 = 400, 150
idx = pd.bdate_range("2018-01-02", periods=T2_)
cal = pd.bdate_range("2017-06-01", "2023-03-01")
cols = [f"S{i}" for i in range(M2)]
DVd = pd.DataFrame(np.exp(rng.normal(20, 1.5, (len(cal), M2))), index=cal, columns=cols)
CLd = pd.DataFrame(np.exp(rng.normal(8.5, 1.0, (len(cal), M2))), index=cal, columns=cols)
rdv = DVd.loc[idx].rank(axis=1, pct=True).values; rcl = CLd.loc[idx].rank(axis=1, pct=True).values
sig = rng.normal(size=(T2_, M2))                                    # 노출과 무관한 진짜 신호 성분
LIQ = np.exp(-1.0 * rdv + 0.5 * rcl + 0.7 * sig)
Y = 0.5 * sig + rng.normal(size=(T2_, M2)); Y[rng.random((T2_, M2)) < .05] = np.nan
Y2 = pd.DataFrame(Y).rank(axis=1, pct=True).values
prep = {h: {"dates": idx, "block": block_ids(idx), "T1": Y.copy(), "T2": Y2.copy(), "T1_L1": Y.copy(), "F": {"LIQ": LIQ.copy()}} for h in (5, 10, 20)}
tdir = tempfile.mkdtemp(); csv = os.path.join(tdir, "g1.csv")
with X.direction_ctx():
    rows = [{"feature": "LIQ", "h": h, "target": "T1", "ic_mean": R.observed(prep[h], "LIQ")[0]["ic_mean"]} for h in prep]
pd.DataFrame(rows).to_csv(csv, index=False, encoding="utf-8-sig")
with small_k(20):
    msgs = []
    r, meta, dd = X.run_tl008(prep, DVd, CLd, os.path.join(tdir, "o1"), csv, log=msgs.append)
ok("선행조건·직교 로그", any("일치 OK" in m for m in msgs) and any("직교성 OK" in m for m in msgs))
ok("family 1·trial 9", meta["families"] == 1 and meta["trials"] == 9 and set(r["df"]["feature"]) == {X.FEATURE})
ok("방향 컨텍스트 해제", X.FEATURE not in C.FEATURE_DIRECTION)
ok("노출 제거 후 심은 신호 검출(IC>0, stage1 통과 존재)", (r["df"]["ic_mean"] > 0).all() and r["df"]["s1_IC"].any())
ok("진단 표 형식", len(dd) == 3 and (dd["평균 R2"] > 0.1).all())
X.print_report(r, meta, dd, csv, out=lambda s: None); ok("print_report 동작", True)
# 순수 노출만 있는 LIQ(진짜 성분 없음)에서는 잔차 신호 없음
LIQ0 = np.exp(-1.0 * rdv + 0.5 * rcl + 0.7 * rng.normal(size=(T2_, M2)))
Y0 = 0.5 * (-rdv) + rng.normal(size=(T2_, M2)); Y02 = pd.DataFrame(Y0).rank(axis=1, pct=True).values
prep0 = {h: {"dates": idx, "block": block_ids(idx), "T1": Y0.copy(), "T2": Y02.copy(), "T1_L1": Y0.copy(), "F": {"LIQ": LIQ0.copy()}} for h in (5, 10, 20)}
with X.direction_ctx():
    pd.DataFrame([{"feature": "LIQ", "h": h, "target": "T1", "ic_mean": R.observed(prep0[h], "LIQ")[0]["ic_mean"]} for h in prep0]).to_csv(csv, index=False, encoding="utf-8-sig")
with small_k(20):
    r0, m0, _ = X.run_tl008(prep0, DVd, CLd, os.path.join(tdir, "o0"), csv, log=lambda s: None)
    with X.direction_ctx():
        raw_ic = np.mean([R.observed(prep0[h], "LIQ")[0]["ic_mean"] for h in prep0])
ok("순수 노출 LIQ: 원본 IC>0이나 잔차 stage1 불통과", raw_ic > 0.02 and m0["stage1_IC_BH"] == 0)
# 원본 IC 불일치 시 중단
bad = pd.read_csv(csv); bad["ic_mean"] += 1e-9; bad.to_csv(csv, index=False)
with small_k(20):
    ok("D5 csv 불일치 시 중단", raises(lambda: X.run_tl008(prep0, DVd, CLd, os.path.join(tdir, "o2"), csv, log=lambda s: None)))

fails = [n for n, c in res if not c]
print(f"test_tl008: {len(res) - len(fails)}/{len(res)} PASS" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
