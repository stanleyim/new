"""TL-005 근접 검증 합성 검증: 기간 컨텍스트 복원·이동량·판정 로직·재현 확인기·종단 실행·실제 경로(로더~라벨) 기간 확장."""
import tempfile
import numpy as np
import pandas as pd
from research import config as C
from research import near_run as N
from research import gate2_run as G2
from research.gate1 import block_ids
from research.tests.test_synthetic import make_world


def make_prep(T=300, M=100, seed=0):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2023-01-02", periods=T); Nn = T + 25
    O = 100 * np.exp(np.cumsum(rng.normal(0, 0.01, (Nn, M)), axis=0)); Clf = O * (1 + rng.normal(0, 0.002, (Nn, M)))
    base = {k: rng.normal(size=(T, M)) for k in ["REV", "RISK", "ATTN", "LIQ"]}
    prep = {"O": O, "Clf": Clf, "h": {}}
    for h in (5, 10, 20):
        F = {k: v.copy() for k, v in base.items()}
        for k in F:
            F[k][rng.random((T, M)) < 0.05] = np.nan
        z = (F["LIQ"] - np.nanmean(F["LIQ"], axis=1, keepdims=True)) / np.nanstd(F["LIQ"], axis=1, keepdims=True)
        T1 = 0.01 * np.nan_to_num(z) + rng.normal(0, 0.03, (T, M))        # LIQ에만 심은 edge
        prep["h"][h] = {"dates": dates, "block": block_ids(dates), "tpos": np.arange(T), "T1": T1,
                        "status": np.zeros((T, M), np.int8), "DV": rng.random((T, M)) + 0.1, "F": F}
    return prep


def test_period_restore():
    a = (C.SIGNAL_START, C.SIGNAL_END)
    with N.period("2023-01-02", "2024-12-30"):
        assert C.SIGNAL_START == pd.Timestamp("2023-01-02") and C.SIGNAL_END == pd.Timestamp("2024-12-30")
    assert (C.SIGNAL_START, C.SIGNAL_END) == a
    try:
        with N.period("2023-01-02", "2024-12-30"):
            raise RuntimeError("x")
    except RuntimeError:
        pass
    assert (C.SIGNAL_START, C.SIGNAL_END) == a
    old = G2.null_unit
    with N.patched(G2, "null_unit", N.null_dummy):
        assert G2.null_unit is N.null_dummy
    assert G2.null_unit is old


def test_all_shifts():
    s = N.all_shifts(300)
    assert len(s) == 300 - 79 and s[0] == 40 and s[-1] == 260 and (np.diff(s) == 1).all()
    assert (N.all_shifts(300) == s).all()
    assert len(N.all_shifts(485)) == 406


def test_judge_logic():
    base = {"판정불가": False, "블록양비율": 1.0, "블록임계": 1.0, "Q5절대순수익(트랜치,h일)": 0.01}
    rows = []
    for k, h, p in [("LIQ", 5, 0.001), ("LIQ", 10, 0.02), ("LIQ", 20, 0.5), ("RISK", 10, 0.04), ("RISK", 20, 0.2)]:
        rows.append({"feature": k, "h": h, "p_E": p, **base})
    df = pd.DataFrame(rows)
    j = N.judge(df)
    assert list(j["s1_초과BH"]) == [True, True, False, True, False]            # m=3: 0.001,0.02 / m=2: 0.04<=0.05
    assert list(j["판정"]) == ["통과", "통과", "실패", "통과", "실패"]
    d2 = df.copy(); d2.loc[0, "블록양비율"] = 0.5; d2.loc[1, "Q5절대순수익(트랜치,h일)"] = -0.001; d2.loc[3, "판정불가"] = True
    j2 = N.judge(d2)
    assert list(j2["판정"]) == ["실패", "실패", "실패", "판정불가", "실패"]
    assert np.isnan(j2.loc[3, "bh_q"])                                           # 판정불가는 BH 제외


def test_replication_checker():
    prep = make_prep(T=300, M=100, seed=1)
    new = N.eval_df(prep, G2.CANDS, N.null_dummy)
    assert N.check_replication(new, new.copy()) == []
    bad = new.copy(); bad.loc[3, "Q5_CAGR"] += 1e-6
    r = N.check_replication(new, bad)
    assert r and r[0][0] == "Q5_CAGR" and r[0][1] == 1
    assert N.check_replication(new, new.iloc[:-1].copy())[0][0] == "후보 집합 불일치"
    nan_same = new.copy(); nan_same.loc[0, "Q5_MDD"] = np.nan
    assert N.check_replication(nan_same, nan_same.copy()) == []


def test_pipeline_synthetic():
    prep = make_prep(T=300, M=100, seed=0)
    df, meta = N.run_near(prep, log=lambda *a: None)
    assert len(df) == 5 and set(zip(df["feature"], df["h"])) == set(N.NEAR_CANDS)
    assert meta["이동량 수"] == [300 - 79] and (df["평가일"] > 200).all() and not df["판정불가"].any()
    assert (df["p_E"] > 0).all() and (df["p_E"] <= 1).all() and (df["p_E"] >= 1 / 222 - 1e-12).all()
    liq = df[df["feature"] == "LIQ"]; risk = df[df["feature"] == "RISK"]
    assert (liq["p_E"] < 0.02).all() and (liq["판정"] == "통과").all(), liq[["h", "p_E", "블록양비율", "블록임계", "판정"]]
    assert (risk["판정"] != "통과").all(), risk[["h", "p_E", "판정"]]
    assert {"E평균_2023", "E평균_2024"} <= set(df.columns) and "E평균_2018-19" not in df.columns
    d = prep["h"][5]["dates"]; yr = d.year.values
    assert abs(df.loc[(df.feature == "LIQ") & (df.h == 5), "E평균_2023"].iloc[0]) > 0
    # 근접 구간 밖 신호일 차단
    bad = make_prep(T=300, M=100, seed=0)
    for h in bad["h"]:
        bad["h"][h]["dates"] = pd.bdate_range("2024-06-03", periods=300)
    try:
        N.run_near(bad, log=lambda *a: None); raise RuntimeError("구간 밖 거부해야 함")
    except AssertionError:
        pass
    # 사전등록 상수 변경 거부
    old = C.G2_COST_RT; C.G2_COST_RT = 0.001
    try:
        N.run_near(prep, log=lambda *a: None); raise RuntimeError("상수 불일치 거부해야 함")
    except AssertionError:
        pass
    finally:
        C.G2_COST_RT = old


def test_real_path_window():
    """로더~라벨 실제 경로가 기간 컨텍스트에서 확장 구간(설계 상한 이후)을 처리하고, 상한 밖 데이터는 적재하지 않는다."""
    with tempfile.TemporaryDirectory() as tmp:
        paths = make_world(tmp)
        prep, info = N.build_prep(paths, (pd.Timestamp("2022-07-01"), pd.Timestamp("2023-02-28")), "window")
        for h in N.HORIZONS:
            d = pd.DatetimeIndex(prep["h"][h]["dates"])
            assert d.min() >= pd.Timestamp("2022-07-01") and d.max() <= pd.Timestamp("2023-02-28")
            assert d.max() > C.SIGNAL_END, "설계 상한 이후 신호일이 생성돼야 함"
            assert prep["O"].shape[0] == len(pd.bdate_range("2017-01-02", "2023-02-28"))
        cut, _ = N.build_prep(paths, (pd.Timestamp("2022-07-01"), pd.Timestamp("2022-12-30")), "cut")
        assert cut["O"].shape[0] == len(pd.bdate_range("2017-01-02", "2022-12-30"))     # 상한 이후 미적재
        assert pd.DatetimeIndex(cut["h"][5]["dates"]).max() <= pd.Timestamp("2022-12-30")
        # 겹치는 신호일의 Feature는 두 실행에서 동일(상한만 다름; 후행 계산이라 불변)
        a, b = prep["h"][5], cut["h"][5]
        common = pd.DatetimeIndex(b["dates"]).intersection(pd.DatetimeIndex(a["dates"]))
        ia = pd.DatetimeIndex(a["dates"]).get_indexer(common); ib = pd.DatetimeIndex(b["dates"]).get_indexer(common)
        for k in a["F"]:
            np.testing.assert_allclose(a["F"][k][ia], b["F"][k][ib], equal_nan=True)
    assert (C.SIGNAL_START, C.SIGNAL_END) == (N.DESIGN[0], N.DESIGN[1])


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("ok", name)
    print("ALL PASS")
