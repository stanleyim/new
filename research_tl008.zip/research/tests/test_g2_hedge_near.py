import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from research import g2_hedge as H, g2_hedge_near as X, config as C
from research.gate2 import perf

rng = np.random.default_rng(11)
res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f):
    try: f(); return False
    except AssertionError: return True

# 1) hedge_path == H.hedge_eval, 절단 불변(=설계·연속 경로 동일성의 근거), 누수 없음
N = 1000; a, b = 30, N - 6
ridx = rng.normal(0, .01, (N, 2)); ridx[0] = 0
rq = 0.0005 + 1.2 * ridx[:, 0] + 0.4 * ridx[:, 1] + rng.normal(0, 3e-4, N)
rh, beta, s, us, ds = X.hedge_path(rq, ridx, a, b)
o = H.hedge_eval(rq, ridx, a, b, np.where(np.arange(N) < N // 2, 2019, 2021))
ok("hedge_path 일평균=hedge_eval", abs(rh[s:b + 1].mean() - o["헤지후_일평균"]) < 1e-15)
ok("hedge_path MDD=hedge_eval", abs(perf(rh, s, b)["MDD"] - o["헤지후_MDD"]) < 1e-15)
b1 = 700
rh1 = X.hedge_path(rq, ridx, a, b1)[0]
ok("절단 불변(b1 이하 동일)", np.array_equal(rh1[:b1 + 1], rh[:b1 + 1]))
u1 = us[5]; r_ = ridx.copy(); q_ = rq.copy(); r_[u1:] = rng.normal(0, .05, (N - u1, 2)); q_[u1:] = rng.normal(0, .05, N - u1)
ok("누수 없음(u1 이전 불변)", np.array_equal(X.hedge_path(q_, r_, a, b)[0][:u1], rh[:u1]))

# 2) eval_window 판정 로직
yrs = np.where(np.arange(N) < 500, 2023, 2024)
def ev(rq_, e0=400):
    rh_, bt, s_, us_, ds_ = X.hedge_path(rq_, ridx, a, b)
    return X.eval_window(rq_, rh_, np.zeros(N), bt, ridx, us_, ds_, e0, b, yrs)
e = ev(rq)
ok("양/양/MDD감소 → 통과", e["조건1_일평균>0"] and e["조건2_MDD감소"] and e["조건3_두해양"] and e["통과"])
ok("β 복원(1.2/0.4)", abs(e["평균β_KOSPI200"] - 1.2) < .03 and abs(e["평균β_KOSDAQ"] - 0.4) < .03)
rqn = rq.copy(); rqn[500:] -= 0.0012
e2 = ev(rqn)
ok("2024 음 → ③ 실패", (not e2["조건3_두해양"]) and (not e2["통과"]))
e3 = ev(rq - 0.0020)
ok("전체 음 → ① 실패", (not e3["조건1_일평균>0"]) and (not e3["통과"]))
ok("연도 평가일 부재 중단", raises(lambda: X.eval_window(rq, rh, np.zeros(N), beta, ridx, us, ds, 600, b, yrs)))
ok("β 미설정 구간 중단", raises(lambda: X.eval_window(rq, rh, np.zeros(N), beta, ridx, us, ds, s - 5, b, yrs)))

# 3) 설계-연속 일치 점검
ok("일치 점검 정상", X.check_design_equal(rq, rh, rq, rh, 600) == [])
rq_p = rq.copy(); rq_p[300] += 1e-6
ok("일치 점검 위반 탐지", len(X.check_design_equal(rq_p, rh, rq, rh, 600)) == 1)

# 4) 종단(합성 시장): 설계 prep(≤2022-12-29) vs 연속 prep(≤2024-12-30)
cal_c = pd.bdate_range("2017-01-02", "2024-12-30"); cal_d = cal_c[cal_c <= pd.Timestamp("2022-12-29")]
Nc, Nd, M = len(cal_c), len(cal_d), 70
P0 = 100 * np.cumprod(1 + rng.normal(0, .012, (Nc, M)), axis=0)
O = P0 * (1 + rng.normal(0, .002, (Nc, M))); Clf = P0.copy()
t0 = int(cal_c.searchsorted(pd.Timestamp("2018-01-02")))
Fall = rng.normal(size=(Nc, M))
def mkprep(n, h):
    tp = np.arange(t0, n - h - 1)
    return {"O": O[:n], "Clf": Clf[:n], "h": {h: {"tpos": tp, "T1": np.full((len(tp), M), 0.01), "F": {"LIQ": Fall[tp]}}}}
def mk_both():
    pd_ = {"O": O[:Nd], "Clf": Clf[:Nd], "h": {}}; pc_ = {"O": O, "Clf": Clf, "h": {}}
    for h in (10, 20):
        pd_["h"][h] = mkprep(Nd, h)["h"][h]; pc_["h"][h] = mkprep(Nc, h)["h"][h]
    return pd_, pc_
prep_d, prep_c = mk_both()
tdir = tempfile.mkdtemp()
rows = []
for n in ("KOSPI200", "KOSDAQ", "KOSPI"):
    px = 100 * np.cumprod(1 + rng.normal(0, .01, Nc))
    rows.append(pd.DataFrame({"date": cal_c, "index": n, "종가": px}))
allx = pd.concat(rows)
for y in range(2017, 2025): allx[allx["date"].dt.year == y].to_parquet(f"{tdir}/idx_{y}.parquet")
csv = os.path.join(tdir, "g2.csv"); rec = []
for k, h in X.CANDS:
    rq_d, rp_d, a_d, b_d = X.q5_paths(prep_d, k, h); pq = perf(rq_d, a_d, b_d)
    rec.append({"feature": k, "h": h, "Q5_CAGR": pq["CAGR"], "Q5_Sharpe": pq["Sharpe"], "Q5_MDD": pq["MDD"]})
pd.DataFrame(rec).to_csv(csv, index=False)
msgs = []
des = X.design_stage(prep_d, cal_d, tdir, csv, check_tl006=False, log=msgs.append)
ok("design_stage 재현 OK", sum("재현 OK" in m for m in msgs) == 2 and len(des) == 2)
ok("TL-006 기록값 불일치 시 중단(합성은 불일치)", raises(lambda: X.design_stage(prep_d, cal_d, tdir, csv, check_tl006=True, log=lambda m: None)))
bad = pd.read_csv(csv); bad.loc[0, "Q5_MDD"] += 1e-6; bad.to_csv(csv + "x", index=False)
ok("gate2 불일치 시 중단", raises(lambda: X.design_stage(prep_d, cal_d, tdir, csv + "x", check_tl006=False, log=lambda m: None)))
msgs = []
df = X.near_stage(prep_c, cal_c, cal_d, tdir, des, log=msgs.append)
ok("near_stage 종단·연속=설계 일치", len(df) == 2 and sum("일치 OK" in m for m in msgs) == 2)
ok("평가 시작=2023-01-02·종료≤2024-12-30", (df["평가시작"] == "2023-01-02").all() and (pd.to_datetime(df["평가종료"]) <= X.EVAL_END).all())
X.print_report(df, out=lambda s: None); ok("print_report 동작", True)
# 설계 구간 Feature를 연속 prep에서 바꾸면 중단(연속 경로≠설계 경로)
pc2 = {"O": O, "Clf": Clf, "h": {h: dict(v, F={"LIQ": v["F"]["LIQ"].copy()}) for h, v in prep_c["h"].items()}}
pc2["h"][10]["F"]["LIQ"][100] = rng.normal(size=M)
ok("설계구간 경로 불일치 시 중단", raises(lambda: X.near_stage(pc2, cal_c, cal_d, tdir, des, log=lambda m: None)))
# 데이터 상한 위반
cal_over = pd.bdate_range("2017-01-02", periods=Nc + 5)
ok("상한 초과 캘린더 중단", raises(lambda: X.near_stage(prep_c, cal_over, cal_d, tdir, des, log=lambda m: None)))
# 2023 이전 데이터가 달라도(신호 이후) 평가가 2023-01-02 이전 일을 쓰지 않는다
ok("평가일 수=종료-시작 구간", all(df.loc[i, "평가일"] == int(pd.bdate_range(df.loc[i, "평가시작"], df.loc[i, "평가종료"]).size) for i in df.index))

fails = [n for n, c in res if not c]
print(f"test_g2_hedge_near: {len(res) - len(fails)}/{len(res)} PASS" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
