import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from research import g2_hedge as H, config as C
from research.gate2 import perf

rng = np.random.default_rng(7)
res = []
def ok(name, cond):
    res.append((name, bool(cond)))

# 1) load_idx_returns: 정확한 수익률·결측/중복/이름 오류 중단
t = tempfile.mkdtemp()
cal = pd.bdate_range("2017-01-02", "2018-12-31")
def mk(names=("KOSPI200", "KOSDAQ", "KOSPI"), drop=None, dup=False):
    rows = []
    for n in names:
        px = 100 * np.cumprod(1 + rng.normal(0, .01, len(cal)))
        rows.append(pd.DataFrame({"date": cal, "index": n, "종가": px}))
    d = pd.concat(rows)
    if drop is not None: d = d[~((d["index"] == "KOSDAQ") & (d["date"] == cal[drop]))]
    if dup: d = pd.concat([d, d.iloc[:1]])
    for y in (2017, 2018): d[d["date"].dt.year == y].to_parquet(f"{t}/idx_{y}.parquet")
    return d
d = mk(); r = H.load_idx_returns(t, cal)
p = d[d["index"] == "KOSPI200"].set_index("date")["종가"].reindex(cal).values
ok("idx수익률 정확", np.allclose(r[1:, 0], p[1:] / p[:-1] - 1) and r[0, 0] == 0)
def raises(f):
    try: f(); return False
    except AssertionError: return True
mk(drop=5); ok("idx 결측 중단", raises(lambda: H.load_idx_returns(t, cal)))
mk(dup=True); ok("idx 중복 중단", raises(lambda: H.load_idx_returns(t, cal)))
mk(names=("KOSPI200", "KOSPI")); ok("idx 이름 부재 중단", raises(lambda: H.load_idx_returns(t, cal)))

# 2) hedge_eval: β 복원·수기 OLS·누수·조건 로직
N = 900; a, b = 20, N - 5
ridx = rng.normal(0, .01, (N, 2)); ridx[0] = 0
alpha = 0.0006
rq = alpha + 1.5 * ridx[:, 0] + 0.5 * ridx[:, 1] + rng.normal(0, 1e-4, N)
years = np.where(np.arange(N) < N // 2, 2019, 2021)
o = H.hedge_eval(rq, ridx, a, b, years)
ok("β 복원(1.5/0.5)", abs(o["평균β_KOSPI200"] - 1.5) < 0.02 and abs(o["평균β_KOSDAQ"] - 0.5) < 0.02)
ok("헤지후 일평균≈alpha", abs(o["헤지후_일평균"] - alpha) < 2e-5)
ok("사후잔차β≈0", abs(o["사후잔차β_KOSPI200"]) < 0.02 and abs(o["사후잔차β_KOSDAQ"]) < 0.02)
ok("MDD 감소·통과", o["조건2_MDD감소"] and o["통과"])
# 수기 OLS 대조: 첫 갱신일 β
s = a + H.BETA_WIN
X = np.column_stack([np.ones(H.BETA_WIN), ridx[s - H.BETA_WIN:s]])
cf = np.linalg.solve(X.T @ X, X.T @ rq[s - H.BETA_WIN:s])[1:]
rq2 = rq.copy()
# 누수: 두 번째 갱신일 u1 이후 값을 바꿔도 u1 이전 일의 헤지후 수익률 불변
u1 = s + H.BETA_STEP
import research.g2_hedge as HH
def hedged(rq_, ridx_):
    beta = np.zeros((N, 2))
    for u in range(s, b + 1, H.BETA_STEP):
        X = np.column_stack([np.ones(H.BETA_WIN), ridx_[u - H.BETA_WIN:u]])
        beta[u:min(u + H.BETA_STEP, b + 1)] = np.linalg.lstsq(X, rq_[u - H.BETA_WIN:u], rcond=None)[0][1:]
    return rq_ - (beta * ridx_).sum(1)
r_ = ridx.copy(); r_[u1:] = rng.normal(0, .05, (N - u1, 2)); q_ = rq.copy(); q_[u1:] = rng.normal(0, .05, N - u1)
ok("누수 없음(u1 이전 불변)", np.allclose(hedged(rq, ridx)[:u1], hedged(q_, r_)[:u1]))
ok("첫 갱신 β 수기 OLS 일치", np.allclose(cf, [1.5, 0.5], atol=0.02))
# 조건 로직: 헤지해도 일평균이 음수인 경우 실패
o2 = H.hedge_eval(-alpha + 1.5 * ridx[:, 0] + rng.normal(0, 1e-4, N), ridx, a, b, years)
ok("일평균<0 → 불통과", (not o2["조건1_일평균>0"]) and (not o2["통과"]))
# 한 구간만 양인 경우 ③ 실패
rq3 = rq.copy(); rq3[N // 2:] -= 2 * alpha
o3 = H.hedge_eval(rq3, ridx, a, b, years)
ok("한 구간 음 → ③ 실패", not o3["조건3_두구간양"])
ok("평가구간 부족 중단", raises(lambda: H.hedge_eval(rq, ridx, a, a + 50, years)))

# 3) run_hedge 종단: 합성 prep, 재현 점검
M, h = 60, 5
Nn = 400
P0 = 100 * np.cumprod(1 + rng.normal(0, .01, (Nn, M)), axis=0)
O = P0 * (1 + rng.normal(0, .002, (Nn, M))); Clf = P0.copy()
tpos = np.arange(10, Nn - 8)
T = len(tpos)
Fv = rng.normal(size=(T, M))
cal2 = pd.bdate_range("2019-01-01", periods=Nn)
prep = {"O": O, "Clf": Clf, "h": {h: {"tpos": tpos, "T1": np.full((T, M), 0.01), "F": {"LIQ": Fv}}}}
idx2 = rng.normal(0, .01, (Nn, 2)); idx2[0] = 0
# 합성은 신호일≥10, 평가구간 부족하므로 L 축소 불가 → run_hedge는 조건 오류가 나야 함(평가구간 길이 검증), 재현 점검만 별도 확인
rq_ = None
from research.gate2 import select_masks, daily_path
_, q5, _ = select_masks(Fv, C.FEATURE_DIRECTION["LIQ"])
rq_ = daily_path(q5 & np.isfinite(prep["h"][h]["T1"]), O, Clf, tpos, h)
a_, b_ = int(tpos[0]) + h, int(tpos[-1]) + 1
pq = perf(rq_, a_, b_)
csv = os.path.join(t, "g2.csv")
pd.DataFrame([{"feature": "LIQ", "h": h, "Q5_CAGR": pq["CAGR"], "Q5_Sharpe": pq["Sharpe"], "Q5_MDD": pq["MDD"]}]).to_csv(csv, index=False)
msgs = []
df = H.run_hedge(prep, idx2, cal2.year, gate2_csv=csv, cands=[("LIQ", h)], log=msgs.append)
ok("run_hedge 종단·재현 OK", len(df) == 1 and any("재현 OK" in m for m in msgs) and df.loc[0, "평가일"] == b_ + 1 - (a_ + H.BETA_WIN))
bad = pd.read_csv(csv); bad["Q5_MDD"] += 1e-6; bad.to_csv(csv, index=False)
ok("재현 불일치 시 중단", raises(lambda: H.run_hedge(prep, idx2, cal2.year, gate2_csv=csv, cands=[("LIQ", h)], log=lambda m: None)))
msgs2 = []; H.run_hedge(prep, idx2, cal2.year, gate2_csv=None, cands=[("LIQ", h)], log=msgs2.append)
ok("csv 없음 경고", any("재현 미확인" in m for m in msgs2))
H.print_report(df, out=lambda s: None)
ok("print_report 동작", True)

fails = [n for n, c in res if not c]
print(f"test_g2_hedge: {len(res) - len(fails)}/{len(res)} PASS" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
