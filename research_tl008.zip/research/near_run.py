"""TL-005 근접 검증(2023~24): Gate 2 통과 5개 (Feature,h)를 Gate 2와 동일 코드·규칙으로 재평가한다.
기존 모듈은 수정하지 않는다. 기간만 config(SIGNAL_START/END)를 컨텍스트로 바꿔 같은 파이프라인을 재사용한다.
null: 가능한 이동량 전부([MIN_SHIFT, N-MIN_SHIFT] 정수, 무작위·seed 없음). 2년 구간은 서로 다른 이동량이
1,000개 미만이라 K=1,000이 불가능하다(Stanley 승인 2026-10-06). 실행 전 설계구간(2018~22)에서 기존 Gate 2 결과를 재현해야 한다."""
import contextlib
import numpy as np
import pandas as pd
from . import config as C
from . import gate2_run as G2
from .d5_run import bh_adjust, check_prereg
from .gate1 import bh_reject
from .gate2 import excess_days, select_masks, null_excess

DESIGN = (pd.Timestamp("2018-01-02"), pd.Timestamp("2022-12-30"))
NEAR = (pd.Timestamp("2023-01-02"), pd.Timestamp("2024-12-30"))      # 데이터 상한도 NEAR[1] (2025-01 이후 미적재)
NEAR_CANDS = [("RISK", 10), ("RISK", 20), ("LIQ", 5), ("LIQ", 10), ("LIQ", 20)]   # Gate 2 통과 5개, 변경 불가
HORIZONS = (5, 10, 20)
PREREG_NEAR = dict(MIN_SHIFT=40, GATE1_MIN_N=50, BLOCK_MIN_DAYS=60, BH_Q=0.10, NULL_PCT=0.95,
                   MIN_ELIG_FRAC=0.5, G2_COST_RT=0.00206, G2_ANN_DAYS=252, G2_QUANTILE=5)
REPL_COLS = ["신호일", "평가일", "평가비율", "평균E_gross(트랜치,h일)", "초과연환산(=E×252/h)", "블록포함", "블록양비율",
             "Q5_CAGR", "Q5_Sharpe", "Q5_MDD", "풀_CAGR", "풀_Sharpe", "풀_MDD", "초과일평균연환산(경로)",
             "Q5 거래 수(종목×트랜치)", "일평균 Q5 종목수", "유효 독립 표본(≈평가일/h)", "Q5평균_gross(트랜치,h일)",
             "Q5절대순수익(트랜치,h일)", "break_even_절대_bp", "break_even_초과_bp",
             "저분위_Q5평균(gross)", "중분위_Q5평균(gross)", "고분위_Q5평균(gross)", "저분위_E", "중분위_E", "고분위_E",
             "E평균_2018-19", "E평균_2020-22", "Q5 제외(일시정지·진입불가·이상치)", "Q5 제외 비율", "Q5 L2청산"]


@contextlib.contextmanager
def period(start, end):
    old = (C.SIGNAL_START, C.SIGNAL_END)
    C.SIGNAL_START, C.SIGNAL_END = pd.Timestamp(start), pd.Timestamp(end)
    try:
        yield
    finally:
        C.SIGNAL_START, C.SIGNAL_END = old


@contextlib.contextmanager
def patched(mod, name, fn):
    old = getattr(mod, name)
    setattr(mod, name, fn)
    try:
        yield
    finally:
        setattr(mod, name, old)


def all_shifts(n_rows):
    lo, hi = C.MIN_SHIFT, n_rows - C.MIN_SHIFT
    assert hi >= lo, "이동량 후보 없음"
    return np.arange(lo, hi + 1)


def null_all(P, k, h, out_dir, pool, q5):
    return null_excess(q5, pool, P["T1"], all_shifts(P["T1"].shape[0]), P["block"])


def null_dummy(P, k, h, out_dir, pool, q5):
    return np.full((1, 2), np.nan)          # 재현 확인 전용(null 의존 열은 비교하지 않음)


def eval_df(prep, cands, null_fn, log=lambda *a: None):
    with patched(G2, "null_unit", null_fn):
        return pd.DataFrame([G2.evaluate(prep, k, h, None, log) for k, h in cands])


def judge(df):
    """run_gate2와 동일한 판정: ①평균E p + Feature family 내부 BH ②블록 양비율≥null95th ③Q5 절대순수익>0."""
    df = df.copy()
    df["bh_q"] = np.nan
    df["s1_초과BH"] = False
    for k in df["feature"].unique():
        m = (df["feature"] == k) & ~df["판정불가"]
        if m.any():
            p = df.loc[m, "p_E"].values
            df.loc[m, "bh_q"] = bh_adjust(p)
            df.loc[m, "s1_초과BH"] = bh_reject(p)
    df["s2_블록"] = np.isfinite(df["블록양비율"]) & np.isfinite(df["블록임계"]) & (df["블록양비율"] >= df["블록임계"])
    df["s3_절대순수익>0"] = np.isfinite(df["Q5절대순수익(트랜치,h일)"]) & (df["Q5절대순수익(트랜치,h일)"] > 0)
    df["판정"] = np.where(df["판정불가"], "판정불가",
                        np.where(df["s1_초과BH"] & df["s2_블록"] & df["s3_절대순수익>0"], "통과", "실패"))
    return df


def check_replication(new, ref):
    """new/ref 모두 (feature,h) 행. 결정적 열이 rtol 1e-9·atol 1e-12 안에서 일치해야 한다. 불일치 목록 반환."""
    a, b = new.set_index(["feature", "h"]), ref.set_index(["feature", "h"])
    if set(a.index) != set(b.index):
        return [("후보 집합 불일치", sorted(set(a.index) ^ set(b.index)))]
    a = a.loc[b.index]
    bad = []
    for c in REPL_COLS:
        if c not in a.columns or c not in b.columns:
            bad.append((c, "컬럼 없음"))
            continue
        ok = np.isclose(a[c].astype(float).values, b[c].astype(float).values, rtol=1e-9, atol=1e-12, equal_nan=True)
        if not ok.all():
            bad.append((c, int((~ok).sum())))
    return bad


def replicate_design(prep, ref_csv):
    new = eval_df(prep, G2.CANDS, null_dummy)
    ref = pd.read_csv(ref_csv, encoding="utf-8-sig")
    bad = check_replication(new, ref)
    assert not bad, f"설계구간 재현 실패 -> 근접 검증 중단: {bad[:12]}"
    return new


def yearly_E(prep, k, h, years):
    P = prep["h"][h]
    pool, q5, _ = select_masks(P["F"][k], C.FEATURE_DIRECTION[k])
    E = excess_days(q5, pool, P["T1"], 0)[0]
    yr = pd.DatetimeIndex(P["dates"]).year.values
    return {y: (float(np.nanmean(E[yr == y])) if np.isfinite(E[yr == y]).any() else np.nan) for y in years}


def run_near(prep, log=print):
    check_prereg(PREREG_NEAR)
    for h in HORIZONS:
        d = pd.DatetimeIndex(prep["h"][h]["dates"])
        assert d.min() >= NEAR[0] and d.max() <= NEAR[1], "근접 구간 밖 신호일"
    df = judge(eval_df(prep, NEAR_CANDS, null_all, log))
    df["이동량 수"] = [len(all_shifts(prep["h"][h]["T1"].shape[0])) for h in df["h"]]
    df = df.drop(columns=["E평균_2018-19", "E평균_2020-22"], errors="ignore")
    for y in (2023, 2024):
        df[f"E평균_{y}"] = [yearly_E(prep, k, h, (y,))[y] for k, h in zip(df["feature"], df["h"])]
    meta = {"후보": len(df), "통과": int((df["판정"] == "통과").sum()), "실패": int((df["판정"] == "실패").sum()),
            "판정불가": int((df["판정"] == "판정불가").sum()), "이동량 수": sorted(set(df["이동량 수"]))}
    return df, meta


def build_prep(paths, window, label=""):
    from .run_d3d4 import run
    from .gate2_prep import prepare_g2, dollar_volume_20
    with period(*window):
        D, U, parts, F, labels = run(*paths, verbose=False)
        assert D["calendar"].max() <= window[1], "데이터 상한 초과 적재"
        DV = dollar_volume_20(D["close"], D["volume"], D["outlier"])
        prep = prepare_g2(D, U, F, labels, DV, list(HORIZONS))
        info = {"label": label, "calendar": f"{D['calendar'].min().date()}~{D['calendar'].max().date()}",
                "신호일": {h: len(prep['h'][h]['dates']) for h in HORIZONS}}
    return prep, info


def print_report(df, meta, df_design, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 60)
    f = lambda d, cols: d[cols].round(4).to_string(index=False)
    out("=== [근접 2023~24] 판정 (Gate 2와 동일 규칙; 비용 왕복 0.206%) ===")
    out(f(df, ["feature", "h", "평가일", "평균E_gross(트랜치,h일)", "초과연환산(=E×252/h)", "p_E", "bh_q", "s1_초과BH",
               "블록포함", "블록양비율", "블록임계", "s2_블록", "Q5절대순수익(트랜치,h일)", "s3_절대순수익>0", "판정"]))
    out("\n=== 설계(2018~22) 대비 (평균 E, h일 기준 / 연환산) ===")
    d = df_design.set_index(["feature", "h"])
    cmp_ = df[["feature", "h"]].copy()
    cmp_["설계_E"] = [d.loc[(k, h), "평균E_gross(트랜치,h일)"] for k, h in zip(df["feature"], df["h"])]
    cmp_["근접_E"] = df["평균E_gross(트랜치,h일)"].values
    cmp_["설계_연환산"] = [d.loc[(k, h), "초과연환산(=E×252/h)"] for k, h in zip(df["feature"], df["h"])]
    cmp_["근접_연환산"] = df["초과연환산(=E×252/h)"].values
    cmp_["E평균_2023"] = df["E평균_2023"].values; cmp_["E평균_2024"] = df["E평균_2024"].values
    out(cmp_.round(4).to_string(index=False))
    out("\n=== 경로 성과 (비용 후) ===")
    out(f(df, ["feature", "h", "Q5_CAGR", "Q5_Sharpe", "Q5_MDD", "풀_CAGR", "풀_Sharpe", "풀_MDD"]))
    out("\n=== 거래 수·break-even(편도 bp)·거래대금 3분위 E ===")
    out(f(df, ["feature", "h", "Q5 거래 수(종목×트랜치)", "일평균 Q5 종목수", "Q5 제외 비율", "break_even_절대_bp",
               "break_even_초과_bp", "저분위_E", "중분위_E", "고분위_E"]))
    out(f"\n요약: 후보 {meta['후보']} | 통과 {meta['통과']} | 실패 {meta['실패']} | 판정불가 {meta['판정불가']} | null 이동량 수 {meta['이동량 수']}")
    out("통과: " + (", ".join(f"{r.feature}-h{r.h}" for r in df[df['판정'] == '통과'].itertuples()) or "없음"))
