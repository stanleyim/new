"""TL-006: LIQ Q5 롱 + 지수 베타 헤지(KOSPI200·KOSDAQ 일수익률 대용). 실데이터 실행은 Colab 전용.
β = 직전 120거래일(t-1까지) 비헤지 Q5 경로수익률의 OLS(상수항 포함, 두 지수 동시), 20거래일마다 갱신. 튜닝 파라미터 없음."""
import numpy as np
import pandas as pd
from . import config as C
from .gate2 import select_masks, daily_path, perf

BETA_WIN = 120
BETA_STEP = 20
IDX_NAMES = ("KOSPI200", "KOSDAQ")
CANDS_H = [("LIQ", 10), ("LIQ", 20)]


def load_idx_returns(pit_extra_dir, cal):
    """cal(DatetimeIndex, 마스터 거래일) 위 지수 종가→일수익률 (N×2, 열=IDX_NAMES). 결측·중복·이름 부재는 즉시 중단.
    첫 행은 이전 종가가 없어 0으로 두며(평가에서 미사용 assert), 이후 행은 직전 캘린더일 종가 대비."""
    cal = pd.DatetimeIndex(cal)
    frames = [pd.read_parquet(f"{pit_extra_dir}/idx_{y}.parquet", columns=["date", "index", "종가"])
              for y in range(cal[0].year, cal[-1].year + 1)]
    d = pd.concat(frames, ignore_index=True)
    assert not d.duplicated(["date", "index"]).any(), "idx (date,index) 중복"
    px = d.pivot(index="date", columns="index", values="종가")
    for n in IDX_NAMES:
        assert n in px.columns, f"지수 {n} 없음: {list(px.columns)}"
    px = px[list(IDX_NAMES)].reindex(cal)
    assert px.notna().all().all(), "마스터 거래일 중 지수 종가 결측"
    assert (px.values > 0).all(), "지수 종가 <= 0"
    r = np.array(px.pct_change().values, dtype=float)
    r[0] = 0.0
    return r


def hedge_eval(rq, ridx, a, b, years, L=BETA_WIN, step=BETA_STEP):
    """rq: 비헤지 Q5 일경로수익률(길이 N), ridx: N×2 지수 일수익률, [a,b]=모든 슬롯 활성 구간(gate2 perf와 동일).
    평가구간 s=a+L..b. 갱신일 u의 β는 rq/ridx[u-L:u](u 이전)만 사용, 적용은 [u,u+step)."""
    N = len(rq)
    s = a + L
    assert a >= 1 and s <= b < N, "평가구간 부족"
    beta = np.zeros((N, 2))
    prev = np.zeros(2)
    turnover = 0.0
    n_upd = 0
    for u in range(s, b + 1, step):
        X = np.column_stack([np.ones(L), ridx[u - L:u]])
        coef = np.linalg.lstsq(X, rq[u - L:u], rcond=None)[0]
        nb = coef[1:]
        turnover += float(np.abs(nb - prev).sum())
        prev = nb
        n_upd += 1
        beta[u:min(u + step, b + 1)] = nb
    rh = rq - (beta * ridx).sum(axis=1)
    sl = slice(s, b + 1)
    pu, ph = perf(rq, s, b), perf(rh, s, b)
    yrs = np.asarray(years)[sl]
    m_hi, m_lo = rh[sl][yrs <= 2019], rh[sl][yrs >= 2020]
    assert len(m_hi) > 0 and len(m_lo) > 0, "하위 구간 비어 있음"
    X = np.column_stack([np.ones(b + 1 - s), ridx[sl]])
    resid_beta = np.linalg.lstsq(X, rh[sl], rcond=None)[0][1:]
    yr = {}
    for y in np.unique(yrs):
        m = yrs == y
        yr[int(y)] = (float(np.prod(1 + rh[sl][m]) - 1), float(np.prod(1 + rq[sl][m]) - 1))
    pnl = float(rh[sl].sum())
    c1 = bool(rh[sl].mean() > 0)
    c2 = bool(abs(ph["MDD"]) < abs(pu["MDD"]))
    c3 = bool(m_hi.mean() > 0 and m_lo.mean() > 0)
    return {"평가일": b + 1 - s, "헤지후_일평균": float(rh[sl].mean()), "비헤지_일평균": float(rq[sl].mean()),
            "헤지후_CAGR": ph["CAGR"], "헤지후_Sharpe": ph["Sharpe"], "헤지후_MDD": ph["MDD"],
            "비헤지_CAGR": pu["CAGR"], "비헤지_Sharpe": pu["Sharpe"], "비헤지_MDD": pu["MDD"],
            "일평균_2018-19": float(m_hi.mean()), "일평균_2020-22": float(m_lo.mean()),
            "평균β_KOSPI200": float(beta[sl][:, 0].mean()), "평균β_KOSDAQ": float(beta[sl][:, 1].mean()),
            "사후잔차β_KOSPI200": float(resid_beta[0]), "사후잔차β_KOSDAQ": float(resid_beta[1]),
            "β갱신횟수": n_upd, "헤지회전합(Σ|Δβ|)": turnover,
            "헤지거래금액대비_breakeven_bp(보조)": pnl / turnover * 1e4 if turnover > 0 else float("nan"),
            "연도별(헤지후,비헤지)": yr,
            "조건1_일평균>0": c1, "조건2_MDD감소": c2, "조건3_두구간양": c3, "통과": bool(c1 and c2 and c3)}


def run_hedge(prep, ridx, years, gate2_csv=None, cands=None, log=print):
    cands = CANDS_H if cands is None else cands
    ref = pd.read_csv(gate2_csv).set_index(["feature", "h"]) if gate2_csv else None
    rows = []
    for k, h in cands:
        P = prep["h"][h]
        _, q5, _ = select_masks(P["F"][k], C.FEATURE_DIRECTION[k])
        fin = np.isfinite(P["T1"]); tpos = P["tpos"]
        rq = daily_path(q5 & fin, prep["O"], prep["Clf"], tpos, h)
        a, b = int(tpos[0]) + h, int(tpos[-1]) + 1
        pq = perf(rq, a, b)
        if ref is not None:      # 재현 선행조건: 기존 gate2 결과와 일치하지 않으면 중단(헤지 결과 미산출)
            for key, col in (("CAGR", "Q5_CAGR"), ("Sharpe", "Q5_Sharpe"), ("MDD", "Q5_MDD")):
                assert np.isclose(pq[key], ref.loc[(k, h), col], rtol=1e-9, atol=1e-12), \
                    f"재현 불일치 {k} h={h} {col}: {pq[key]} vs {ref.loc[(k, h), col]}"
            log(f"재현 OK {k} h={h} (Q5 CAGR·Sharpe·MDD가 gate2_results.csv와 일치)")
        else:
            log(f"경고: gate2_results.csv 없음 → {k} h={h} 재현 미확인")
        r = hedge_eval(rq, ridx, a, b, years)
        r.update({"feature": k, "h": h})
        rows.append(r)
    return pd.DataFrame(rows)


def print_report(df, out=print):
    for _, r in df.iterrows():
        out(f"\n[{r['feature']} h={r['h']}] 평가일 {r['평가일']} | 통과={r['통과']} (①일평균>0 {r['조건1_일평균>0']} ②MDD감소 {r['조건2_MDD감소']} ③두구간양 {r['조건3_두구간양']})")
        out(f"  비헤지 CAGR {r['비헤지_CAGR']:.4f} Sharpe {r['비헤지_Sharpe']:.3f} MDD {r['비헤지_MDD']:.4f} 일평균 {r['비헤지_일평균']:.6f}")
        out(f"  헤지후 CAGR {r['헤지후_CAGR']:.4f} Sharpe {r['헤지후_Sharpe']:.3f} MDD {r['헤지후_MDD']:.4f} 일평균 {r['헤지후_일평균']:.6f}")
        out(f"  일평균 2018-19 {r['일평균_2018-19']:.6f} | 2020-22 {r['일평균_2020-22']:.6f}")
        out(f"  평균β KOSPI200 {r['평균β_KOSPI200']:.3f} KOSDAQ {r['평균β_KOSDAQ']:.3f} | 사후잔차β {r['사후잔차β_KOSPI200']:.3f}/{r['사후잔차β_KOSDAQ']:.3f}")
        out(f"  β갱신 {r['β갱신횟수']}회, 회전합 {r['헤지회전합(Σ|Δβ|)']:.3f}, 헤지거래금액대비 break-even {r['헤지거래금액대비_breakeven_bp(보조)']:.1f}bp(보조)")
        out("  연도별 (헤지후, 비헤지): " + ", ".join(f"{y}: {v[0]:.3f}/{v[1]:.3f}" for y, v in r["연도별(헤지후,비헤지)"].items()))
