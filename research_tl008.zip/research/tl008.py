"""TL-008: LIQ 잔차 Feature(거래대금·가격 수준 노출 제거) Gate 1. 실데이터 실행은 Colab 전용.
LIQ_RESID(t,i) = 일별 횡단면에서 pct-rank(LIQ)를 [1, pct-rank(거래대금20일평균), pct-rank(종가)]에 OLS 회귀한 잔차.
대상 종목 = 그날 LIQ·거래대금·종가가 모두 유효(유한, >0)한 유니버스 종목, 유효 종목 < GATE1_MIN_N이면 그날 결측.
Gate 1 규칙·상수·permutation은 D5와 동일(d5_run 재사용). 회귀 변수·스케일은 결과 열람 후 변경하지 않는다."""
import contextlib
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from . import config as C
from . import d5_run as R

FEATURE = "LIQ_RESID"
DIRECTION = +1          # LIQ와 동일 방향(비유동 우위)


@contextlib.contextmanager
def direction_ctx():
    old = C.FEATURE_DIRECTION.get(FEATURE)
    C.FEATURE_DIRECTION[FEATURE] = DIRECTION
    try:
        yield
    finally:
        if old is None:
            C.FEATURE_DIRECTION.pop(FEATURE, None)
        else:
            C.FEATURE_DIRECTION[FEATURE] = old


def residualize(F, DV, CL, min_n=None):
    """F, DV, CL: T×M(같은 신호일·종목 정렬). 반환 RES(T×M, 비대상 NaN)와 일별 진단(DataFrame)."""
    min_n = C.GATE1_MIN_N if min_n is None else min_n
    assert F.shape == DV.shape == CL.shape, "입력 형상 불일치"
    T, M = F.shape
    RES = np.full((T, M), np.nan)
    rows = []
    for t in range(T):
        f, d, c = F[t], DV[t], CL[t]
        m = np.isfinite(f) & np.isfinite(d) & np.isfinite(c) & (d > 0) & (c > 0)
        n = int(m.sum())
        nf = int(np.isfinite(f).sum())
        if n < min_n:
            rows.append((t, nf, n, np.nan, np.nan, np.nan, np.nan, np.nan))
            continue
        y = rankdata(f[m]) / n
        a = rankdata(d[m]) / n
        b = rankdata(c[m]) / n
        X = np.column_stack([np.ones(n), a, b])
        e = y - X @ np.linalg.lstsq(X, y, rcond=None)[0]
        RES[t, m] = e
        r2 = 1.0 - e.var() / y.var()
        cc = lambda u, v: float(np.corrcoef(u, v)[0, 1]) if u.std() > 0 and v.std() > 0 else np.nan
        rows.append((t, nf, n, r2, cc(y, a), cc(y, b), cc(e, a), cc(e, b)))
    diag = pd.DataFrame(rows, columns=["row", "n_liq", "n_used", "r2", "corr_liq_dv", "corr_liq_close",
                                       "corr_res_dv", "corr_res_close"])
    return RES, diag


def build_res_prep(prep, DV, CL):
    """prep: gate1_prep.prepare 결과(h→{dates,block,T1,T2,T1_L1,F{LIQ,...}}). DV·CL: 캘린더×종목 DataFrame(열은 prep과 같은 순서).
    반환 h→같은 구조에 F={LIQ_RESID}만 있는 prep, 일별 진단 dict."""
    out, diags = {}, {}
    for h, P in prep.items():
        idx = P["dates"]
        dv, cl = DV.loc[idx].values, CL.loc[idx].values
        RES, diag = residualize(P["F"]["LIQ"], dv, cl)
        diag.index = idx
        out[h] = {k: P[k] for k in ("dates", "block", "T1", "T2", "T1_L1")}
        out[h]["F"] = {FEATURE: RES}
        diags[h] = diag
    return out, diags


def check_raw_liq(prep, gate1_csv):
    """선행 조건: 같은 prep에서 원본 LIQ IC 평균이 D5 gate1_results.csv(T1 행)와 일치해야 한다(atol 1e-12)."""
    ref = pd.read_csv(gate1_csv, encoding="utf-8-sig")
    ref = ref[(ref["feature"] == "LIQ") & (ref["target"] == "T1")].set_index("h")
    for h in sorted(prep):
        r1 = R.observed(prep[h], "LIQ")[0]
        assert abs(r1["ic_mean"] - ref.loc[h, "ic_mean"]) <= 1e-12, f"원본 LIQ IC 불일치 h={h}: {r1['ic_mean']} vs {ref.loc[h, 'ic_mean']}"


def exposure_check(diags, tol=1e-9):
    """잔차는 회귀 변수와 직교해야 한다(일별 순위 상관 절대값 <= tol)."""
    for h, d in diags.items():
        assert d["corr_res_dv"].abs().max() <= tol and d["corr_res_close"].abs().max() <= tol, f"직교성 위반 h={h}"


def summarize_diag(diags):
    rows = []
    for h, d in sorted(diags.items()):
        ok = d["n_used"] >= C.GATE1_MIN_N
        rows.append({"h": h, "신호일": len(d), "회귀 가능일": int(ok.sum()), "일평균 LIQ 유효 종목": float(d["n_liq"].mean()),
                     "일평균 회귀 종목": float(d.loc[ok, "n_used"].mean()), "회귀 종목/LIQ 유효 비율": float((d.loc[ok, "n_used"] / d.loc[ok, "n_liq"]).mean()),
                     "평균 R2": float(d["r2"].mean()), "평균 순위상관 LIQ-거래대금": float(d["corr_liq_dv"].mean()),
                     "평균 순위상관 LIQ-종가": float(d["corr_liq_close"].mean())})
    return pd.DataFrame(rows)


def run_tl008(prep, DV, CL, out_dir, gate1_csv, log=print):
    """①원본 LIQ 재현 ②잔차 구성·직교 확인 ③Gate 1(D5와 동일 규칙, family=LIQ_RESID 9개)."""
    with direction_ctx():
        check_raw_liq(prep, gate1_csv)
        log("원본 LIQ IC가 D5 gate1_results.csv와 일치 OK")
        prep_res, diags = build_res_prep(prep, DV, CL)
        exposure_check(diags)
        diag_df = summarize_diag(diags)
        log("잔차 직교성 OK (일별 순위상관 |.|<=1e-9)")
        res, meta = R.run_gate1(prep_res, out_dir, log=log)
    return res, meta, diag_df


def print_report(res, meta, diag_df, gate1_csv, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 50)
    out("=== 잔차 구성 진단(성과 무관) ==="); out(diag_df.round(4).to_string(index=False))
    df = res["df"]
    out("\\n=== LIQ_RESID Gate 1 (독립 IC 검정 3개, T1·T3 동일) ===")
    a = df[df["target"] == "T1"][["feature", "h", "ic_mean", "ic_t", "p_ic", "bh_q", "s1_IC", "agree", "agree_thr", "s2_agree"]]
    out(a.round(4).to_string(index=False))
    out("\\n=== 분위 단계 (stage2 통과분) ===")
    b = df[df["s2_agree"]][["feature", "h", "target", "spread", "spread_thr", "mono", "mono_thr", "s3_quant", "판정"]]
    out(b.round(4).to_string(index=False) if len(b) else "stage2 통과 없음")
    ref = pd.read_csv(gate1_csv, encoding="utf-8-sig")
    ref = ref[(ref["feature"] == "LIQ") & (ref["target"] == "T1")].set_index("h")
    cmp_ = a.set_index("h")[["ic_mean"]].rename(columns={"ic_mean": "잔차_IC"})
    cmp_["원본_IC"] = ref["ic_mean"]; cmp_["잔차/원본"] = cmp_["잔차_IC"] / cmp_["원본_IC"]
    out("\\n=== 원본 LIQ 대비 IC (정보용, 판정 불변) ==="); out(cmp_.round(4).to_string())
    out(f"\\n요약: trial {meta['trials']} | family {meta['families']} | 판정불가 {meta['n_판정불가']} | stage1 {meta['stage1_IC_BH']}/9 → stage2 {meta['stage2_agree']}/9 → stage3 {meta['stage3_quantile']}/9")
    ps = df[df["s3_quant"]]
    out("Gate 2 후보: " + (", ".join(f"{r.feature}-h{r.h}-{r.target}" for r in ps.itertuples()) if len(ps) else "없음"))
