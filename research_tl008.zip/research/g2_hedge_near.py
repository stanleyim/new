"""TL-007: LIQ Q5 롱 + 지수 베타 헤지의 2023~24 근접 검증. 실데이터 실행은 Colab 전용.
기존 모듈(g2_hedge·gate2·near_run)은 수정하지 않는다. 경로는 2018~2024 연속으로 계산하고 평가는 2023-01-02부터.
β는 TL-006과 동일 규칙(직전 120거래일 OLS·20거래일 갱신, 갱신일 u는 u 이전 데이터만 사용)이며 갱신 격자는 설계구간과 같다."""
import numpy as np
import pandas as pd
from . import config as C
from . import g2_hedge as H
from .gate2 import select_masks, daily_path, perf

EVAL_START = pd.Timestamp("2023-01-02")
EVAL_END = pd.Timestamp("2024-12-30")            # 데이터 상한(이후 미적재)
CANDS = [("LIQ", 10), ("LIQ", 20)]
# TL-006 결과 블록 기록값(소수 6자리/3자리/4자리 반올림). 설계구간 재현 확인용.
TL006_REF = {("LIQ", 10): dict(h_mean=0.000721, h_sharpe=1.872, h_mdd=-0.2092, u_mean=0.000818),
             ("LIQ", 20): dict(h_mean=0.000862, h_sharpe=2.260, h_mdd=-0.2119, u_mean=0.000989)}
TOL = dict(mean=6e-7, sharpe=6e-4, mdd=6e-5)


def q5_paths(prep, k, h):
    """비헤지 Q5·풀 일경로(gate2와 동일 규칙: 비용 0.206% 트랜치 전액). 반환 rq, rp, a, b."""
    P = prep["h"][h]
    pool, q5, _ = select_masks(P["F"][k], C.FEATURE_DIRECTION[k])
    fin = np.isfinite(P["T1"]); tpos = P["tpos"]
    rq = daily_path(q5 & fin, prep["O"], prep["Clf"], tpos, h)
    rp = daily_path(pool & fin, prep["O"], prep["Clf"], tpos, h)
    return rq, rp, int(tpos[0]) + h, int(tpos[-1]) + 1


def hedge_path(rq, ridx, a, b, L=H.BETA_WIN, step=H.BETA_STEP):
    """g2_hedge.hedge_eval과 같은 β 갱신. 반환 rh(N), beta(N×2), s(=a+L), 갱신일 목록 us, 갱신별 |Δβ| 합."""
    N = len(rq)
    s = a + L
    assert a >= 1 and s <= b < N, "평가구간 부족"
    beta = np.zeros((N, 2)); prev = np.zeros(2); us = []; dsum = []
    for u in range(s, b + 1, step):
        X = np.column_stack([np.ones(L), ridx[u - L:u]])
        nb = np.linalg.lstsq(X, rq[u - L:u], rcond=None)[0][1:]
        dsum.append(float(np.abs(nb - prev).sum())); us.append(u); prev = nb
        beta[u:min(u + step, b + 1)] = nb
    return rq - (beta * ridx).sum(axis=1), beta, s, np.array(us), np.array(dsum)


def eval_window(rq, rh, rp, beta, ridx, us, dsum, e0, e1, years):
    """[e0,e1] 평가. 판정: ①헤지후 일평균>0 ②헤지후 MDD 절대값<비헤지 ③2023·2024 각각 헤지후 일평균>0."""
    yrs = np.asarray(years)[e0:e1 + 1]
    assert (beta[e0:e1 + 1] != 0).any(axis=1).all(), "평가구간에 β 미설정일 존재"
    y_set = (2023, 2024)
    assert all((yrs == y).any() for y in y_set), "2023·2024 평가일 부재"
    h_, u_ = rh[e0:e1 + 1], rq[e0:e1 + 1]
    pu, ph = perf(rq, e0, e1), perf(rh, e0, e1)
    X = np.column_stack([np.ones(len(h_)), ridx[e0:e1 + 1]])
    resid = np.linalg.lstsq(X, h_, rcond=None)[0][1:]
    m = {y: float(h_[yrs == y].mean()) for y in y_set}
    mu = {y: float(u_[yrs == y].mean()) for y in y_set}
    yr = {y: (float(np.prod(1 + h_[yrs == y]) - 1), float(np.prod(1 + u_[yrs == y]) - 1)) for y in y_set}
    w = (us >= e0) & (us <= e1)
    c1 = bool(h_.mean() > 0); c2 = bool(abs(ph["MDD"]) < abs(pu["MDD"])); c3 = bool(all(m[y] > 0 for y in y_set))
    return {"평가일": e1 + 1 - e0, "헤지후_일평균": float(h_.mean()), "비헤지_일평균": float(u_.mean()),
            "풀_일평균": float(rp[e0:e1 + 1].mean()), "초과_일평균(비헤지Q5-풀)": float(u_.mean() - rp[e0:e1 + 1].mean()),
            "헤지후_CAGR": ph["CAGR"], "헤지후_Sharpe": ph["Sharpe"], "헤지후_MDD": ph["MDD"],
            "비헤지_CAGR": pu["CAGR"], "비헤지_Sharpe": pu["Sharpe"], "비헤지_MDD": pu["MDD"],
            "일평균_2023": m[2023], "일평균_2024": m[2024], "비헤지_일평균_2023": mu[2023], "비헤지_일평균_2024": mu[2024],
            "평균β_KOSPI200": float(beta[e0:e1 + 1][:, 0].mean()), "평균β_KOSDAQ": float(beta[e0:e1 + 1][:, 1].mean()),
            "사후잔차β_KOSPI200": float(resid[0]), "사후잔차β_KOSDAQ": float(resid[1]),
            "β갱신횟수(평가구간)": int(w.sum()), "헤지회전합(평가구간)": float(dsum[w].sum()),
            "연도별(헤지후,비헤지)": yr, "조건1_일평균>0": c1, "조건2_MDD감소": c2, "조건3_두해양": c3,
            "통과": bool(c1 and c2 and c3)}


def check_design_equal(rq_c, rh_c, rq_d, rh_d, b_d):
    """연속 경로(2018~2024)와 설계구간 경로가 [0, b_d]에서 일치해야 한다(rtol 1e-9, atol 1e-12). 불일치 목록 반환."""
    bad = []
    n = b_d + 1
    for name, x, y in (("비헤지경로", rq_c, rq_d), ("헤지후경로", rh_c, rh_d)):
        ok = np.isclose(x[:n], y[:n], rtol=1e-9, atol=1e-12)
        if not ok.all():
            bad.append((name, int((~ok).sum()), float(np.abs(x[:n] - y[:n]).max())))
    return bad


def design_stage(prep_d, cal_d, pit_dir, gate2_csv, check_tl006=True, log=print):
    """설계구간(2018~22): ①TL-006 코드(H.run_hedge)로 gate2_results.csv 재현 ②TL-006 결과 블록 기록값 일치 ③이 모듈의 헤지 경로가
    H.hedge_eval과 일치. 통과 시 연속 경로 비교용 경로를 반환. 불일치는 AssertionError(2023~24 결과 미산출)."""
    cal_d = pd.DatetimeIndex(cal_d)
    ridx = H.load_idx_returns(pit_dir, cal_d)
    years = cal_d.year.values
    res = H.run_hedge(prep_d, ridx, years, gate2_csv=gate2_csv, cands=CANDS, log=log).set_index(["feature", "h"])
    out = {}
    for k, h in CANDS:
        r = res.loc[(k, h)]
        if check_tl006:
            ref = TL006_REF[(k, h)]
            assert abs(r["헤지후_일평균"] - ref["h_mean"]) <= TOL["mean"], f"TL-006 불일치 {k}{h} 헤지후 일평균 {r['헤지후_일평균']}"
            assert abs(r["비헤지_일평균"] - ref["u_mean"]) <= TOL["mean"], f"TL-006 불일치 {k}{h} 비헤지 일평균"
            assert abs(r["헤지후_Sharpe"] - ref["h_sharpe"]) <= TOL["sharpe"], f"TL-006 불일치 {k}{h} Sharpe"
            assert abs(r["헤지후_MDD"] - ref["h_mdd"]) <= TOL["mdd"], f"TL-006 불일치 {k}{h} MDD"
            log(f"TL-006 기록값 일치 OK {k} h={h}")
        rq, rp, a, b = q5_paths(prep_d, k, h)
        rh, beta, s, us, ds = hedge_path(rq, ridx, a, b)
        assert abs(float(rh[s:b + 1].mean()) - r["헤지후_일평균"]) < 1e-15 and abs(float(rq[s:b + 1].mean()) - r["비헤지_일평균"]) < 1e-15, \
            "hedge_path와 H.hedge_eval 불일치"
        out[(k, h)] = dict(rq=rq, rh=rh, a=a, b=b, design_res=r.to_dict())
    return out


def near_stage(prep_c, cal_c, cal_d, pit_dir, design, log=print):
    """연속(2018~2024) 경로로 2023~24 평가. 연속 경로가 설계구간 경로와 [0,b_d]에서 일치해야만 평가 결과를 산출."""
    cal_c, cal_d = pd.DatetimeIndex(cal_c), pd.DatetimeIndex(cal_d)
    assert cal_c.max() <= EVAL_END, "데이터 상한 초과"
    assert (cal_c[:len(cal_d)] == cal_d).all(), "연속 캘린더가 설계 캘린더를 접두로 포함하지 않음"
    ridx = H.load_idx_returns(pit_dir, cal_c)
    years = cal_c.year.values
    e0 = int(cal_c.searchsorted(EVAL_START))
    assert cal_c[e0] >= EVAL_START and e0 > 0
    rows = []
    for k, h in CANDS:
        d = design[(k, h)]
        rq, rp, a, b = q5_paths(prep_c, k, h)
        assert a == d["a"], "첫 활성일 불일치(설계 vs 연속)"
        rh, beta, s, us, ds = hedge_path(rq, ridx, a, b)
        bad = check_design_equal(rq, rh, d["rq"], d["rh"], d["b"])
        assert not bad, f"설계구간 경로 재현 실패 -> 2023~24 결과 미산출: {k} h={h} {bad}"
        log(f"연속경로=설계경로 일치 OK {k} h={h} (일 0..{d['b']})")
        assert s <= e0 <= b, "평가 시작일이 β 가용·활성 구간 밖"
        r = eval_window(rq, rh, rp, beta, ridx, us, ds, e0, b, years)
        r.update({"feature": k, "h": h, "평가시작": str(cal_c[e0].date()), "평가종료": str(cal_c[b].date())})
        dr = d["design_res"]
        r.update({"설계_헤지후_일평균(TL-006)": dr["헤지후_일평균"], "설계_비헤지_일평균(TL-006)": dr["비헤지_일평균"],
                  "설계_헤지후_Sharpe": dr["헤지후_Sharpe"], "설계_헤지후_MDD": dr["헤지후_MDD"]})
        rows.append(r)
    return pd.DataFrame(rows)


def build_cont(paths, window, label=""):
    """near_run.build_prep과 같은 적재, 캘린더도 반환."""
    from . import near_run as N
    from .run_d3d4 import run
    from .gate2_prep import prepare_g2, dollar_volume_20
    with N.period(*window):
        D, U, parts, F, labels = run(*paths, verbose=False)
        assert D["calendar"].max() <= window[1], "데이터 상한 초과 적재"
        DV = dollar_volume_20(D["close"], D["volume"], D["outlier"])
        prep = prepare_g2(D, U, F, labels, DV, list(N.HORIZONS))
        cal = pd.DatetimeIndex(D["open"].index)
    return prep, cal, {"label": label, "calendar": f"{cal.min().date()}~{cal.max().date()}"}


def print_report(df, out=print):
    for _, r in df.iterrows():
        out(f"\n[{r['feature']} h={r['h']}] 평가 {r['평가시작']}~{r['평가종료']} ({r['평가일']}일) | 통과={r['통과']} "
            f"(①일평균>0 {r['조건1_일평균>0']} ②MDD감소 {r['조건2_MDD감소']} ③두해양 {r['조건3_두해양']})")
        out(f"  비헤지 CAGR {r['비헤지_CAGR']:.4f} Sharpe {r['비헤지_Sharpe']:.3f} MDD {r['비헤지_MDD']:.4f} 일평균 {r['비헤지_일평균']:.6f} | 풀 일평균 {r['풀_일평균']:.6f} 초과 {r['초과_일평균(비헤지Q5-풀)']:.6f}")
        out(f"  헤지후 CAGR {r['헤지후_CAGR']:.4f} Sharpe {r['헤지후_Sharpe']:.3f} MDD {r['헤지후_MDD']:.4f} 일평균 {r['헤지후_일평균']:.6f}")
        out(f"  일평균 2023 {r['일평균_2023']:.6f} (비헤지 {r['비헤지_일평균_2023']:.6f}) | 2024 {r['일평균_2024']:.6f} (비헤지 {r['비헤지_일평균_2024']:.6f})")
        out(f"  평균β KOSPI200 {r['평균β_KOSPI200']:.3f} KOSDAQ {r['평균β_KOSDAQ']:.3f} | 사후잔차β {r['사후잔차β_KOSPI200']:.3f}/{r['사후잔차β_KOSDAQ']:.3f} | β갱신 {r['β갱신횟수(평가구간)']}회 회전합 {r['헤지회전합(평가구간)']:.3f}")
        out("  연도별 (헤지후/비헤지): " + ", ".join(f"{y}: {v[0]:.3f}/{v[1]:.3f}" for y, v in r["연도별(헤지후,비헤지)"].items()))
        out(f"  설계(TL-006) 대비 일평균: 헤지후 {r['설계_헤지후_일평균(TL-006)']:.6f} → {r['헤지후_일평균']:.6f} | 비헤지 {r['설계_비헤지_일평균(TL-006)']:.6f} → {r['비헤지_일평균']:.6f}")
