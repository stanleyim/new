"""D5 입력 준비(Target 결과를 배열화). Feature 계산 모듈은 import하지 않는다."""
import numpy as np
from .gate1 import block_ids
from .targets import targets_from


def prepare(D, U, F, labels):
    """신호일 행렬 준비: 라벨 날짜 기준으로 Feature(유니버스 마스크)·Target(T1/T2, L2) 배열화."""
    prep = {}
    for h, res in labels.items():
        idx = res["t1"].index
        tg = targets_from(res, "L2")
        prep[h] = {"dates": idx, "block": block_ids(idx), "T1": tg["T1"].values, "T2": tg["T2"].values,
                   "F": {k: f.where(U).loc[idx, res["t1"].columns].values for k, f in F.items()},
                   "T1_L1": targets_from(res, "L1")["T1"].values}
    return prep
