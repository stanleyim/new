"""D3·D4 통합 실행 + 진단 출력(성과·수익률 통계·Feature-Target 관계는 계산·출력하지 않음)."""
import numpy as np
import pandas as pd
from . import config as C
from .data_loader import load_all
from .universe import build_universe
from .features import compute_features
from .targets import build_labels, targets_from, STATUS_NAMES, OK, L2


def _yr(idx):
    return pd.Index(idx.year, name="연도")


def run(ohlcv_path, kis_dir, sector_glob, verbose=True):
    D = load_all(ohlcv_path, kis_dir, sector_glob)
    cal = D["calendar"]
    U, parts = build_universe(D["valid"], D["names"], cal)
    F = compute_features(D["close"], D["volume"], D["outlier"])
    cont = D["meta"]["continues"].fillna(False).values
    labels = {h: build_labels(D["open"], D["close"], D["valid"], D["outlier"], U, cont, h) for h in C.HORIZONS}
    if verbose:
        report(D, U, parts, F, labels)
    return D, U, parts, F, labels


def report(D, U, parts, F, labels):
    pd.set_option("display.width", 220); pd.set_option("display.max_rows", 200)
    meta, cal, info = D["meta"], D["calendar"], D["info"]
    sig = (cal >= C.SIGNAL_START) & (cal <= C.SIGNAL_END)
    print("=== [1] 로드 ===")
    print(f"캘린더 {cal.min().date()}~{cal.max().date()} ({len(cal)}일) | 신호일 구간 {int(sig.sum())}일")
    print(f"로스터 {info['roster_size']} | 패널 종목 {D['close'].shape[1]} | 로스터 밖 종목 {len(info['tickers_not_in_roster'])} {info['tickers_not_in_roster'][:10]}")
    print(f"캘린더 밖 행 폐기 {info['rows_off_calendar_dropped']} | 그룹별 종목 수:", meta['group'].value_counts().to_dict(),
          "| SIGNAL_END 이후 거래 지속(continues):", int(meta['continues'].sum()))
    print("유효거래일(V) 비율:", round(float(D['valid'].values.mean()), 4), "| 이상치 행 반영:", int(D['outlier'].values.sum()))

    print("\n=== [2] 유니버스 (신호일 구간, 일평균 종목 수) ===")
    Us, V = U[sig], D["valid"][sig]
    elig, win_ok = parts["eligible"][sig], parts["win_ok"][sig]
    tb = pd.DataFrame({
        "유니버스(U)": Us.sum(axis=1),
        "스팩 제외": parts["spac"][sig].sum(axis=1),
        "스팩이름미상": parts["spac_unknown"][sig].sum(axis=1),
        "유효거래일 중 15/20 미달": (V & elig & ~win_ok).sum(axis=1),
        "T일 무효(적격 종목)": (~V & elig).sum(axis=1),
    })
    print(tb.groupby(_yr(tb.index)).mean().round(1))
    print("우선주(ticker 끝글자≠0) 컬럼 수:", int(parts["pref"].iloc[0].sum()))
    g = D["meta"]["group"]
    print("그룹별 U 일평균:", {k: round(float(Us.loc[:, g[g == k].index].sum(axis=1).mean()), 1) for k in ["439", "A", "B"]})

    print("\n=== [3] 라벨 진단 (신호일×종목 건수; 성과 통계 없음) ===")
    for h, res in labels_iter(labels):
        st = res["status"]
        inU = (st != 5)
        row = {STATUS_NAMES[k]: int((st == k).values.sum()) for k in range(6)}
        row["유효(L2기준)"] = row["OK"] + row["L2청산"]
        row["유효(L1기준)"] = row["OK"]
        print(f"h={h}: 신호일 {len(st)}일 |", row)
        yy = pd.DataFrame({STATUS_NAMES[k]: (st == k).sum(axis=1) for k in (0, 1, 2, 3, 4)})
        print(yy.groupby(_yr(yy.index)).sum())
        gg = {}
        for k in ["439", "A", "B"]:
            cols = g[g == k].index.intersection(st.columns)
            s2 = st[cols]
            gg[k] = {STATUS_NAMES[q]: int((s2 == q).values.sum()) for q in (0, 1, 2, 3, 4)}
        print("그룹별:", gg)
        tg = targets_from(res, "L2")
        nvalid = tg["T1"].notna().sum(axis=1)
        print(f"일별 유효 라벨 수(L2): min {int(nvalid.min())} / 중앙 {int(nvalid.median())} / max {int(nvalid.max())} | 유효 라벨 50 미만인 날 {int((nvalid < 50).sum())}")

    print("\n=== [4] Feature 결측·동률 진단 (U 종목 대상, 값-수익률 관계 없음) ===")
    rows = {}
    for k, f in F.items():
        fu = f[sig].where(U[sig])
        n = U[sig].values.sum()
        nan_rate = 1 - fu.notna().values.sum() / n
        distinct = fu.apply(lambda r: r.dropna().nunique(), axis=1)
        valid_n = fu.notna().sum(axis=1)
        rows[k] = {"방향": C.FEATURE_DIRECTION[k], "U대비 NaN율": round(float(nan_rate), 4),
                   "일별 유효종목 중앙": int(valid_n.median()), "일별 유효종목 최소": int(valid_n.min()),
                   "일별 고유값수 중앙": int(distinct.median())}
    print(pd.DataFrame(rows).T)
    print("\n연도별 NaN율(U 대비):")
    yr = {}
    for k, f in F.items():
        fu = f[sig].where(U[sig]); un = U[sig]
        yr[k] = (1 - fu.notna().groupby(_yr(fu.index)).sum().sum(axis=1) / un.groupby(_yr(un.index)).sum().sum(axis=1)).round(4)
    print(pd.DataFrame(yr))
    print("그룹별 NaN율(U 대비):")
    gr = {}
    for k, f in F.items():
        fu = f[sig].where(U[sig]); un = U[sig]
        gr[k] = {q: round(float(1 - fu[g[g == q].index].notna().values.sum() / max(un[g[g == q].index].values.sum(), 1)), 4) for q in ["439", "A", "B"]}
    print(pd.DataFrame(gr))


def labels_iter(labels):
    return sorted(labels.items())
