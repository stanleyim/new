"""일별 유니버스: 로스터 고정, 우선주(ticker 끝글자≠0)·스팩(T 이전 최신 월 스냅샷 종목명) 제외,
유효거래일(T일 open>0·volume>0) + 직전 20거래일(T 포함) 중 15일 이상 유효."""
import numpy as np
import pandas as pd
from . import config as C


def build_universe(V, names, calendar):
    tickers = list(V.columns)
    pref = np.array([not t.endswith("0") for t in tickers])
    nm = names.copy()
    nm["flag"] = nm["종목명"].astype(str).str.contains("스팩").astype(float)
    S = nm.pivot_table(index="date", columns="ticker", values="flag", aggfunc="max")
    S = S.reindex(columns=tickers).sort_index().ffill()          # 과거 이름만 이월
    snap = S.index.values
    pos = np.searchsorted(snap, calendar.values, side="left") - 1  # 엄격히 T 이전 스냅샷
    have = pos >= 0
    arr = np.full((len(calendar), len(tickers)), np.nan)
    if len(snap):
        arr[have] = S.values[pos[have]]
    spac = pd.DataFrame(arr == 1.0, index=calendar, columns=tickers)
    spac_unknown = pd.DataFrame(np.isnan(arr), index=calendar, columns=tickers)
    prefdf = pd.DataFrame(np.tile(pref, (len(calendar), 1)), index=calendar, columns=tickers)
    eligible = ~prefdf & ~spac
    cnt = V.astype(float).rolling(C.UNIV_WINDOW, min_periods=1).sum()
    win_ok = cnt >= C.UNIV_MIN_VALID
    U = eligible & V & win_ok
    parts = {"pref": prefdf, "spac": spac, "spac_unknown": spac_unknown,
             "eligible": eligible, "win_ok": win_ok}
    return U, parts
