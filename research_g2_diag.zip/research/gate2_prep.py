"""Gate 2 입력 준비. gate1_prep처럼 Target 결과를 배열화한다(Feature 계산 모듈은 import하지 않음)."""
import numpy as np
from .gate1 import block_ids
from .targets import targets_from


def prepare_g2(D, U, F, labels, DV, horizons):
    cal = D["open"].index
    out = {"O": D["open"].values, "Clf": D["close"].ffill().values, "h": {}}
    for h in sorted(horizons):
        res = labels[h]
        idx = res["t1"].index; cols = res["t1"].columns
        assert list(cols) == list(D["open"].columns), "라벨 열과 패널 열 불일치"
        tpos = cal.get_indexer(idx)
        assert (tpos >= 0).all() and (np.diff(tpos) == 1).all(), "신호일이 캘린더에서 연속이 아님"
        tg = targets_from(res, "L2")
        out["h"][h] = {"dates": idx, "block": block_ids(idx), "tpos": tpos,
                       "T1": tg["T1"].values, "status": res["status"].values,
                       "DV": DV.loc[idx, cols].values,
                       "F": {k: f.where(U).loc[idx, cols].values for k, f in F.items()}}
    return out


def dollar_volume_20(close, volume, outlier):
    """거래대금 20일 평균(종가×거래량, T 포함 후행, 유효 15일 이상). 이상치 행 NaN. 분위 진단 전용(선택·판정 미사용)."""
    from . import config as C
    return (close.mask(outlier) * volume).rolling(C.UNIV_WINDOW, min_periods=C.UNIV_MIN_VALID).mean()
