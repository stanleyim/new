"""D4 가격·거래량 Feature 6개. 입력은 close/volume/outlier뿐이며 Target(targets)을 import하지 않는다.
모든 연산은 시점 t 이전(포함) 데이터만 사용(shift>=0, 후행 rolling)."""
import numpy as np
import pandas as pd
from . import config as C


def _mp(w):
    return int(np.ceil(C.MIN_VALID_FRAC * w))


def compute_features(close, volume, outlier):
    c, v = close, volume
    r = c / c.shift(1) - 1
    F = {}
    F["REV"] = c / c.shift(5) - 1                                        # 5일 수익률
    F["MOM"] = c.shift(5) / c.shift(60) - 1                              # t-60~t-5 수익률
    F["RISK"] = r.rolling(60, min_periods=_mp(60)).std()                 # 60일 일수익률 표준편차
    F["ATTN"] = v.rolling(5, min_periods=_mp(5)).mean() / v.rolling(60, min_periods=_mp(60)).mean()
    F["LIQ"] = (r.abs() / (c * v)).rolling(20, min_periods=_mp(20)).mean()  # Amihud형, 거래대금=종가×거래량
    F["ANCH"] = c / c.rolling(120, min_periods=_mp(120)).max()           # 종가 / T 포함 120거래일 최고 종가
    o = outlier.astype(float)
    for k in F:
        bad = o.rolling(C.FEATURE_SPAN[k], min_periods=1).sum() > 0
        F[k] = F[k].replace([np.inf, -np.inf], np.nan).mask(bad)
    return F
