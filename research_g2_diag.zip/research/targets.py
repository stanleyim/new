"""D3 Target 라벨. Feature(features)를 import하지 않는다.
진입 T+1 시가, 청산 T+h 종가(L2: 이후 거래 없는 종목은 마지막 volume>0일 종가). 비용 제외 gross."""
import numpy as np
import pandas as pd
from . import config as C

OK, L2, TEMP_HALT, ENTRY_FAIL, OUTLIER, NOT_UNIV = 0, 1, 2, 3, 4, 5
STATUS_NAMES = {OK: "OK", L2: "L2청산", TEMP_HALT: "일시정지NaN", ENTRY_FAIL: "진입불가",
                OUTLIER: "이상치NaN", NOT_UNIV: "유니버스외"}


def last_valid_info(V, close):
    Vv = V.values
    N = Vv.shape[0]
    anyv = Vv.any(axis=0)
    last_idx = np.where(anyv, N - 1 - np.argmax(Vv[::-1], axis=0), -1)
    cl = close.values
    last_close = np.where(anyv, cl[np.clip(last_idx, 0, N - 1), np.arange(Vv.shape[1])], np.nan)
    return last_idx, last_close


def build_labels(open_, close_, valid, outlier, U, continues, h):
    dates = open_.index
    assert dates.max() <= C.SIGNAL_END, "SIGNAL_END 이후 날짜 차단"
    N, M = open_.shape
    sig = np.where((dates >= C.SIGNAL_START) & (dates <= C.SIGNAL_END))[0]
    t = sig[sig + h <= N - 1]                       # 라벨 종료가 구간을 넘는 신호일 제외
    last_idx, last_close = last_valid_info(valid, close_)
    O, Cl = open_.values, close_.values
    entry = O[t + 1]
    cdir = Cl[t + h]
    ok_entry = np.isfinite(entry)
    ok_exit = np.isfinite(cdir)
    cs = np.vstack([np.zeros((1, M), dtype=np.int32), np.cumsum(outlier.values.astype(np.int32), axis=0)])
    outl_cnt = cs[t + h + 1] - cs[t + 1]            # 라벨 윈도우 T+1..T+h
    lv = last_idx[None, :]
    cont = np.asarray(continues, dtype=bool)[None, :]
    l2 = (~ok_exit) & (~cont) & (lv >= (t + 1)[:, None]) & (lv < (t + h)[:, None])
    inU = U.values[t]
    status = np.select([~inU, ~ok_entry, outl_cnt > 0, ok_exit, l2],
                       [NOT_UNIV, ENTRY_FAIL, OUTLIER, OK, L2], default=TEMP_HALT).astype(np.int8)
    exit_px = np.where(ok_exit, cdir, last_close[None, :])
    with np.errstate(invalid="ignore", divide="ignore"):
        t1 = exit_px / entry - 1
    t1 = np.where((status == OK) | (status == L2), t1, np.nan)
    idx = dates[t]
    return {"status": pd.DataFrame(status, index=idx, columns=open_.columns),
            "t1": pd.DataFrame(t1, index=idx, columns=open_.columns), "h": h}


def targets_from(res, variant="L2"):
    """variant L2(기본): OK+L2청산 사용 / L1(민감도): L2 해당 라벨을 NaN."""
    st = res["status"]
    ok = (st == OK) if variant == "L1" else ((st == OK) | (st == L2))
    T1 = res["t1"].where(ok)
    T2 = T1.rank(axis=1, pct=True)
    T3 = T1.sub(T1.mean(axis=1), axis=0)
    return {"T1": T1, "T2": T2, "T3": T3}
