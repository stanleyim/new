"""D5-0: 판정 불가 메타 선계산(마스크만 사용, 수익률 값 미사용) + 속도 측정(통계 값 미출력)."""
import time
import numpy as np
import pandas as pd
from . import config as C
from .gate1 import daily_stats, summarize, make_shifts


def eligibility_meta(prep):
    rows = []
    for h, P in sorted(prep.items()):
        Ymask = np.where(np.isfinite(P["T1"]), 0.0, np.nan)       # 값 제거: 유효 여부만
        n_rows = Ymask.shape[0]
        for k, F in P["F"].items():
            ic, qm, nv = daily_stats(F, Ymask, want_ic=False)
            elig = np.isfinite(qm[:, 0])
            days_ok = nv >= C.GATE1_MIN_N
            blk = P["block"]
            per_blk = {b: int(days_ok[blk == b].sum()) for b in np.unique(blk)}
            incl = sum(v >= C.BLOCK_MIN_DAYS for v in per_blk.values())
            rows.append({"feature": k, "h": h, "신호일": n_rows, "n>=50 일수": int(days_ok.sum()),
                         "평가가능일(5분위 충족)": int(elig.sum()), "평가가능 비율": round(elig.sum() / n_rows, 4),
                         "교집합 종목수 중앙": int(np.median(nv[days_ok])) if days_ok.any() else 0,
                         "블록 포함/전체": f"{incl}/{len(per_blk)}", "블록별 유효일 최소": min(per_blk.values()),
                         "판정 불가?": bool(elig.sum() / n_rows < C.MIN_ELIG_FRAC)})
    return pd.DataFrame(rows)


def timing(prep, n_shifts=3):
    """shift 몇 개로 계산 시간만 측정(결과 값은 버림)."""
    rows = []
    for h, P in sorted(prep.items()):
        shifts = make_shifts(P["T1"].shape[0], h)[:n_shifts]
        for k, F in P["F"].items():
            t0 = time.time()
            for s in shifts:
                ic, qm, _ = daily_stats(F, np.roll(P["T1"], int(s), axis=0), True)
                summarize(ic, qm, P["block"], 1.0, F.shape[0])
            t1 = (time.time() - t0) / len(shifts)
            t0 = time.time()
            for s in shifts:
                daily_stats(F, np.roll(P["T2"], int(s), axis=0), False)
            t2 = (time.time() - t0) / len(shifts)
            rows.append({"feature": k, "h": h, "T1 1회(초)": round(t1, 2), "T2 스프레드 1회(초)": round(t2, 2)})
    df = pd.DataFrame(rows)
    est = (df["T1 1회(초)"].sum() + df["T2 스프레드 1회(초)"].sum()) * C.K_SHIFTS
    return df, est
