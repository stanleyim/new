"""Gate 2 코어(비용 포함 롱온리 Q5 트랜치 포트폴리오). features/targets를 import하지 않는다.
선택(Q5·풀)은 T 시점 Feature와 유니버스만으로 정하고 라벨 유효 여부는 선택에 쓰지 않는다(수익률 계산 단계에서만 NaN 제외).
통계량 E_t = (Q5 동일가중 T1 평균) - (풀 동일가중 T1 평균). null = Feature 고정, T1 패널을 날짜축으로 순환 이동."""
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from . import config as C

try:
    from numba import njit
    HAVE_NUMBA = True
except Exception:  # pragma: no cover
    HAVE_NUMBA = False

    def njit(*a, **k):
        def deco(f):
            return f
        return deco if not (len(a) == 1 and callable(a[0])) else a[0]


def select_masks(F, direction, min_n=None):
    """F: T×M Feature(유니버스 밖 NaN). 방향 정렬 점수 direction*F의 일별 5분위(평균순위, 동률 같은 분위,
    q=ceil(5*rank/n) 정수 연산). 반환 pool(T×M bool), q5(T×M bool), day_ok(T bool: 유효 종목 >= min_n)."""
    min_n = C.GATE1_MIN_N if min_n is None else min_n
    T, M = F.shape
    pool = np.zeros((T, M), bool); q5 = np.zeros((T, M), bool); day_ok = np.zeros(T, bool)
    S = direction * F
    for t in range(T):
        m = np.isfinite(S[t]); n = int(m.sum())
        if n < min_n:
            continue
        day_ok[t] = True
        rf = rankdata(S[t][m])
        r2 = np.rint(2 * rf).astype(np.int64)
        q = np.clip((5 * r2 + 2 * n - 1) // (2 * n), 1, 5)
        pool[t] = m
        sel = np.zeros(M, bool); sel[np.where(m)[0][q == 5]] = True
        q5[t] = sel
    return pool, q5, day_ok


@njit(cache=True)
def excess_days_nb(Q, P, Y, shift):
    """Y를 날짜축으로 shift만큼 순환 이동(np.roll(Y, shift, axis=0)과 동일 행 대응)한 뒤 일별 E_t.
    반환 E, 평균Q, 평균P, Q 유효 수."""
    T, M = Y.shape
    E = np.full(T, np.nan); mq = np.full(T, np.nan); mp = np.full(T, np.nan)
    nq = np.zeros(T, np.int64)
    for t in range(T):
        src = t - shift
        if src < 0:
            src += T
        sq = 0.0; cq = 0; sp = 0.0; cp = 0
        for j in range(M):
            if P[t, j]:
                y = Y[src, j]
                if np.isfinite(y):
                    sp += y; cp += 1
                    if Q[t, j]:
                        sq += y; cq += 1
        if cq > 0 and cp > 0:
            E[t] = sq / cq - sp / cp; mq[t] = sq / cq; mp[t] = sp / cp; nq[t] = cq
    return E, mq, mp, nq


def excess_days_ref(Q, P, Y, shift):
    """순수 numpy 참조 구현(테스트용). np.roll 사용."""
    Yr = np.roll(Y, int(shift), axis=0)
    T = Y.shape[0]
    E = np.full(T, np.nan); mq = np.full(T, np.nan); mp = np.full(T, np.nan); nq = np.zeros(T, np.int64)
    for t in range(T):
        pm = P[t] & np.isfinite(Yr[t]); qm = Q[t] & np.isfinite(Yr[t])
        if qm.sum() > 0 and pm.sum() > 0:
            mq[t] = Yr[t][qm].mean(); mp[t] = Yr[t][pm].mean(); E[t] = mq[t] - mp[t]; nq[t] = int(qm.sum())
    return E, mq, mp, nq


def excess_days(Q, P, Y, shift):
    fn = excess_days_nb if HAVE_NUMBA else excess_days_ref
    return fn(np.ascontiguousarray(Q), np.ascontiguousarray(P), np.ascontiguousarray(Y), int(shift))


def summarize_excess(E, block):
    """E: 일별 초과(NaN=해당일 없음). 반환 dict: n_days, mean_E, 블록 양(+) 비율(유효일 >= BLOCK_MIN_DAYS 블록만)."""
    ok = np.isfinite(E)
    out = {"n_days": int(ok.sum()), "mean_E": float(E[ok].mean()) if ok.any() else np.nan}
    pos, incl = 0, 0
    for b in np.unique(block):
        sel = (block == b) & ok
        if sel.sum() >= C.BLOCK_MIN_DAYS:
            incl += 1
            pos += int(E[sel].mean() > 0)
    out["blocks_incl"] = incl
    out["block_pos"] = pos / incl if incl else np.nan
    return out


def null_excess(Q, P, Y, shifts, block):
    """K×2 [mean_E, block_pos]."""
    out = np.full((len(shifts), 2), np.nan)
    for i, s in enumerate(shifts):
        E = excess_days(Q, P, Y, s)[0]
        r = summarize_excess(E, block)
        out[i] = [r["mean_E"], r["block_pos"]]
    return out


def daily_path(W, O, Clf, tpos, h, cost=None):
    """트랜치 일별 경로. W: 신호일×종목 bool(선택 ∧ T1 유효). 신호일 t마다 T+1 시가 동일가중 진입,
    T+k 종가(휴장·무거래는 직전 유효 종가 이월=ffill, L2 청산가와 동일)로 평가, T+h 종가 청산 후 왕복 비용 전액 부과.
    슬롯 h개(각 1/h), 일 수익률 = (1/h)*Σ 활성 슬롯 일수익률(빈 슬롯=현금 0). 반환 길이 N의 일별 수익률."""
    cost = C.G2_COST_RT if cost is None else cost
    N = O.shape[0]
    cnt = W.sum(axis=1); ex = cnt > 0
    denom = np.where(ex, cnt, 1)
    E0 = O[tpos + 1]
    ret = np.zeros(N)
    Vprev = np.ones(len(tpos))
    for k in range(1, h + 1):
        with np.errstate(invalid="ignore", divide="ignore"):
            R = np.where(W, Clf[tpos + k] / E0, 0.0)
        V = R.sum(axis=1) / denom
        if k == h:
            V = V * (1.0 - cost)
        with np.errstate(invalid="ignore", divide="ignore"):
            dr = np.where(ex, V / Vprev - 1.0, 0.0)
        ret[tpos + k] += dr / h
        Vprev = np.where(ex, V, 1.0)
    assert np.isfinite(ret).all(), "경로에 NaN(유효 선택 종목의 중간 가격 결측)"
    return ret


def perf(ret, start, end):
    """ret[start:end+1] 구간(모든 슬롯 활성 구간) 성과. CAGR·Sharpe(일, √252)·MDD."""
    r = ret[start:end + 1]
    eq = np.cumprod(1.0 + r)
    n = len(r)
    sd = r.std(ddof=1)
    return {"CAGR": float(eq[-1] ** (C.G2_ANN_DAYS / n) - 1.0),
            "Sharpe": float(r.mean() / sd * np.sqrt(C.G2_ANN_DAYS)) if sd > 0 else np.nan,
            "MDD": float((eq / np.maximum.accumulate(eq) - 1.0).min()), "n_days": n}


def tercile_pool(P, DV):
    """일별 풀(P) 내 DV(20일평균 거래대금) 3분위(평균순위 ceil(3*rank/n)): 1 저, 3 고. 0=해당 없음. 라벨 미사용."""
    T, M = P.shape
    TL = np.zeros((T, M), np.int8)
    for t in range(T):
        m = P[t] & np.isfinite(DV[t]); n = int(m.sum())
        if n < 3:
            continue
        TL[t][m] = np.clip(np.ceil(3.0 * rankdata(DV[t][m]) / n), 1, 3).astype(np.int8)
    return TL
