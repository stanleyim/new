"""D5 Gate 1 코어. 일별 교집합 Spearman IC·5분위 평균, 요약 통계, 순환 이동 permutation, BH.
Feature 고정, Target 패널만 날짜축으로 순환 이동. 이 모듈은 features/targets를 import하지 않는다."""
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from . import config as C

try:
    from numba import njit
    HAVE_NUMBA = True
except Exception:  # pragma: no cover
    HAVE_NUMBA = False

    def njit(*a, **k):
        def deco(f):
            return f
        return deco if not (len(a) == 1 and callable(a[0])) else a[0]


@njit(cache=True)
def _avg_rank(x, out):
    n = x.shape[0]
    idx = np.argsort(x)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and x[idx[j + 1]] == x[idx[i]]:
            j += 1
        r = 0.5 * (i + j) + 1.0
        for k in range(i, j + 1):
            out[idx[k]] = r
        i = j + 1


@njit(cache=True)
def daily_stats_nb(F, Y, min_n, want_ic):
    T, M = F.shape
    ic = np.full(T, np.nan)
    qm = np.full((T, 5), np.nan)
    nv = np.zeros(T, np.int64)
    fb = np.empty(M); yb = np.empty(M); rf = np.empty(M); ry = np.empty(M)
    for t in range(T):
        n = 0
        for j in range(M):
            a = F[t, j]; b = Y[t, j]
            if np.isfinite(a) and np.isfinite(b):
                fb[n] = a; yb[n] = b; n += 1
        nv[t] = n
        if n < min_n:
            continue
        _avg_rank(fb[:n], rf[:n])
        if want_ic:
            _avg_rank(yb[:n], ry[:n])
            mu = (n + 1) / 2.0
            sxy = 0.0; sxx = 0.0; syy = 0.0
            for k in range(n):
                dx = rf[k] - mu; dy = ry[k] - mu
                sxy += dx * dy; sxx += dx * dx; syy += dy * dy
            if sxx > 0 and syy > 0:
                ic[t] = sxy / np.sqrt(sxx * syy)
        cnt = np.zeros(5, np.int64); sm = np.zeros(5)
        for k in range(n):
            r2 = int(round(2.0 * rf[k]))
            q = (5 * r2 + 2 * n - 1) // (2 * n)      # ceil(5*rank/n), 정수 연산
            if q > 5: q = 5
            if q < 1: q = 1
            cnt[q - 1] += 1; sm[q - 1] += yb[k]
        ok = True
        for q in range(5):
            if cnt[q] == 0:
                ok = False
        if ok:
            for q in range(5):
                qm[t, q] = sm[q] / cnt[q]
    return ic, qm, nv


def daily_stats_ref(F, Y, min_n, want_ic):
    """순수 numpy/scipy 참조 구현(테스트용, 동일 정의)."""
    T = F.shape[0]
    ic = np.full(T, np.nan); qm = np.full((T, 5), np.nan); nv = np.zeros(T, np.int64)
    for t in range(T):
        m = np.isfinite(F[t]) & np.isfinite(Y[t]); n = int(m.sum()); nv[t] = n
        if n < min_n:
            continue
        f, y = F[t][m], Y[t][m]
        rf = rankdata(f)
        if want_ic:
            ry = rankdata(y)
            if rf.std() > 0 and ry.std() > 0:
                ic[t] = np.corrcoef(rf, ry)[0, 1]
        r2 = np.rint(2 * rf).astype(np.int64)
        q = np.clip((5 * r2 + 2 * n - 1) // (2 * n), 1, 5)
        if all((q == k).any() for k in range(1, 6)):
            for k in range(1, 6):
                qm[t, k - 1] = y[q == k].mean()
    return ic, qm, nv


def daily_stats(F, Y, want_ic=True, min_n=None):
    min_n = C.GATE1_MIN_N if min_n is None else min_n
    fn = daily_stats_nb if HAVE_NUMBA else daily_stats_ref
    return fn(np.ascontiguousarray(F), np.ascontiguousarray(Y), min_n, want_ic)


def block_ids(dates):
    d = pd.DatetimeIndex(dates)
    return (d.year * 2 + (d.month > 6).astype(int)).values


def summarize(ic, qm, block, direction, n_rows):
    """direction(+1/-1)로 방향 정렬한 요약 통계."""
    ok = np.isfinite(ic)
    n = int(ok.sum())
    out = {"n_ic_days": n}
    if n >= 2:
        m = ic[ok].mean(); s = ic[ok].std(ddof=1)
        out["ic_mean"] = direction * m
        out["ic_t"] = direction * m / (s / np.sqrt(n)) if s > 0 else np.nan
    else:
        out["ic_mean"] = out["ic_t"] = np.nan
    agree, incl = 0, 0
    for b in np.unique(block):
        sel = (block == b) & ok
        if sel.sum() >= C.BLOCK_MIN_DAYS:
            incl += 1
            agree += int(direction * ic[sel].mean() > 0)
    out["blocks_incl"] = incl
    out["agree"] = agree / incl if incl else np.nan
    elig = np.isfinite(qm[:, 0])
    out["elig_frac"] = elig.sum() / n_rows
    if elig.any():
        out["spread"] = direction * np.mean(qm[elig, 4] - qm[elig, 0])
        qbar = qm[elig].mean(axis=0)
        r = rankdata(qbar)
        out["mono"] = direction * np.corrcoef(np.arange(1, 6), r)[0, 1] if r.std() > 0 else np.nan
    else:
        out["spread"] = out["mono"] = np.nan
    return out


def make_shifts(n_rows, h):
    lo, hi = C.MIN_SHIFT, n_rows - C.MIN_SHIFT
    assert hi - lo + 1 >= C.K_SHIFTS, "이동량 후보가 K보다 적음"
    rng = np.random.default_rng(C.SEED + h)
    return np.sort(rng.choice(np.arange(lo, hi + 1), size=C.K_SHIFTS, replace=False))


def null_stats(F, Y, shifts, block, direction, want_ic=True):
    """Feature 고정, Y를 날짜축으로 순환 이동. 반환 K×4 [ic_mean, agree, spread, mono]."""
    out = np.full((len(shifts), 4), np.nan)
    n_rows = F.shape[0]
    for i, s in enumerate(shifts):
        ic, qm, _ = daily_stats(F, np.roll(Y, int(s), axis=0), want_ic)
        r = summarize(ic, qm, block, direction, n_rows)
        out[i] = [r["ic_mean"], r["agree"], r["spread"], r["mono"]]
    return out


def emp_p(obs, null):
    null = null[np.isfinite(null)]
    return (1 + int((null >= obs).sum())) / (1 + len(null))


def bh_reject(pvals, q=None):
    q = C.BH_Q if q is None else q
    p = np.asarray(pvals, float); m = len(p)
    order = np.argsort(p); thr = (np.arange(1, m + 1) / m) * q
    passed = p[order] <= thr
    k = int(np.where(passed)[0].max()) + 1 if passed.any() else 0
    rej = np.zeros(m, bool); rej[order[:k]] = True
    return rej
