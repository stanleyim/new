"""데이터 로드. SIGNAL_END 이후 행은 폐기하고, 종목별 메타(이후 거래 지속 여부)만 남긴다."""
import glob
import os
import numpy as np
import pandas as pd
from . import config as C


def norm_ticker(s):
    s = s.astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
    isnum = s.str.fullmatch(r"\d+")
    return s.where(~isnum, s.str.zfill(6))


def _scan(df, ticker, src):
    ok = (df["open"] > 0) & (df["close"] > 0) & (df["volume"] > 0)
    vd = df.loc[ok, "date"]
    last_valid_actual = vd.max() if len(vd) else pd.NaT
    last_row = df["date"].max()
    inwin = (df["date"] >= C.INPUT_START) & (df["date"] <= C.SIGNAL_END)
    w = df.loc[inwin, ["date", "open", "close", "volume"]].copy()
    w["ticker"] = ticker
    continues = bool(pd.notna(last_valid_actual) and last_valid_actual > C.SIGNAL_END)
    if src == "439":
        grp = "439"
    else:
        grp = "A" if (pd.notna(last_row) and last_row.year <= 2025) else "B"
    meta = {"ticker": ticker, "continues": continues, "group": grp}
    return w, meta


ALIASES = {"date": ["date", "날짜", "일자", "Date"], "open": ["open", "시가", "Open"],
           "close": ["close", "종가", "Close"], "volume": ["volume", "거래량", "Volume"],
           "ticker": ["ticker", "종목코드", "code"], "name": ["종목명", "name", "Name"]}


def _std(df, need, src=""):
    """컬럼명을 표준명으로 정리. 없으면 실제 컬럼을 보여 주며 중단(추측 진행 금지)."""
    if not any(a in df.columns for a in ALIASES["date"]):
        df = df.reset_index()
    out = {}
    for k in need:
        hit = [a for a in ALIASES[k] if a in df.columns]
        if not hit:
            raise KeyError(f"[{src}] '{k}' 컬럼 없음. 실제 컬럼: {list(df.columns)}")
        out[k] = df[hit[0]]
    return pd.DataFrame(out)


def _num(df):
    for c in ("open", "close", "volume"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["date"] = pd.to_datetime(df["date"])
    return df


def load_439(path):
    df = _std(pd.read_parquet(path), ["date", "open", "close", "volume", "ticker"], "ohlcv_full")
    df["ticker"] = norm_ticker(df["ticker"])
    df = _num(df)
    wins, metas = [], []
    for tk, g in df.groupby("ticker", sort=False):
        w, m = _scan(g, tk, "439")
        wins.append(w)
        metas.append(m)
    return pd.concat(wins, ignore_index=True), metas


def load_kis(dir_):
    wins, metas = [], []
    for f in sorted(glob.glob(os.path.join(dir_, "*.parquet"))):
        tk = os.path.splitext(os.path.basename(f))[0]
        df = _num(_std(pd.read_parquet(f), ["date", "open", "close", "volume"], f))
        w, m = _scan(df, tk, "kis")
        wins.append(w)
        metas.append(m)
    return pd.concat(wins, ignore_index=True), metas


def load_sector_names(glob_pat):
    parts = []
    for f in sorted(glob.glob(glob_pat)):
        d = _std(pd.read_parquet(f), ["date", "ticker", "name"], f).rename(columns={"name": "종목명"})
        d["ticker"] = norm_ticker(d["ticker"])
        d["date"] = pd.to_datetime(d["date"])
        parts.append(d)
    return pd.concat(parts, ignore_index=True)


def build_panels(long_df, meta_df, roster, calendar):
    """long_df: date/ticker/open/close/volume (윈도우 내). 무효 행(open/close/volume<=0)은 전부 NaN, forward-fill 없음."""
    assert long_df["date"].max() <= C.SIGNAL_END, "SIGNAL_END 이후 행이 로드됨"
    n_before = len(long_df)
    long_df = long_df[long_df["date"].isin(calendar)]
    n_off_calendar = n_before - len(long_df)
    not_in_roster = sorted(set(long_df["ticker"]) - set(roster))
    long_df = long_df[long_df["ticker"].isin(roster)]
    cols = sorted(set(long_df["ticker"]))
    P = {}
    for k in ("open", "close", "volume"):
        P[k] = long_df.pivot(index="date", columns="ticker", values=k).reindex(index=calendar, columns=cols)
    V = (P["open"] > 0) & (P["close"] > 0) & (P["volume"] > 0)
    for k in P:
        P[k] = P[k].where(V)
    O = pd.DataFrame(False, index=calendar, columns=cols)
    for tk, ds in C.OUTLIER_ROWS.items():
        for d in ds:
            d = pd.Timestamp(d)
            if tk in O.columns and d in O.index:
                O.loc[d, tk] = True
    meta = meta_df.set_index("ticker").reindex(cols)
    info = {"rows_off_calendar_dropped": n_off_calendar, "tickers_not_in_roster": not_in_roster}
    return P["open"], P["close"], P["volume"], V, O, meta, info


def load_all(ohlcv_path, kis_dir, sector_glob):
    w439, m439 = load_439(ohlcv_path)
    wkis, mkis = load_kis(kis_dir)
    calendar = pd.DatetimeIndex(sorted(w439["date"].unique()))
    names = load_sector_names(sector_glob)
    roster = sorted(set(names["ticker"]))
    long_df = pd.concat([w439, wkis], ignore_index=True)
    meta_df = pd.DataFrame(m439 + mkis)
    names_w = names[names["date"] <= C.SIGNAL_END]
    o, c, v, V, O, meta, info = build_panels(long_df, meta_df, roster, calendar)
    info["roster_size"] = len(roster)
    return {"open": o, "close": c, "volume": v, "valid": V, "outlier": O,
            "meta": meta, "names": names_w, "calendar": calendar, "info": info}
