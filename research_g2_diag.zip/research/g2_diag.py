"""Gate 2 후속 진단(읽기 전용). Gate 2 판정·후보·임계·비용·선택 규칙을 바꾸지 않는다(재판정 없음).
선택(Q5·풀)은 gate2.select_masks 그대로. features/targets를 import하지 않는다(입력은 prepare_g2 결과 + 가격 배열).
진단 4종: (1) Q5 구성 (2) 상위 기여 집중도 (3) 연도별 E (4) 거래대금 3분위별 절대 순수익.
거래 단위 절단·종목 제외는 '사후 스트레스 민감도'이며 어떤 선택·판정에도 쓰지 않는다."""
import numpy as np
import pandas as pd
from . import config as C
from .gate2 import select_masks, excess_days, tercile_pool

DIAG_CANDS = [("LIQ", 5), ("LIQ", 10), ("LIQ", 20), ("RISK", 5), ("RISK", 10), ("RISK", 20)]
GROUPS = ("439", "A", "B")
TOPK_STOCKS = (1, 3, 5, 10)
TRIM_FRACS = (0.001, 0.01, 0.05)


def _q(a, qs=(0.1, 0.5, 0.9)):
    a = a[np.isfinite(a)]
    return [float(np.quantile(a, x)) if len(a) else np.nan for x in qs]


def _mean_E(Q, P, Y):
    E, mq, mp, nq = excess_days(Q, P, Y, 0)
    ok = np.isfinite(E)
    return (float(E[ok].mean()) if ok.any() else np.nan), (float(mq[np.isfinite(mq)].mean()) if np.isfinite(mq).any() else np.nan), int(ok.sum())


def _contrib(Q, P, Y):
    """거래별 E 기여 c_tj = (T1_tj - 풀평균_t)/Q5수_t (E_t = Σ_j c_tj). 반환 (c: T×M, E 유효일 수)."""
    Qf = Q & np.isfinite(Y); Pf = P & np.isfinite(Y)
    T, M = Y.shape
    nq = Qf.sum(1); npl = Pf.sum(1)
    Yz = np.where(np.isfinite(Y), Y, 0.0)
    mp = np.where(npl > 0, (Yz * Pf).sum(1) / np.maximum(npl, 1), np.nan)
    day = (nq > 0) & (npl > 0)
    c = np.zeros((T, M))
    rows = np.where(day)[0]
    c[rows] = np.where(Qf[rows], (Yz[rows] - mp[rows, None]) / nq[rows, None], 0.0)
    return c, int(day.sum())


def diag_one(prep, px, group, k, h, cost=None):
    """k,h 한 후보의 진단. px: 신호일×종목 T일 종가(무효 NaN), group: 길이 M 배열('439'/'A'/'B')."""
    cost = C.G2_COST_RT if cost is None else cost
    P = prep["h"][h]; d = C.FEATURE_DIRECTION[k]
    T1 = P["T1"]; DV = P["DV"]; dates = pd.DatetimeIndex(P["dates"])
    pool, q5, _ = select_masks(P["F"][k], d)
    fin = np.isfinite(T1); Qt = q5 & fin; Pt = pool & fin
    g = np.asarray(group)
    out = {}
    base_E, base_mq, base_n = _mean_E(q5, pool, T1)

    # (1) Q5 구성
    rows = []
    TL = tercile_pool(pool, DV)
    for gname in GROUPS:
        gm = (g == gname)[None, :]
        rows.append({"항목": f"그룹 {gname} 비중", "Q5": float((Qt & gm).sum() / max(Qt.sum(), 1)), "풀": float((Pt & gm).sum() / max(Pt.sum(), 1))})
    for t_, nm in ((1, "저"), (2, "중"), (3, "고")):
        rows.append({"항목": f"거래대금 {nm}분위 비중", "Q5": float((Qt & (TL == t_)).sum() / max(Qt.sum(), 1)), "풀": float((Pt & (TL == t_)).sum() / max(Pt.sum(), 1))})
    for nm, arr in (("종가(원)", px), ("거래대금20일평균", DV)):
        qa = _q(arr[Qt]); pa = _q(arr[Pt])
        for lab, a, b in zip(("p10", "중앙", "p90"), qa, pa):
            rows.append({"항목": f"{nm} {lab}", "Q5": a, "풀": b})
    comp = pd.DataFrame(rows)
    out["comp"] = comp

    # (2) 기여 집중도
    c, nday = _contrib(q5, pool, T1)
    assert nday > 0, f"{k} h={h}: 평가 가능한 날이 없음(유효 종목 < {C.GATE1_MIN_N}?)"
    total = float(c.sum())
    assert abs(total / nday - base_E) < 1e-12, (total / nday, base_E)         # 분해가 Gate 2 E와 일치
    S = c.sum(0)
    order = np.argsort(-S)
    conc = []
    nstock_q5 = int((Qt.sum(0) > 0).sum())
    for kk in TOPK_STOCKS:
        ex = np.zeros(len(g), bool); ex[order[:kk]] = True
        mE, mq, _ = _mean_E(q5 & ~ex[None, :], pool & ~ex[None, :], T1)
        conc.append({"구분": f"상위 {kk}종목 제외(기여순, 사후)", "평균E": mE, "Q5절대순수익": mq - cost if np.isfinite(mq) else np.nan,
                     "상위기여 합/전체E합": float(S[order[:kk]].sum() / total) if total != 0 else np.nan})
    thr_src = T1[Qt]
    for fr in TRIM_FRACS:
        thr = np.quantile(thr_src, 1 - fr)
        cut = fin & (np.where(fin, T1, -np.inf) >= thr)
        mE, mq, _ = _mean_E(q5 & ~cut, pool, T1)
        conc.append({"구분": f"Q5 상위 {fr*100:g}% 거래 절단(Q5만, 스트레스)", "평균E": mE, "Q5절대순수익": mq - cost if np.isfinite(mq) else np.nan,
                     "상위기여 합/전체E합": np.nan})
    conc.insert(0, {"구분": "기준(Gate 2 동일)", "평균E": base_E, "Q5절대순수익": base_mq - cost, "상위기여 합/전체E합": np.nan})
    out["conc"] = pd.DataFrame(conc)
    gshare = {f"그룹{gn}_E기여비중": float(S[g == gn].sum() / total) if total != 0 else np.nan for gn in GROUPS}
    cnt_by_stock = Qt.sum(0)
    top10_trade_share = float(np.sort(cnt_by_stock)[::-1][:10].sum() / max(Qt.sum(), 1))
    out["conc_meta"] = {"Q5에 한 번이라도 든 종목 수": nstock_q5, "Q5 거래 수": int(Qt.sum()), "최다빈도 상위10종목 거래 비중": top10_trade_share,
                        "상위1종목 E기여/전체": float(S[order[0]] / total) if total != 0 else np.nan, **gshare}

    # (3) 연도별 E
    E, mq, mp, nq = excess_days(q5, pool, T1, 0)
    yrs = dates.year.values; yr = []
    for y in sorted(set(yrs)):
        m = (yrs == y) & np.isfinite(E)
        if not m.any():
            continue
        yr.append({"연도": int(y), "평가일": int(m.sum()), "평균E(h일)": float(E[m].mean()), "초과연환산": float(E[m].mean() * C.G2_ANN_DAYS / h),
                   "Q5평균gross": float(mq[m].mean()), "풀평균gross": float(mp[m].mean()), "Q5절대순수익": float(mq[m].mean() - cost),
                   "E>0 일 비율": float((E[m] > 0).mean())})
    out["year"] = pd.DataFrame(yr)

    # (4) 거래대금 3분위별 Q5 절대 순수익(분위 내 Q5, 비용 0.206% 동일)
    tr = []
    for t_, nm in ((1, "저"), (2, "중"), (3, "고")):
        Eg, mqg, mpg, nqg = excess_days(q5 & (TL == t_), pool & (TL == t_), T1, 0)
        ok = np.isfinite(Eg)
        tr.append({"분위": nm, "평가일": int(ok.sum()), "일평균 Q5 종목수": float(nqg[ok].mean()) if ok.any() else np.nan,
                   "Q5평균gross(h일)": float(mqg[ok].mean()) if ok.any() else np.nan,
                   "Q5절대순수익(h일)": float(mqg[ok].mean() - cost) if ok.any() else np.nan,
                   "Q5절대순수익_단순연환산(×252/h)": float((mqg[ok].mean() - cost) * C.G2_ANN_DAYS / h) if ok.any() else np.nan,
                   "분위내 평균E(h일)": float(Eg[ok].mean()) if ok.any() else np.nan})
    out["terc"] = pd.DataFrame(tr)
    out["base"] = {"평균E": base_E, "Q5절대순수익": base_mq - cost, "평가일": base_n}
    return out


def run_diag(prep, px_by_h, group, cands=None, cost=None, log=print):
    """px_by_h[h]: 해당 h 신호일×종목 종가 배열. 반환 {(k,h): diag_one 결과}."""
    res = {}
    for k, h in (cands or DIAG_CANDS):
        res[(k, h)] = diag_one(prep, px_by_h[h], group, k, h, cost)
        log(f"진단 완료: {k} h={h}")
    return res


def check_against_gate2(res, csv_path, atol=1e-12):
    """진단의 기준값이 gate2_results.csv(평균E·Q5절대순수익)와 일치하는지 확인. 불일치 시 중단."""
    df = pd.read_csv(csv_path)
    n = 0
    for (k, h), r in res.items():
        row = df[(df["feature"] == k) & (df["h"] == h)]
        assert len(row) == 1, f"gate2_results.csv에 {k} h={h} 없음"
        assert abs(row["평균E_gross(트랜치,h일)"].iloc[0] - r["base"]["평균E"]) < atol, (k, h, "평균E")
        assert abs(row["Q5절대순수익(트랜치,h일)"].iloc[0] - r["base"]["Q5절대순수익"]) < atol, (k, h, "Q5절대순수익")
        n += 1
    return n


def save_report(res, out_dir):
    import os
    os.makedirs(out_dir, exist_ok=True)
    for tag in ("comp", "conc", "year", "terc"):
        parts = []
        for (k, h), r in res.items():
            t = r[tag].copy(); t.insert(0, "h", h); t.insert(0, "feature", k); parts.append(t)
        pd.concat(parts, ignore_index=True).to_csv(os.path.join(out_dir, f"g2_diag_{tag}.csv"), index=False, encoding="utf-8-sig")
    pd.DataFrame([{"feature": k, "h": h, **r["conc_meta"]} for (k, h), r in res.items()]).to_csv(
        os.path.join(out_dir, "g2_diag_conc_meta.csv"), index=False, encoding="utf-8-sig")


def print_report(res, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
    for tag, title in (("comp", "(1) Q5 구성 vs 풀"), ("conc", "(2) 기여 집중도·절단 민감도(사후 스트레스, 판정 불변)"),
                       ("year", "(3) 연도별 E"), ("terc", "(4) 거래대금 3분위별 Q5 절대 순수익(비용 0.206%)")):
        out(f"\n===== {title} =====")
        for (k, h), r in res.items():
            out(f"\n[{k} h={h}]")
            out(r[tag].round(4).to_string(index=False))
            if tag == "conc":
                out({a: (round(b, 4) if isinstance(b, float) else b) for a, b in r["conc_meta"].items()})
