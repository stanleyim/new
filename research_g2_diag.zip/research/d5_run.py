"""D5 Gate 1 본 실행. 승인된 확정안 그대로: Feature 고정·Target 날짜축 순환 이동 permutation, family(=Feature) 내부 BH,
순차 AND 통과 규칙. features/targets를 import하지 않는다(입력은 gate1_prep.prepare 결과 prep).
청크 단위 체크포인트(중단 후 같은 셀 재실행 시 이어받음). 통계 값은 최종 보고에서만 출력한다."""
import hashlib
import json
import os
import time
import numpy as np
import pandas as pd
from . import config as C
from .gate1 import daily_stats, summarize, make_shifts, null_stats, emp_p, bh_reject

CHUNK = 100
TARGETS = ("T1", "T2", "T3")
# 사전등록 상수(결과 열람 전 고정). config가 바뀌어 있으면 실행 거부.
PREREG = dict(K_SHIFTS=1000, MIN_SHIFT=40, SEED=20261005, GATE1_MIN_N=50, BLOCK_MIN_DAYS=60,
              BH_Q=0.10, NULL_PCT=0.95, MIN_ELIG_FRAC=0.5)


class StopForTest(Exception):
    pass


def check_prereg(expected=PREREG):
    for k, v in expected.items():
        assert getattr(C, k) == v, f"사전등록 상수 불일치: {k}={getattr(C, k)} (사전등록 {v})"


def bh_adjust(p):
    """BH 보정 p(q-value). bh_reject(p,q)와 (adj<=q) 동치."""
    p = np.asarray(p, float); m = len(p)
    order = np.argsort(p)
    ranked = p[order] * m / np.arange(1, m + 1)
    adj_sorted = np.minimum.accumulate(ranked[::-1])[::-1]
    adj = np.empty(m); adj[order] = np.minimum(adj_sorted, 1.0)
    return adj


def fingerprint(prep):
    """입력 배열 지문(체크포인트가 다른 입력과 섞이는 것 방지)."""
    h = hashlib.sha256()
    for hh in sorted(prep):
        P = prep[hh]
        for name in ("T1", "T2", "T1_L1"):
            h.update(np.ascontiguousarray(P[name]).tobytes())
        for k in P["F"]:
            h.update(k.encode()); h.update(np.ascontiguousarray(P["F"][k]).tobytes())
    h.update(json.dumps({k: float(getattr(C, k)) for k in PREREG}, sort_keys=True).encode())
    return h.hexdigest()


def _atomic_save(path, arr):
    tmp = path + ".tmp.npy"
    np.save(tmp, arr)
    os.replace(tmp, path)


def null_unit(P, h, k, tgt, out_dir, chunk=CHUNK, stop_after_chunks=None):
    """한 (h, Feature, Target[T1|T2]) null. 반환 K×4 [ic_mean, agree, spread, mono]. 청크마다 저장·재개."""
    final = os.path.join(out_dir, f"null_h{h}_{k}_{tgt}.npy")
    K = C.K_SHIFTS
    if os.path.exists(final):
        a = np.load(final)
        assert a.shape == (K, 4), f"{final} shape {a.shape} != ({K},4)"
        return a
    part = final.replace(".npy", ".part.npy")
    F, Y = P["F"][k], P[tgt]
    shifts = make_shifts(F.shape[0], h)
    done = np.load(part) if os.path.exists(part) else np.empty((0, 4))
    assert len(done) <= K
    n_chunks = 0
    while len(done) < K:
        i = len(done)
        blk = null_stats(F, Y, shifts[i:i + chunk], P["block"], C.FEATURE_DIRECTION[k], want_ic=(tgt == "T1"))
        done = np.vstack([done, blk])
        _atomic_save(part, done)
        n_chunks += 1
        if stop_after_chunks is not None and n_chunks >= stop_after_chunks and len(done) < K:
            raise StopForTest()
    _atomic_save(final, done)
    os.remove(part)
    return done


def observed(P, k):
    n = P["T1"].shape[0]; d = C.FEATURE_DIRECTION[k]
    ic, qm, nv = daily_stats(P["F"][k], P["T1"], True)
    r1 = summarize(ic, qm, P["block"], d, n)
    _, qm2, _ = daily_stats(P["F"][k], P["T2"], False)
    r2 = summarize(np.full(n, np.nan), qm2, P["block"], d, n)
    ic_l1, qm_l1, _ = daily_stats(P["F"][k], P["T1_L1"], True)
    r_l1 = summarize(ic_l1, qm_l1, P["block"], d, n)
    return r1, r2, r_l1


def run_gate1(prep, out_dir, chunk=CHUNK, log=print, stop_after_chunks=None):
    check_prereg()
    os.makedirs(out_dir, exist_ok=True)
    fp = fingerprint(prep)
    fpath = os.path.join(out_dir, "fingerprint.json")
    if os.path.exists(fpath):
        old = json.load(open(fpath))["fingerprint"]
        assert old == fp, "체크포인트 폴더의 입력 지문이 현재 입력과 다름: 다른 폴더를 쓰거나 폴더를 비우세요(임의 병합 금지)"
    else:
        json.dump({"fingerprint": fp}, open(fpath, "w"))
    feats = list(next(iter(prep.values()))["F"])
    nulls, obs = {}, {}
    units = [(h, k, t) for h in sorted(prep) for k in feats for t in ("T1", "T2")]
    t_start = time.time()
    for i, (h, k, t) in enumerate(units, 1):
        t0 = time.time()
        nulls[(h, k, t)] = null_unit(prep[h], h, k, t, out_dir, chunk, stop_after_chunks)
        log(f"[{i}/{len(units)}] null h={h} {k} {t} 완료 {time.time() - t0:.0f}s | 누적 {(time.time() - t_start) / 60:.1f}분")
    for h in sorted(prep):
        for k in feats:
            obs[(h, k)] = observed(prep[h], k)
    res = assemble(prep, feats, obs, nulls)
    res["df"].to_csv(os.path.join(out_dir, "gate1_results.csv"), index=False, encoding="utf-8-sig")
    meta = summary_meta(res, fp)
    json.dump(meta, open(os.path.join(out_dir, "gate1_summary.json"), "w"), ensure_ascii=False, indent=1, default=str)
    return res, meta


def _pct(a):
    a = a[np.isfinite(a)]
    return float(np.percentile(a, C.NULL_PCT * 100)) if len(a) else np.nan   # linear 보간


def assemble(prep, feats, obs, nulls):
    rows = []
    for k in feats:
        fam = []                                    # family(Feature) 내부 9개: h 3 × Target 3
        for h in sorted(prep):
            r1, r2, rl1 = obs[(h, k)]
            n1, n2 = nulls[(h, k, "T1")], nulls[(h, k, "T2")]
            unjudge = bool(r1["elig_frac"] < C.MIN_ELIG_FRAC)
            ic_ok = np.isfinite(r1["ic_mean"])
            p_ic = emp_p(r1["ic_mean"], n1[:, 0]) if ic_ok else 1.0     # IC는 T1~T3 동일
            for tgt in TARGETS:
                src, nl = (r2, n2) if tgt == "T2" else (r1, n1)         # T3는 T1과 수학적으로 동일(테스트로 검증)
                rows.append({"feature": k, "h": h, "target": tgt, "n_ic_days": r1["n_ic_days"],
                             "elig_frac": r1["elig_frac"] if tgt != "T2" else r2["elig_frac"],
                             "ic_mean": r1["ic_mean"], "ic_t": r1["ic_t"], "p_ic": p_ic,
                             "blocks_incl": r1["blocks_incl"], "agree": r1["agree"], "agree_thr": _pct(n1[:, 1]),
                             "spread": src["spread"], "spread_thr": _pct(nl[:, 2]),
                             "mono": src["mono"], "mono_thr": _pct(nl[:, 3]),
                             "p_spread": emp_p(src["spread"], nl[:, 2]) if np.isfinite(src["spread"]) else 1.0,
                             "ic_mean_L1": rl1["ic_mean"], "판정불가": unjudge})
    df = pd.DataFrame(rows)
    df["bh_q"] = np.nan; df["s1_IC"] = False
    for k in feats:                                  # family 내부 BH(판정 불가는 family에서 제외)
        m = (df["feature"] == k) & ~df["판정불가"]
        if m.any():
            p = df.loc[m, "p_ic"].values
            df.loc[m, "bh_q"] = bh_adjust(p)
            df.loc[m, "s1_IC"] = bh_reject(p)
    ok_agree = np.isfinite(df["agree"]) & np.isfinite(df["agree_thr"]) & (df["agree"] >= df["agree_thr"])
    ok_sp = np.isfinite(df["spread"]) & np.isfinite(df["spread_thr"]) & (df["spread"] >= df["spread_thr"])
    ok_mo = np.isfinite(df["mono"]) & np.isfinite(df["mono_thr"]) & (df["mono"] >= df["mono_thr"])
    df["s2_agree"] = df["s1_IC"] & ok_agree
    df["s3_quant"] = df["s2_agree"] & ok_sp & ok_mo
    df["판정"] = np.where(df["판정불가"], "판정불가", np.where(df["s3_quant"], "통과(Gate2 후보)", "실패"))
    return {"df": df, "feats": feats}


def summary_meta(res, fp):
    df = res["df"]
    import numba, scipy
    return {"fingerprint": fp, "prereg": PREREG, "trials": int(len(df)), "families": int(df["feature"].nunique()),
            "independent_IC_tests": int(df.groupby(["feature", "h"]).ngroups),
            "n_판정불가": int(df["판정불가"].sum()), "stage1_IC_BH": int(df["s1_IC"].sum()),
            "stage2_agree": int(df["s2_agree"].sum()), "stage3_quantile": int(df["s3_quant"].sum()),
            "versions": {"numpy": np.__version__, "pandas": pd.__version__, "numba": numba.__version__, "scipy": scipy.__version__},
            "bh_adjust_note": "p는 (1+#{null>=obs})/(1+K) 단측, family 내부 9개에 BH, 판정 불가 제외"}


def print_report(res, meta, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 50)
    df = res["df"]
    out("=== [Gate 1 결과] 독립 IC 검정 18개 (T1·T3 동일) ===")
    a = df[df["target"] == "T1"][["feature", "h", "ic_mean", "ic_t", "p_ic", "bh_q", "s1_IC", "agree", "agree_thr", "s2_agree", "ic_mean_L1"]]
    out(a.round(4).to_string(index=False))
    out("\n=== 분위 단계 (54개 중 stage2 통과분) ===")
    b = df[df["s2_agree"]][["feature", "h", "target", "spread", "spread_thr", "mono", "mono_thr", "s3_quant", "판정"]]
    out(b.round(4).to_string(index=False) if len(b) else "stage2 통과 없음")
    out("\n=== 요약 ===")
    out(f"전체 trial {meta['trials']} | family {meta['families']} | 독립 IC 검정 {meta['independent_IC_tests']} | 판정불가 {meta['n_판정불가']}")
    out(f"통과: stage1 IC(BH) {meta['stage1_IC_BH']}/54 → stage2 부호일치 {meta['stage2_agree']}/54 → stage3 분위 {meta['stage3_quantile']}/54")
    ps = df[df["s3_quant"]][["feature", "h", "target"]]
    out("Gate 2 후보: " + (", ".join(f"{r.feature}-h{r.h}-{r.target}" for r in ps.itertuples()) if len(ps) else "없음"))
