"""Gate 2 실행: 사전등록 11개 (Feature,h) 후보, 롱온리 Q5 트랜치 포트폴리오(왕복 0.206%), 풀 대비 초과.
features/targets를 import하지 않는다(입력은 gate2_prep.prepare_g2 결과). null은 후보별 파일로 체크포인트(재개 가능)."""
import hashlib
import json
import os
import time
import numpy as np
import pandas as pd
from . import config as C
from .gate1 import make_shifts, emp_p, bh_reject
from .d5_run import bh_adjust, check_prereg
from .gate2 import (select_masks, excess_days, summarize_excess, null_excess, daily_path, perf, tercile_pool)

CANDS = [("REV", 5), ("REV", 10), ("REV", 20), ("RISK", 5), ("RISK", 10), ("RISK", 20),
         ("ATTN", 5), ("ATTN", 10), ("LIQ", 5), ("LIQ", 10), ("LIQ", 20)]    # Gate 1 통과 19개를 (Feature,h)로 묶은 것, 변경 불가
PREREG2 = dict(K_SHIFTS=1000, MIN_SHIFT=40, SEED=20261005, GATE1_MIN_N=50, BLOCK_MIN_DAYS=60, BH_Q=0.10,
               NULL_PCT=0.95, MIN_ELIG_FRAC=0.5, G2_COST_RT=0.00206, G2_ANN_DAYS=252, G2_QUANTILE=5)
STATUS = {0: "OK", 1: "L2", 2: "일시정지NaN", 3: "진입불가", 4: "이상치NaN", 5: "유니버스외"}


def check_cands_vs_gate1(csv_path):
    """gate1_results.csv가 있으면 사전등록 후보와 일치하는지 확인(불일치 시 중단)."""
    df = pd.read_csv(csv_path)
    got = set(map(tuple, df[df["s3_quant"]][["feature", "h"]].drop_duplicates().values.tolist()))
    assert got == set(CANDS), f"Gate 1 통과 (Feature,h)와 사전등록 후보 불일치: {sorted(got ^ set(CANDS))}"
    return len(df[df["s3_quant"]])


def fingerprint(prep):
    h = hashlib.sha256()
    for hh in sorted(prep["h"]):
        P = prep["h"][hh]
        h.update(np.ascontiguousarray(P["T1"]).tobytes()); h.update(np.ascontiguousarray(P["tpos"]).tobytes())
        for k in sorted(P["F"]):
            h.update(k.encode()); h.update(np.ascontiguousarray(P["F"][k]).tobytes())
    h.update(json.dumps({k: float(getattr(C, k)) for k in PREREG2}, sort_keys=True).encode())
    return h.hexdigest()


def _pct(a):
    a = a[np.isfinite(a)]
    return float(np.percentile(a, C.NULL_PCT * 100)) if len(a) else np.nan


def null_unit(P, k, h, out_dir, pool, q5):
    final = os.path.join(out_dir, f"null_g2_{k}_h{h}.npy")
    if os.path.exists(final):
        a = np.load(final); assert a.shape == (C.K_SHIFTS, 2), f"{final} shape {a.shape}"
        return a
    shifts = make_shifts(P["T1"].shape[0], h)
    a = null_excess(q5, pool, P["T1"], shifts, P["block"])
    tmp = final + ".tmp.npy"; np.save(tmp, a); os.replace(tmp, final)
    return a


def evaluate(prep, k, h, out_dir, log=print):
    P = prep["h"][h]; d = C.FEATURE_DIRECTION[k]; T1 = P["T1"]; T = T1.shape[0]
    pool, q5, day_ok = select_masks(P["F"][k], d)
    E, mq, mp, nq = excess_days(q5, pool, T1, 0)
    s = summarize_excess(E, P["block"])
    null = null_unit(P, k, h, out_dir, pool, q5)
    elig = s["n_days"] / T
    row = {"feature": k, "h": h, "신호일": T, "평가일": s["n_days"], "평가비율": elig,
           "판정불가": bool(elig < C.MIN_ELIG_FRAC), "평균E_gross(트랜치,h일)": s["mean_E"],
           "초과연환산(=E×252/h)": s["mean_E"] * C.G2_ANN_DAYS / h, "p_E": emp_p(s["mean_E"], null[:, 0]),
           "블록포함": s["blocks_incl"], "블록양비율": s["block_pos"], "블록임계": _pct(null[:, 1])}
    # 경로 성과(Q5, 풀, 초과). 모든 슬롯이 채워진 구간만.
    tpos = P["tpos"]; O, Clf = prep["O"], prep["Clf"]
    fin = np.isfinite(T1)
    rq = daily_path(q5 & fin, O, Clf, tpos, h); rp = daily_path(pool & fin, O, Clf, tpos, h)
    a, b = int(tpos[0]) + h, int(tpos[-1]) + 1
    pq, pp = perf(rq, a, b), perf(rp, a, b)
    row.update({"Q5_CAGR": pq["CAGR"], "Q5_Sharpe": pq["Sharpe"], "Q5_MDD": pq["MDD"],
                "풀_CAGR": pp["CAGR"], "풀_Sharpe": pp["Sharpe"], "풀_MDD": pp["MDD"],
                "초과일평균연환산(경로)": float((rq - rp)[a:b + 1].mean() * C.G2_ANN_DAYS)})
    # 거래 수·회전
    n_trades = int((q5 & fin).sum())
    row.update({"Q5 거래 수(종목×트랜치)": n_trades, "일평균 Q5 종목수": float(nq[nq > 0].mean()) if (nq > 0).any() else np.nan,
                "유효 독립 표본(≈평가일/h)": s["n_days"] / h, "연 왕복 횟수(=252/h)": C.G2_ANN_DAYS / h})
    # 슬리피지 break-even(편도 bp): 절대(순수익 0), 초과(풀 대비 0)
    mqv = mq[np.isfinite(mq)]
    row["Q5평균_gross(트랜치,h일)"] = float(mqv.mean()) if len(mqv) else np.nan
    row["Q5절대순수익(트랜치,h일)"] = float(mqv.mean() - C.G2_COST_RT) if len(mqv) else np.nan     # 필수조건 ③(TL-004)
    row["break_even_절대_bp"] = float((mqv.mean() - C.G2_COST_RT) / 2 * 1e4) if len(mqv) else np.nan
    row["break_even_초과_bp"] = float(s["mean_E"] / 2 * 1e4)
    # 거래대금 3분위(풀 내, 라벨 미사용)별
    TL = tercile_pool(pool, P["DV"])
    for g, nm in ((1, "저"), (2, "중"), (3, "고")):
        Eg, mqg, mpg, nqg = excess_days(q5 & (TL == g), pool & (TL == g), T1, 0)
        okg = np.isfinite(Eg)
        row[f"{nm}분위_Q5평균(gross)"] = float(np.nanmean(mqg)) if okg.any() else np.nan
        row[f"{nm}분위_E"] = float(np.nanmean(Eg)) if okg.any() else np.nan
        row[f"{nm}분위_break_even_절대_bp"] = float((np.nanmean(mqg) - C.G2_COST_RT) / 2 * 1e4) if okg.any() else np.nan
        row[f"{nm}분위_break_even_초과_bp"] = float(np.nanmean(Eg) / 2 * 1e4) if okg.any() else np.nan
    # 기간 분할(참고) : 2018~19 vs 2020~22
    yrs = pd.DatetimeIndex(P["dates"]).year.values
    for nm, m in (("2018-19", yrs <= 2019), ("2020-22", yrs >= 2020)):
        e = E[m]; row[f"E평균_{nm}"] = float(np.nanmean(e)) if np.isfinite(e).any() else np.nan
    # 선택 종목 상태 진단(선택 후 라벨 상태)
    cnt = np.bincount(P["status"][q5].astype(np.int64), minlength=6)
    row["Q5 제외(일시정지·진입불가·이상치)"] = int(cnt[2] + cnt[3] + cnt[4])
    row["Q5 제외 비율"] = float((cnt[2] + cnt[3] + cnt[4]) / max(int(q5.sum()), 1))
    row["Q5 L2청산"] = int(cnt[1])
    return row


def run_gate2(prep, out_dir, gate1_csv=None, log=print):
    check_prereg(PREREG2)
    os.makedirs(out_dir, exist_ok=True)
    if gate1_csv and os.path.exists(gate1_csv):
        n19 = check_cands_vs_gate1(gate1_csv); log(f"사전등록 후보 11개 = Gate 1 통과 (Feature,h) 일치 확인 (통과 trial {n19}개)")
    fp = fingerprint(prep); fpath = os.path.join(out_dir, "fingerprint_g2.json")
    if os.path.exists(fpath):
        assert json.load(open(fpath))["fingerprint"] == fp, "체크포인트 폴더 입력 지문 불일치: 다른 폴더를 쓰거나 비우세요"
    else:
        json.dump({"fingerprint": fp}, open(fpath, "w"))
    rows = []; t0 = time.time()
    for i, (k, h) in enumerate(CANDS, 1):
        rows.append(evaluate(prep, k, h, out_dir, log))
        log(f"[{i}/{len(CANDS)}] {k} h={h} 완료 | 누적 {(time.time() - t0) / 60:.1f}분")
    df = pd.DataFrame(rows)
    df["bh_q"] = np.nan; df["s1_초과BH"] = False
    for k in df["feature"].unique():                       # family(Feature) 내부 BH, 판정 불가 제외
        m = (df["feature"] == k) & ~df["판정불가"]
        if m.any():
            p = df.loc[m, "p_E"].values
            df.loc[m, "bh_q"] = bh_adjust(p); df.loc[m, "s1_초과BH"] = bh_reject(p)
    df["s2_블록"] = np.isfinite(df["블록양비율"]) & np.isfinite(df["블록임계"]) & (df["블록양비율"] >= df["블록임계"])
    df["s3_절대순수익>0"] = np.isfinite(df["Q5절대순수익(트랜치,h일)"]) & (df["Q5절대순수익(트랜치,h일)"] > 0)
    df["판정"] = np.where(df["판정불가"], "판정불가",
                        np.where(df["s1_초과BH"] & df["s2_블록"] & df["s3_절대순수익>0"], "통과", "실패"))
    df.to_csv(os.path.join(out_dir, "gate2_results.csv"), index=False, encoding="utf-8-sig")
    meta = {"fingerprint": fp, "prereg": PREREG2, "후보": len(df), "통과": int((df["판정"] == "통과").sum()),
            "실패": int((df["판정"] == "실패").sum()), "판정불가": int((df["판정"] == "판정불가").sum())}
    json.dump(meta, open(os.path.join(out_dir, "gate2_summary.json"), "w"), ensure_ascii=False, indent=1)
    return df, meta


def print_report(df, meta, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 60)
    f = lambda cols: df[cols].round(4).to_string(index=False)
    out("=== [Gate 2] 판정 (롱온리 Q5 트랜치, 왕복 0.206%, 풀 대비 초과; 같은 비용을 풀에도 적용) ===")
    out(f(["feature", "h", "평가일", "평균E_gross(트랜치,h일)", "초과연환산(=E×252/h)", "p_E", "bh_q", "s1_초과BH", "블록양비율", "블록임계", "s2_블록", "Q5절대순수익(트랜치,h일)", "s3_절대순수익>0", "판정"]))
    out("\n=== 경로 성과 (모든 슬롯 활성 구간, 비용 후) ===")
    out(f(["feature", "h", "Q5_CAGR", "Q5_Sharpe", "Q5_MDD", "풀_CAGR", "풀_Sharpe", "풀_MDD", "초과일평균연환산(경로)"]))
    out("\n=== 거래 수·회전·표본 ===")
    out(f(["feature", "h", "Q5 거래 수(종목×트랜치)", "일평균 Q5 종목수", "유효 독립 표본(≈평가일/h)", "연 왕복 횟수(=252/h)", "Q5 제외 비율", "Q5 L2청산"]))
    out("\n=== 슬리피지 break-even (편도 bp; 절대=Q5 순수익 0, 초과=풀 대비 초과 0) ===")
    out(f(["feature", "h", "break_even_절대_bp", "break_even_초과_bp", "저분위_break_even_절대_bp", "중분위_break_even_절대_bp", "고분위_break_even_절대_bp", "저분위_break_even_초과_bp", "중분위_break_even_초과_bp", "고분위_break_even_초과_bp"]))
    out("\n=== 거래대금 3분위별 Q5 평균(gross, h일)·E(풀 대비) ===")
    out(f(["feature", "h", "저분위_Q5평균(gross)", "중분위_Q5평균(gross)", "고분위_Q5평균(gross)", "저분위_E", "중분위_E", "고분위_E"]))
    out("\n=== 기간 분할(참고, 판정 불변) E평균 ===")
    out(f(["feature", "h", "E평균_2018-19", "E평균_2020-22"]))
    out(f"\n요약: 후보 {meta['후보']} | 통과 {meta['통과']} | 실패 {meta['실패']} | 판정불가 {meta['판정불가']}")
    out("통과: " + (", ".join(f"{r.feature}-h{r.h}" for r in df[df['판정'] == '통과'].itertuples()) or "없음"))
