"""Gate 2 합성 검증: 선택 규칙·numba↔참조·경로 항등·비용·null 보정/검정력·BH·모듈 분리·종단 실행."""
import ast, os, sys, tempfile
import numpy as np
import pandas as pd
from research import config as C
from research import gate2 as G
from research import gate2_run as R
from research.gate1 import block_ids

ROOT = os.path.dirname(os.path.dirname(__file__))


def test_select_masks():
    rng = np.random.default_rng(0)
    F = rng.normal(size=(5, 100)); F[:, :7] = np.nan
    for d in (+1, -1):
        pool, q5, ok = G.select_masks(F, d, min_n=50)
        assert ok.all() and (pool == np.isfinite(F)).all()
        for t in range(5):
            n = int(pool[t].sum()); s = d * F[t][pool[t]]
            top = s >= np.sort(s)[-int(np.ceil(0.2 * n))]
            assert q5[t].sum() == top.sum() == 19, (q5[t].sum(), top.sum())     # n=93 -> 상위 19(5*r>4n)
            assert set(np.where(q5[t])[0]) == set(np.where(pool[t])[0][top])
    # 최소 종목 수 미만 -> 선택 없음
    pool, q5, ok = G.select_masks(F, +1, min_n=94)
    assert not ok.any() and not pool.any() and not q5.any()
    # 동률: 전부 같은 값 -> 모두 같은 분위(ceil(5*(n+1)/2/n)=3) -> Q5 비어 있음
    pool, q5, ok = G.select_masks(np.ones((1, 60)), +1, min_n=50)
    assert ok[0] and pool[0].all() and not q5[0].any()
    # 행 독립성(미래 행 교란 불변)
    F2 = F.copy(); F2[3:] = rng.normal(size=F2[3:].shape)
    _, a, _ = G.select_masks(F, +1, 50); _, b, _ = G.select_masks(F2, +1, 50)
    assert (a[:3] == b[:3]).all()


def rand_panel(T, M, seed, nan_frac=0.15):
    rng = np.random.default_rng(seed)
    Y = rng.normal(size=(T, M)); Y[rng.random((T, M)) < nan_frac] = np.nan
    P = rng.random((T, M)) < 0.8
    Q = P & (rng.random((T, M)) < 0.25)
    return Q, P, Y


def test_numba_vs_ref():
    for seed in range(4):
        Q, P, Y = rand_panel(60, 70, seed)
        for s in (0, 1, 17, 59):
            a = G.excess_days_nb(Q, P, Y, s); b = G.excess_days_ref(Q, P, Y, s)
            for x, y in zip(a, b):
                np.testing.assert_allclose(x, y, equal_nan=True, atol=1e-12)
    # 빈 Q5 일: NaN
    Q = np.zeros((3, 10), bool); P = np.ones((3, 10), bool); Y = np.ones((3, 10))
    assert np.isnan(G.excess_days(Q, P, Y, 0)[0]).all()


def hand_panel():
    """N=40일, M=5종목. 신호일 t=10 한 개, h=5. 종목 0~4:
    0: 매일 +2%, 1: 매일 -1%, 2: t+3 이후 무거래(NaN, ffill로 이월=L2 청산가), 3: 평탄, 4: 선택 제외용."""
    N, M, h = 40, 5, 5
    d = np.arange(N)
    Cl = np.vstack([100 * 1.02 ** d, 100 * 0.99 ** d, 100 * 1.03 ** d, np.full(N, 100.0), 100 * 1.05 ** d]).T
    O = np.vstack([np.r_[100.0, Cl[:-1, j]] for j in range(M)]).T          # 시가 = 전일 종가
    Cn = Cl.copy(); Cn[14:, 2] = np.nan; On = O.copy(); On[14:, 2] = np.nan  # 종목2: 14일(=t+4)부터 무거래
    return O, Cl, On, Cn, h


def test_path_identity_and_cost():
    O, Cl, On, Cn, h = hand_panel()
    N, M = O.shape
    Clf = pd.DataFrame(Cn).ffill().values
    tpos = np.array([10]); c = C.G2_COST_RT
    W = np.array([[True, True, True, True, False]])
    ret = G.daily_path(W, On, Clf, tpos, h)
    # 수기: 진입 = t+1(=11) 시가, 청산 = t+h(=15) 종가. 종목2는 13일 종가까지 유효, 이후 ffill(L2 청산가=13일 종가)
    entry = On[11]; exitp = np.array([Cn[15, 0], Cn[15, 1], Cn[13, 2], Cn[15, 3], np.nan])
    t1 = exitp / entry - 1
    mean_t1 = np.nanmean(t1[:4])
    # 슬롯 경로 복리 = (1+평균 T1)(1-비용). 슬롯 비중 1/h이므로 일수익률*h로 되돌려 복리.
    days = tpos[0] + np.arange(1, h + 1)
    comp = np.prod(1 + ret[days] * h)
    assert abs(comp - (1 + mean_t1) * (1 - c)) < 1e-12, (comp, (1 + mean_t1) * (1 - c))
    assert np.allclose(ret[:11], 0) and np.allclose(ret[16:], 0)
    # 첫날 수익률: 진입 시가→종가 (시가=전일종가)
    first = np.mean([Cn[11, j] / On[11, j] - 1 for j in range(4)]) / h
    assert abs(ret[11] - first) < 1e-12
    # 선택 없음(빈 W) -> 현금 0
    r0 = G.daily_path(np.zeros((1, M), bool), On, Clf, tpos, h)
    assert np.allclose(r0, 0)


def test_overlap_steady_state():
    N, M, h = 80, 4, 5
    d = np.arange(N)
    Cl = np.tile((100 * 1.01 ** d)[:, None], (1, M)); O = np.vstack([np.full(M, 100.0), Cl[:-1]])
    tpos = np.arange(10, 40); W = np.ones((len(tpos), M), bool); c = C.G2_COST_RT
    ret = G.daily_path(W, O, Cl, tpos, h)
    a, b = int(tpos[0]) + h, int(tpos[-1]) + 1
    expect = 0.01 - (1.01 * c) / h      # (1/h)*[(h-1)*0.01 + (1.01*(1-c)-1)]
    # k=h 슬롯은 (V_h(1-c))/V_{h-1}-1 = 1.01(1-c)-1
    expect = ((h - 1) * 0.01 + (1.01 * (1 - c) - 1)) / h
    np.testing.assert_allclose(ret[a:b + 1], expect, atol=1e-12)
    p = G.perf(ret, a, b)
    assert abs(p["MDD"]) < 1e-12 and p["CAGR"] > 0
    # 비용 0이면 일 1%
    r0 = G.daily_path(W, O, Cl, tpos, h, cost=0.0)
    np.testing.assert_allclose(r0[a:b + 1], 0.01, atol=1e-12)
    # 하락 구간 MDD 수기 대조
    rr = np.zeros(10); rr[3] = -0.1; rr[4] = -0.1
    p2 = G.perf(rr, 0, 9)
    assert abs(p2["MDD"] - (0.9 * 0.9 - 1)) < 1e-12


def test_null_calibration_and_power():
    T, M = 600, 80
    rng = np.random.default_rng(3)
    block = block_ids(pd.bdate_range("2018-01-02", periods=T))
    shifts = np.sort(np.random.default_rng(9).choice(np.arange(40, T - 40), size=200, replace=False))
    ps = []
    for seed in range(8):
        rg = np.random.default_rng(100 + seed)
        F = rg.normal(size=(T, M)); Y = rg.normal(size=(T, M))
        pool, q5, _ = G.select_masks(F, +1, 50)
        E = G.excess_days(q5, pool, Y, 0)[0]
        obs = G.summarize_excess(E, block)["mean_E"]
        nl = G.null_excess(q5, pool, Y, shifts, block)
        ps.append((1 + (nl[:, 0] >= obs).sum()) / (1 + len(nl)))
    assert sum(p < 0.05 for p in ps) <= 2 and max(ps) > 0.3, ps          # 위양성 통제
    F = rng.normal(size=(T, M)); Y = 0.3 * F + rng.normal(size=(T, M))     # 심은 신호
    pool, q5, _ = G.select_masks(F, +1, 50)
    E = G.excess_days(q5, pool, Y, 0)[0]
    obs = G.summarize_excess(E, block)
    nl = G.null_excess(q5, pool, Y, shifts, block)
    assert (1 + (nl[:, 0] >= obs["mean_E"]).sum()) / (1 + len(nl)) <= 1 / 201 + 1e-12 and obs["block_pos"] == 1.0
    # 순환 이동은 선택(F)을 고정하고 Y만 이동: 이동 0과 T는 동일
    a = G.excess_days(q5, pool, Y, 0)[0]; b = G.excess_days(q5, pool, Y, T - 0 if False else 0)[0]
    np.testing.assert_allclose(a, b, equal_nan=True)


def test_block_summary():
    d = pd.bdate_range("2018-01-02", periods=300); blk = block_ids(d)
    E = np.full(300, 0.01); r = G.summarize_excess(E, blk)
    assert r["block_pos"] == 1.0 and r["blocks_incl"] >= 2
    E2 = E.copy(); E2[blk == np.unique(blk)[0]] = -0.01
    r2 = G.summarize_excess(E2, blk); assert r2["block_pos"] < 1.0
    E3 = E.copy(); E3[::2] = np.nan                                       # 유효일 60 미만 블록은 제외
    assert G.summarize_excess(E3, blk)["blocks_incl"] <= r["blocks_incl"]


def test_bh_family():
    from research.d5_run import bh_adjust
    p = np.array([0.001, 0.02, 0.04]); adj = bh_adjust(p)
    assert (R.bh_reject(p, 0.10) == (adj <= 0.10)).all()


def test_module_separation():
    def imports(fn):
        tree = ast.parse(open(os.path.join(ROOT, fn)).read()); out = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom) and n.module is not None and n.level >= 1:
                out.add(n.module)
        return out
    for fn in ("gate2.py", "gate2_run.py"):
        im = imports(fn); assert "features" not in im and "targets" not in im, (fn, im)
    assert "features" not in imports("gate2_prep.py")


def synth_prep(T=1150, h_list=(5, 10, 20), M=70, seed=11):
    rng = np.random.default_rng(seed)
    N = T + 60
    r = rng.normal(0.0003, 0.02, size=(N, M)); Cl = 100 * np.cumprod(1 + r, axis=0)
    O = np.vstack([np.full(M, 100.0), Cl[:-1]]) * (1 + rng.normal(0, 0.002, size=(N, M)))
    Cl[N - 30:, 3] = np.nan; O[N - 30:, 3] = np.nan                       # 종목 3: 종료 쪽 무거래 구간(전체 테스트 범위 밖)
    dates = pd.bdate_range("2018-01-02", periods=N)
    tpos = np.arange(0, T); idx = dates[tpos]
    out = {"O": O, "Clf": pd.DataFrame(Cl).ffill().values, "h": {}}
    for h in h_list:
        T1 = out["Clf"][tpos + h] / O[tpos + 1] - 1
        sig_future = np.log1p(T1)                                         # 심은 신호용(미래 정보, 합성 전용)
        Fd = {}
        for k in ("REV", "RISK", "ATTN", "LIQ"):
            noise = rng.normal(size=T1.shape)
            if k == "LIQ":
                Fd[k] = sig_future / sig_future.std() * 0.6 + noise       # 방향 +1, 강한 신호
            else:
                Fd[k] = noise                                              # null
        out["h"][h] = {"dates": idx, "block": block_ids(idx), "tpos": tpos, "T1": T1,
                       "status": np.zeros(T1.shape, np.int8), "DV": np.exp(rng.normal(size=T1.shape)), "F": Fd}
    return out


def test_end_to_end():
    prep = synth_prep()
    with tempfile.TemporaryDirectory() as d:
        df, meta = R.run_gate2(prep, d, None, log=lambda *_: None)
        assert len(df) == 11 and meta["후보"] == 11
        assert os.path.exists(os.path.join(d, "gate2_results.csv")) and os.path.exists(os.path.join(d, "gate2_summary.json"))
        liq = df[df.feature == "LIQ"]
        assert (liq["s3_절대순수익>0"]).all() and np.allclose(df["Q5절대순수익(트랜치,h일)"], df["Q5평균_gross(트랜치,h일)"] - C.G2_COST_RT)
        assert (liq["판정"] == "통과").all(), liq[["h", "p_E", "bh_q", "블록양비율", "블록임계", "판정"]]
        oth = df[df.feature != "LIQ"]
        assert (oth["판정"] != "통과").sum() >= 6, oth[["feature", "h", "p_E", "bh_q", "판정"]]    # null Feature 대부분 불통과
        # 재실행(체크포인트 이어받기) 동일 결과
        df2, _ = R.run_gate2(prep, d, None, log=lambda *_: None)
        pd.testing.assert_frame_equal(df.drop(columns=[]), df2)
        # 다른 입력으로 같은 폴더 사용 시 거부
        prep2 = synth_prep(seed=12)
        try:
            R.run_gate2(prep2, d, None, log=lambda *_: None); raise RuntimeError("지문 불일치를 거부해야 함")
        except AssertionError:
            pass
        # 사전등록 상수 변경 시 거부
        old = C.G2_COST_RT; C.G2_COST_RT = 0.003
        try:
            R.run_gate2(prep, tempfile.mkdtemp(), None, log=lambda *_: None); raise RuntimeError("상수 변경을 거부해야 함")
        except AssertionError:
            pass
        finally:
            C.G2_COST_RT = old
        # 선택 종목의 풀 제약: Q5 평균 종목수 약 풀의 20%
        assert 0.15 < (liq["일평균 Q5 종목수"].mean() / 70) < 0.25
        # 비용 항등: 경로 CAGR(비용 후)은 비용 0 가정 결과보다 낮아야 한다
    # break-even 부호 일관성
    assert np.isfinite(df["break_even_절대_bp"]).all() and np.isfinite(df["break_even_초과_bp"]).all()
    assert (liq["break_even_초과_bp"] > 0).all()


def test_abs_net_condition():
    """필수조건 ③: 같은 입력에서 비용만 키우면 s1·s2는 그대로이고 ③만 실패해 판정이 '실패'가 된다(풀 대비 초과는 비용 무관)."""
    prep = synth_prep()
    with tempfile.TemporaryDirectory() as d:
        base = R.evaluate(prep, "LIQ", 5, d)
        old = C.G2_COST_RT
        try:
            C.G2_COST_RT = 0.5
            hi = R.evaluate(prep, "LIQ", 5, d)          # null 파일 재사용(선택·T1 동일)
        finally:
            C.G2_COST_RT = old
        assert base["Q5절대순수익(트랜치,h일)"] > 0 and hi["Q5절대순수익(트랜치,h일)"] < 0
        assert base["p_E"] == hi["p_E"] and base["평균E_gross(트랜치,h일)"] == hi["평균E_gross(트랜치,h일)"]    # 초과는 비용 불변


def test_dollar_volume_pit():
    from research.gate2_prep import dollar_volume_20
    rng = np.random.default_rng(2)
    ix = pd.bdate_range("2018-01-02", periods=60)
    c = pd.DataFrame(np.exp(rng.normal(size=(60, 4))), index=ix); v = pd.DataFrame(np.exp(rng.normal(size=(60, 4))), index=ix)
    o = pd.DataFrame(False, index=ix, columns=c.columns)
    a = dollar_volume_20(c, v, o)
    c2, v2 = c.copy(), v.copy(); c2.iloc[40:] *= 9; v2.iloc[40:] *= 5
    pd.testing.assert_frame_equal(a.iloc[:40], dollar_volume_20(c2, v2, o).iloc[:40])      # 후행성(미래 교란 불변)
    o2 = o.copy(); o2.iloc[30, 0] = True
    assert abs(dollar_volume_20(c, v, o2).iloc[35, 0] - a.iloc[35, 0]) > 0


def test_pipeline_integration():
    """합성 월드를 실제 run() 경로로 처리 -> prepare_g2 -> 슬롯 경로 항등: 단일 트랜치 복리 = (1+평균 T1)(1-비용)(L2·일시정지 포함)."""
    from research.run_d3d4 import run
    from research.gate2_prep import prepare_g2, dollar_volume_20
    from research.tests.test_synthetic import make_world
    with tempfile.TemporaryDirectory() as tmp:
        paths = make_world(tmp)
        D, U, parts, F, labels = run(*paths, verbose=False)
        DV = dollar_volume_20(D["close"], D["volume"], D["outlier"])
        prep = prepare_g2(D, U, F, labels, DV, [5, 10])
        for h in (5, 10):
            P = prep["h"][h]; T1 = P["T1"]; tpos = P["tpos"]
            assert P["F"]["REV"].shape == T1.shape and P["DV"].shape == T1.shape
            pool, q5, ok = G.select_masks(P["F"]["REV"], C.FEATURE_DIRECTION["REV"], min_n=5)
            fin = np.isfinite(T1)
            checked = 0
            for i in range(0, len(tpos), 7):
                for W in (pool[i:i + 1] & fin[i:i + 1], q5[i:i + 1] & fin[i:i + 1]):
                    if W.sum() == 0:
                        continue
                    ret = G.daily_path(W, prep["O"], prep["Clf"], tpos[i:i + 1], h)
                    comp = np.prod(1 + ret[tpos[i] + np.arange(1, h + 1)] * h)
                    exp = (1 + T1[i][W[0]].mean()) * (1 - C.G2_COST_RT)
                    assert abs(comp - exp) < 1e-10, (h, i, comp, exp)
                    checked += 1
            assert checked > 20, checked
        assert int((prep["h"][5]["status"] == 1).sum()) > 0       # L2 청산 사례가 합성 월드에 존재


def test_gate1_candidates_check():
    with tempfile.TemporaryDirectory() as d:
        rows = [{"feature": k, "h": h, "s3_quant": True} for k, h in R.CANDS]
        pd.DataFrame(rows).to_csv(os.path.join(d, "g.csv"), index=False)
        assert R.check_cands_vs_gate1(os.path.join(d, "g.csv")) == 11
        rows2 = rows[:-1] + [{"feature": "MOM", "h": 5, "s3_quant": True}]
        pd.DataFrame(rows2).to_csv(os.path.join(d, "g2.csv"), index=False)
        try:
            R.check_cands_vs_gate1(os.path.join(d, "g2.csv")); raise RuntimeError("불일치 거부해야 함")
        except AssertionError:
            pass


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("ok", name)
    print("ALL PASS")
