"""g2_diag 합성 검증: 기여 분해 항등, 수기 대조, 브루트포스 제외 재계산, 연도 가중평균, 분위, 모듈 분리, 입력 불변."""
import ast, copy, os, tempfile
import numpy as np
import pandas as pd
from research import config as C
from research import gate2 as G
from research import g2_diag as D
from research.tests.test_gate2 import synth_prep

ROOT = os.path.dirname(os.path.dirname(__file__))


def make(seed=11, T=900, M=70):
    prep = synth_prep(T=T, h_list=(5, 10, 20), M=M, seed=seed)
    rng = np.random.default_rng(5)
    group = rng.choice(["439", "A", "B"], size=M, p=[0.2, 0.2, 0.6])
    px = {h: prep["Clf"][prep["h"][h]["tpos"]] for h in (5, 10, 20)}
    return prep, px, group


def test_hand_contribution():
    """T=3,M=4 수기: Q5={0,1}(2일째 {1}), 풀 전체. c_tj=(y-풀평균)/nq, E_t=Σc."""
    Y = np.array([[0.10, 0.02, -0.04, 0.00], [0.05, 0.01, 0.03, 0.01], [np.nan, 0.06, 0.02, 0.00]])
    P = np.ones((3, 4), bool)
    Q = np.array([[1, 1, 0, 0], [0, 1, 0, 0], [1, 1, 0, 0]], bool)
    c, n = D._contrib(Q, P, Y)
    assert n == 3
    mp0 = np.mean([0.10, 0.02, -0.04, 0.00]); mp1 = np.mean([0.05, 0.01, 0.03, 0.01]); mp2 = np.mean([0.06, 0.02, 0.00])
    exp = np.zeros((3, 4))
    exp[0, 0] = (0.10 - mp0) / 2; exp[0, 1] = (0.02 - mp0) / 2
    exp[1, 1] = (0.01 - mp1) / 1
    exp[2, 1] = (0.06 - mp2) / 1                      # 종목0 T1=NaN -> Q5 유효 1개
    np.testing.assert_allclose(c, exp, atol=1e-15)
    E = G.excess_days(Q, P, Y, 0)[0]
    np.testing.assert_allclose(c.sum(1), E, atol=1e-15)


def test_decomposition_identity_and_baseline():
    prep, px, group = make()
    for k, h in D.DIAG_CANDS:
        r = D.diag_one(prep, px[h], group, k, h)
        P = prep["h"][h]
        pool, q5, _ = G.select_masks(P["F"][k], C.FEATURE_DIRECTION[k])
        E, mq, mp, nq = G.excess_days(q5, pool, P["T1"], 0)
        ok = np.isfinite(E)
        assert abs(r["base"]["평균E"] - E[ok].mean()) < 1e-15
        assert abs(r["base"]["Q5절대순수익"] - (mq[np.isfinite(mq)].mean() - C.G2_COST_RT)) < 1e-15
        b = r["conc"].iloc[0]
        assert b["구분"].startswith("기준") and abs(b["평균E"] - r["base"]["평균E"]) < 1e-15       # 기준 행 = Gate 2
        # 연도 가중평균 = 전체 평균
        y = r["year"]; assert abs((y["평균E(h일)"] * y["평가일"]).sum() / y["평가일"].sum() - r["base"]["평균E"]) < 1e-12
        assert y["평가일"].sum() == r["base"]["평가일"]


def test_bruteforce_exclusion():
    prep, px, group = make(seed=21, T=600, M=50)
    k, h = "LIQ", 5
    r = D.diag_one(prep, px[h], group, k, h)
    P = prep["h"][h]
    pool, q5, _ = G.select_masks(P["F"][k], C.FEATURE_DIRECTION[k])
    T1 = P["T1"]; Qf = q5 & np.isfinite(T1); Pf = pool & np.isfinite(T1)
    # 브루트포스: 일별 루프로 거래 기여 → 종목별 합 → 상위 3 제외 → 재계산
    S = np.zeros(T1.shape[1]); nd = 0
    for t in range(T1.shape[0]):
        qi = np.where(Qf[t])[0]; pi = np.where(Pf[t])[0]
        if len(qi) and len(pi):
            mpv = T1[t, pi].mean()
            for j in qi:
                S[j] += (T1[t, j] - mpv) / len(qi)
            nd += 1
    top3 = np.argsort(-S)[:3]
    ex = np.zeros(T1.shape[1], bool); ex[top3] = True
    vals = []
    for t in range(T1.shape[0]):
        qi = np.where(Qf[t] & ~ex)[0]; pi = np.where(Pf[t] & ~ex)[0]
        if len(qi) and len(pi):
            vals.append(T1[t, qi].mean() - T1[t, pi].mean())
    row = r["conc"][r["conc"]["구분"].str.startswith("상위 3종목")].iloc[0]
    assert abs(row["평균E"] - np.mean(vals)) < 1e-12, (row["평균E"], np.mean(vals))
    assert abs(row["상위기여 합/전체E합"] - S[top3].sum() / S.sum()) < 1e-12


def test_trim_monotone_and_terciles():
    prep, px, group = make(seed=31)
    r = D.diag_one(prep, px[10], group, "LIQ", 10)
    c = r["conc"]
    base = c.iloc[0]["평균E"]
    trims = c[c["구분"].str.contains("절단")]["평균E"].values
    assert len(trims) == 3 and all(trims[i] >= trims[i + 1] - 1e-15 for i in range(2)) and trims[0] <= base + 1e-15   # 더 많이 자를수록 E 감소
    comp = r["comp"]
    for col in ("Q5", "풀"):
        assert abs(comp[comp["항목"].str.startswith("그룹")][col].sum() - 1.0) < 1e-12
        assert abs(comp[comp["항목"].str.startswith("거래대금") & comp["항목"].str.contains("분위")][col].sum() - 1.0) < 1e-12
    t = r["terc"]; assert list(t["분위"]) == ["저", "중", "고"]
    # 분위별 절대 순수익 = 분위 내 Q5 평균 gross - 비용
    assert np.allclose(t["Q5절대순수익(h일)"], t["Q5평균gross(h일)"] - C.G2_COST_RT)
    assert abs(r["conc_meta"]["그룹439_E기여비중"] + r["conc_meta"]["그룹A_E기여비중"] + r["conc_meta"]["그룹B_E기여비중"] - 1.0) < 1e-9


def test_inputs_not_mutated_and_gate2_check():
    prep, px, group = make(seed=41, T=500, M=70)
    before = copy.deepcopy(prep["h"][5]["F"]["LIQ"]); b2 = prep["h"][5]["T1"].copy(); b3 = px[5].copy(); b4 = group.copy()
    res = D.run_diag(prep, px, group, cands=[("LIQ", 5), ("RISK", 10)], log=lambda *_: None)
    assert np.array_equal(before, prep["h"][5]["F"]["LIQ"], equal_nan=True) and np.array_equal(b2, prep["h"][5]["T1"], equal_nan=True)
    assert np.array_equal(b3, px[5], equal_nan=True) and (b4 == group).all()
    with tempfile.TemporaryDirectory() as d:
        rows = [{"feature": k, "h": h, "평균E_gross(트랜치,h일)": r["base"]["평균E"], "Q5절대순수익(트랜치,h일)": r["base"]["Q5절대순수익"]} for (k, h), r in res.items()]
        pd.DataFrame(rows).to_csv(os.path.join(d, "g.csv"), index=False)
        assert D.check_against_gate2(res, os.path.join(d, "g.csv")) == 2
        rows[0]["평균E_gross(트랜치,h일)"] += 1e-6
        pd.DataFrame(rows).to_csv(os.path.join(d, "g2.csv"), index=False)
        try:
            D.check_against_gate2(res, os.path.join(d, "g2.csv")); raise RuntimeError("불일치를 거부해야 함")
        except AssertionError:
            pass
        D.save_report(res, os.path.join(d, "out"))
        for f in ("comp", "conc", "year", "terc", "conc_meta"):
            assert os.path.exists(os.path.join(d, "out", f"g2_diag_{f}.csv"))
        lines = []; D.print_report(res, out=lines.append); assert any("(4)" in s for s in lines)


def test_planted_concentration_detected():
    """한 종목에 거대한 수익을 심으면 그 종목 제외 시 E가 크게 하락하고 상위1종목 비중이 커야 한다."""
    prep, px, group = make(seed=51, T=700, M=60)
    P = prep["h"][5]
    pool, q5, _ = G.select_masks(P["F"]["LIQ"], +1)
    j = int(np.argmax(q5.sum(0)))
    P["T1"][:, j] = np.where(q5[:, j], 0.5, P["T1"][:, j])
    r = D.diag_one(prep, px[5], group, "LIQ", 5)
    c = r["conc"]
    assert r["conc_meta"]["상위1종목 E기여/전체"] > 0.1
    assert c.iloc[1]["평균E"] < c.iloc[0]["평균E"] * 0.8


def test_module_separation():
    tree = ast.parse(open(os.path.join(ROOT, "g2_diag.py")).read()); im = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom) and n.module is not None and n.level >= 1:
            im.add(n.module)
    assert "features" not in im and "targets" not in im and "gate2_run" not in im, im


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("ok", name)
    print("ALL PASS")
