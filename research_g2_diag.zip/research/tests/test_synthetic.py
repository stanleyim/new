"""합성 데이터 검증: 로더 e2e, 유니버스, Feature/라벨 누수(절단·교란 불변성), 수기 계산, 날짜 마스크, 모듈 분리."""
import ast, os, sys, tempfile
import numpy as np
import pandas as pd
from research import config as C
from research.data_loader import load_all
from research.universe import build_universe
from research.features import compute_features
from research.targets import build_labels, targets_from, OK, L2, TEMP_HALT, ENTRY_FAIL, OUTLIER, NOT_UNIV
from research.run_d3d4 import run

ROOT = os.path.dirname(os.path.dirname(__file__))


def make_world(tmp, seed=0):
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2017-01-02", "2023-02-28")
    def series(p0=100.0):
        r = rng.normal(0, 0.02, len(cal)); close = p0 * np.exp(np.cumsum(r))
        opn = close * (1 + rng.normal(0, 0.005, len(cal))); vol = rng.integers(1000, 100000, len(cal)).astype(float)
        return pd.DataFrame({"date": cal, "open": opn, "high": opn, "low": opn, "close": close, "volume": vol})
    t439 = ["000010", "000020", "000030", "000040", "000050", "232680", "000140", "000155"]
    kis = {"000100": series(), "000110": series(), "000130": series(), "000160": series()}
    # 000100: 2020-06-30 이후 행 없음(폐지) -> L2 / 000110: 2019-03 일시정지(volume=0) / 000160: 거래 드문 종목
    kis["000100"] = kis["000100"][kis["000100"]["date"] <= "2020-06-30"]
    m = (kis["000110"]["date"] >= "2019-03-01") & (kis["000110"]["date"] <= "2019-03-20")
    kis["000110"].loc[m, "volume"] = 0
    d = kis["000160"]; d.loc[rng.random(len(d)) < 0.5, "volume"] = 0
    rows = []
    for tk in t439:
        s = series(); s["ticker"] = int(tk) if tk.isdigit() else tk; s["name"] = tk; rows.append(s)
    full = pd.concat(rows); full = full.rename(columns={"open": "시가", "close": "종가", "volume": "거래량", "high": "고가", "low": "저가"})
    full["등락률"] = 0.0; full["date"] = full["date"].dt.strftime("%Y-%m-%d")
    full.to_parquet(os.path.join(tmp, "ohlcv_full.parquet"))
    os.makedirs(os.path.join(tmp, "kis"), exist_ok=True)
    for tk, df in kis.items():
        df = df.copy(); df["date"] = df["date"].dt.strftime("%Y-%m-%d"); df.to_parquet(os.path.join(tmp, "kis", f"{tk}.parquet"))
    os.makedirs(os.path.join(tmp, "pit"), exist_ok=True)
    allt = t439 + list(kis)
    snaps = pd.date_range("2016-12-01", "2023-02-01", freq="MS")
    sec = []
    for s in snaps:
        for tk in allt:
            sec.append({"date": s.strftime("%Y-%m-%d"), "ticker": tk, "종목명": "이호스팩" if tk == "000140" else f"종목{tk}"})
    sec = pd.DataFrame(sec)
    for y in sorted(set(pd.to_datetime(sec["date"]).dt.year)):
        sec[pd.to_datetime(sec["date"]).dt.year == y].to_parquet(os.path.join(tmp, "pit", f"sector_{y}.parquet"))
    return (os.path.join(tmp, "ohlcv_full.parquet"), os.path.join(tmp, "kis"), os.path.join(tmp, "pit", "sector_*.parquet"))


def test_loader_universe_features_targets():
    with tempfile.TemporaryDirectory() as tmp:
        paths = make_world(tmp)
        D = load_all(*paths)
        assert D["calendar"].max() <= C.SIGNAL_END and D["close"].index.max() <= C.SIGNAL_END       # 날짜 마스크
        assert D["meta"].loc["000130", "continues"] and not D["meta"].loc["000100", "continues"]
        assert D["meta"].loc["000100", "group"] == "A" or D["meta"].loc["000100", "group"] == "B"
        assert D["meta"].loc["000010", "group"] == "439"
        assert D["outlier"].values.sum() == 1 and D["outlier"].loc["2021-06-17", "232680"]
        U, parts = build_universe(D["valid"], D["names"], D["calendar"])
        sig = (U.index >= C.SIGNAL_START)
        assert not U["000155"].any(), "우선주 포함"                       # 끝글자 5
        assert not U.loc[sig & (U.index > "2017-02-01"), "000140"].any(), "스팩 포함"
        assert U.loc["2018-06-01":"2018-06-29", "000010"].all()
        # 15/20 규칙: 000160(약 50% 무거래)은 일부 날만 통과
        frac = U.loc[sig, "000160"].mean(); assert 0 < frac < 0.5, frac
        F = compute_features(D["close"], D["volume"], D["outlier"])
        assert set(F) == {"REV", "MOM", "RISK", "ATTN", "LIQ", "ANCH"}
        # 이상치 윈도우 NaN
        i = D["calendar"].get_loc(pd.Timestamp("2021-06-17"))
        for k, w in C.FEATURE_SPAN.items():
            assert F[k]["232680"].iloc[i:i + w].isna().all(), k
        # 직접 계산 대조 (000010, 임의일)
        c, v = D["close"]["000010"], D["volume"]["000010"]; j = 700
        assert abs(F["REV"]["000010"].iloc[j] - (c.iloc[j] / c.iloc[j - 5] - 1)) < 1e-12
        assert abs(F["MOM"]["000010"].iloc[j] - (c.iloc[j - 5] / c.iloc[j - 60] - 1)) < 1e-12
        assert abs(F["ANCH"]["000010"].iloc[j] - c.iloc[j] / c.iloc[j - 119:j + 1].max()) < 1e-12
        r = c / c.shift(1) - 1
        assert abs(F["RISK"]["000010"].iloc[j] - r.iloc[j - 59:j + 1].std()) < 1e-12
        assert abs(F["ATTN"]["000010"].iloc[j] - v.iloc[j - 4:j + 1].mean() / v.iloc[j - 59:j + 1].mean()) < 1e-12
        assert abs(F["LIQ"]["000010"].iloc[j] - (r.abs() / (c * v)).iloc[j - 19:j + 1].mean()) < 1e-15
        # 라벨: 폐지 종목 L2, 일시정지 NaN
        cont = D["meta"]["continues"].values
        res = build_labels(D["open"], D["close"], D["valid"], D["outlier"], U, cont, 20)
        st = res["status"]
        assert (st["000100"] == L2).any(), "L2 청산 없음"
        assert (st["000110"] == TEMP_HALT).any(), "일시정지 없음"
        assert (st["232680"] == OUTLIER).any()
        assert res["status"].index.min() >= C.SIGNAL_START and res["status"].index.max() <= C.SIGNAL_END
        # 마지막 신호일은 라벨 종료가 구간을 넘으므로 제외
        assert res["status"].index.max() < D["calendar"][-1]
        tg = targets_from(res, "L2"); tg1 = targets_from(res, "L1")
        assert tg["T1"].notna().values.sum() > tg1["T1"].notna().values.sum()
        # 진단 러너 e2e(크래시 방지)
        run(*paths, verbose=True)


def test_feature_leak_invariance():
    with tempfile.TemporaryDirectory() as tmp:
        D = load_all(*make_world(tmp, seed=1))
        K = 900
        F = compute_features(D["close"], D["volume"], D["outlier"])
        Ft = compute_features(D["close"].iloc[:K], D["volume"].iloc[:K], D["outlier"].iloc[:K])           # 절단
        rng = np.random.default_rng(5)
        c2, v2 = D["close"].copy(), D["volume"].copy()
        c2.iloc[K:] = c2.iloc[K:] * rng.uniform(0.5, 2, c2.iloc[K:].shape); v2.iloc[K:] = v2.iloc[K:] * rng.uniform(0.1, 9, v2.iloc[K:].shape)
        Fp = compute_features(c2, v2, D["outlier"])                                                         # 미래 교란
        for k in F:
            a, b, p = F[k].iloc[:K], Ft[k], Fp[k].iloc[:K]
            np.testing.assert_allclose(a.values, b.values, equal_nan=True, err_msg=f"절단 {k}")
            np.testing.assert_allclose(a.values, p.values, equal_nan=True, err_msg=f"교란 {k}")


def test_universe_and_label_invariance():
    with tempfile.TemporaryDirectory() as tmp:
        D = load_all(*make_world(tmp, seed=2))
        cal = D["calendar"]; K = 900
        U, _ = build_universe(D["valid"], D["names"], cal)
        V2 = D["valid"].copy(); V2.iloc[K:] = ~V2.iloc[K:]
        U2, _ = build_universe(V2, D["names"], cal)
        assert (U.iloc[:K].values == U2.iloc[:K].values).all(), "유니버스 미래 의존"
        cont = D["meta"]["continues"].values
        r1 = build_labels(D["open"], D["close"], D["valid"], D["outlier"], U, cont, 10)
        # T 이하 데이터 교란 -> 해당 T 라벨 불변
        T0 = 800; o2, c2 = D["open"].copy(), D["close"].copy()
        o2.iloc[:T0 + 1] = o2.iloc[:T0 + 1] * 1.7; c2.iloc[:T0 + 1] = c2.iloc[:T0 + 1] * 0.6
        r2 = build_labels(o2, c2, D["valid"], D["outlier"], U, cont, 10)
        d0 = cal[T0]
        np.testing.assert_allclose(r1["t1"].loc[d0].values, r2["t1"].loc[d0].values, equal_nan=True)
        # T+1 교란 -> 라벨 변화(민감도 확인)
        o3 = D["open"].copy(); o3.iloc[T0 + 1] = o3.iloc[T0 + 1] * 1.5
        r3 = build_labels(o3, D["close"], D["valid"], D["outlier"], U, cont, 10)
        assert not np.allclose(r1["t1"].loc[d0].values, r3["t1"].loc[d0].values, equal_nan=True)


def test_handcalc_targets():
    idx = pd.bdate_range("2018-01-02", periods=10)
    cols = list("abcde")
    nan = np.nan
    op = pd.DataFrame(100.0, index=idx, columns=cols); cl = pd.DataFrame(100.0, index=idx, columns=cols)
    cl.loc[idx[5], "a"] = 110.0                       # a: 진입 100 -> 청산 110
    cl.loc[idx[3], "b"] = 90.0; op.loc[idx[4:], "b"] = nan; cl.loc[idx[4:], "b"] = nan   # b: idx3 이후 거래 없음 -> L2 청산 90
    cl.loc[idx[5], "c"] = nan; op.loc[idx[5], "c"] = nan                                  # c: T+5 일시정지, 이후 거래 재개
    op.loc[idx[1], "d"] = nan                                                             # d: 진입불가
    O = pd.DataFrame(False, index=idx, columns=cols); O.loc[idx[3], "e"] = True          # e: 이상치
    V = op.notna() & cl.notna()
    U = pd.DataFrame(True, index=idx, columns=cols)
    cont = np.array([True, False, True, True, True])
    res = build_labels(op, cl, V, O, U, cont, 5)
    s = res["status"].iloc[0]
    assert (s["a"], s["b"], s["c"], s["d"], s["e"]) == (OK, L2, TEMP_HALT, ENTRY_FAIL, OUTLIER), s.to_dict()
    t2 = targets_from(res, "L2"); t1 = targets_from(res, "L1")
    assert abs(t2["T1"].iloc[0]["a"] - 0.10) < 1e-12 and abs(t2["T1"].iloc[0]["b"] + 0.10) < 1e-12
    assert abs(t2["T3"].iloc[0]["a"] - 0.10) < 1e-12 and abs(t2["T3"].iloc[0]["b"] + 0.10) < 1e-12
    assert t2["T2"].iloc[0]["a"] == 1.0 and t2["T2"].iloc[0]["b"] == 0.5
    assert t2["T1"].iloc[0][["c", "d", "e"]].isna().all()
    assert t1["T1"].iloc[0]["b"] != t1["T1"].iloc[0]["b"] and abs(t1["T3"].iloc[0]["a"]) < 1e-12   # L1: b NaN, a 단독 -> T3=0
    # 유니버스 외 -> NOT_UNIV
    U2 = U.copy(); U2["a"] = False
    assert build_labels(op, cl, V, O, U2, cont, 5)["status"].iloc[0]["a"] == NOT_UNIV
    # 날짜 마스크: 상한 이후 날짜 입력 시 거부
    late = pd.bdate_range("2022-12-28", periods=6)
    try:
        build_labels(pd.DataFrame(1.0, index=late, columns=["a"]), pd.DataFrame(1.0, index=late, columns=["a"]),
                     pd.DataFrame(True, index=late, columns=["a"]), pd.DataFrame(False, index=late, columns=["a"]),
                     pd.DataFrame(True, index=late, columns=["a"]), np.array([True]), 5)
        raise SystemExit("날짜 마스크 미작동")
    except AssertionError:
        pass


def test_module_separation():
    def imports(fn):
        tree = ast.parse(open(os.path.join(ROOT, fn), encoding="utf-8").read()); out = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom): out.add((n.module or "") + "|" + ",".join(a.name for a in n.names))
            if isinstance(n, ast.Import): out |= {a.name for a in n.names}
        return " ".join(out)
    assert "targets" not in imports("features.py") and "features" not in imports("targets.py")


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(ROOT))
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
    print("ALL PASS")
