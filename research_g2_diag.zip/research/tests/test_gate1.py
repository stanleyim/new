"""D5 Gate 1 합성 검증: numba↔참조 구현 일치, Spearman, 분위 규칙, T1/T2/T3 동치, 순환 이동, BH, 검정력/위양성, 마스크 전용 메타, 모듈 분리."""
import ast, os, sys, tempfile
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from research import config as C
from research import gate1
from research.gate1 import (daily_stats_nb, daily_stats_ref, summarize, make_shifts, null_stats, emp_p, bh_reject, block_ids)

ROOT = os.path.dirname(os.path.dirname(__file__))


def rand_panel(T=40, M=120, seed=0, ties=True, nan_frac=0.2):
    rng = np.random.default_rng(seed)
    F = rng.normal(size=(T, M)); Y = rng.normal(size=(T, M))
    if ties:
        F = np.round(F, 1)
    F[rng.random((T, M)) < nan_frac] = np.nan; Y[rng.random((T, M)) < nan_frac] = np.nan
    return F, Y


def test_numba_vs_ref_and_spearman():
    for seed in range(5):
        F, Y = rand_panel(seed=seed)
        a = daily_stats_nb(F, Y, 50, True); b = daily_stats_ref(F, Y, 50, True)
        np.testing.assert_allclose(a[0], b[0], equal_nan=True, atol=1e-12)
        np.testing.assert_allclose(a[1], b[1], equal_nan=True, atol=1e-12)
        assert (a[2] == b[2]).all()
        for t in range(F.shape[0]):                       # scipy spearmanr 대조
            m = np.isfinite(F[t]) & np.isfinite(Y[t])
            if m.sum() >= 50:
                assert abs(a[0][t] - spearmanr(F[t][m], Y[t][m])[0]) < 1e-12


def test_quantile_rule():
    # 서로 다른 값 10개 -> ceil(5*rank/10): 순위 1,2->Q1, 3,4->Q2 ...
    F = np.arange(1, 11, dtype=float)[None, :]; Y = F.copy()
    _, qm, _ = daily_stats_nb(F, Y, 5, False)
    np.testing.assert_allclose(qm[0], [1.5, 3.5, 5.5, 7.5, 9.5])
    # 하위 동률이 50%면 Q1이 비어 그날 평가 불가(승인된 정의)
    F2 = np.array([[0.0] * 5 + [1.0, 2.0, 3.0, 4.0, 5.0]]); _, qm2, _ = daily_stats_nb(F2, F2.copy(), 5, False)
    assert np.isnan(qm2[0]).all()
    # 최소 종목 수 미만이면 제외
    _, qm3, nv = daily_stats_nb(F, Y, 11, True); assert np.isnan(qm3).all() and nv[0] == 10


def test_target_equivalence_and_direction():
    F, Y1 = rand_panel(T=60, M=150, seed=3, ties=False)
    Y1 = np.where(np.isfinite(F), Y1, np.nan)                  # 같은 유효 집합
    Y2 = np.full_like(Y1, np.nan); Y3 = np.full_like(Y1, np.nan)
    for t in range(Y1.shape[0]):
        m = np.isfinite(Y1[t])
        Y2[t, m] = pd.Series(Y1[t, m]).rank(pct=True).values
        Y3[t, m] = Y1[t, m] - Y1[t, m].mean()
    blk = block_ids(pd.bdate_range("2018-01-02", periods=60))
    r = {}
    for k, Y in (("1", Y1), ("2", Y2), ("3", Y3)):
        ic, qm, _ = daily_stats_nb(F, Y, 50, True); r[k] = summarize(ic, qm, blk, 1.0, 60)
    for key in ("ic_mean", "ic_t", "agree", "mono"):
        assert abs(r["1"][key] - r["2"][key]) < 1e-9 and abs(r["1"][key] - r["3"][key]) < 1e-9, key
    assert abs(r["1"]["spread"] - r["3"]["spread"]) < 1e-9          # T1=T3 스프레드 동일
    ic, qm, _ = daily_stats_nb(F, Y1, 50, True)
    rn = summarize(ic, qm, blk, -1.0, 60)
    assert abs(rn["ic_mean"] + r["1"]["ic_mean"]) < 1e-12 and abs(rn["spread"] + r["1"]["spread"]) < 1e-12


def test_shifts_and_bh():
    for h, n in ((5, 1227), (20, 1212)):
        s = make_shifts(n, h)
        assert len(s) == C.K_SHIFTS == len(set(s)) and s.min() >= 40 and s.max() <= n - 40
        assert (s == make_shifts(n, h)).all()
    assert not (make_shifts(1227, 5) == make_shifts(1227, 10)).all()
    assert list(bh_reject([0.01, 0.04, 0.03, 0.2], 0.1)) == [True, True, True, False]
    assert not bh_reject([0.5, 0.6], 0.1).any()
    assert abs(emp_p(0.5, np.array([0.1, 0.2, 0.6])) - 2 / 4) < 1e-12


def test_planted_signal_vs_noise():
    old = C.K_SHIFTS; C.K_SHIFTS = 100
    try:
        rng = np.random.default_rng(11); T, M = 400, 150
        f = np.zeros((T, M)); f[0] = rng.normal(size=M)
        for t in range(1, T):
            f[t] = 0.97 * f[t - 1] + 0.25 * rng.normal(size=M)       # 느리게 변하는 Feature
        blk = block_ids(pd.bdate_range("2018-01-02", periods=T))
        noise = rng.normal(size=(T, M))
        res = {}
        for name, Y in (("signal", 0.4 * f + noise), ("noise", noise)):
            ic, qm, _ = daily_stats_nb(f, Y, 50, True); obs = summarize(ic, qm, blk, 1.0, T)
            nl = null_stats(f, Y, make_shifts(T, 5), blk, 1.0)
            res[name] = (emp_p(obs["ic_mean"], nl[:, 0]), obs, nl)
        assert res["signal"][0] <= 0.02, res["signal"][0]            # 신호 있음 -> 검출
        assert res["noise"][0] > 0.02, res["noise"][0]               # 신호 없음 -> 비검출(고정 seed)
        assert res["signal"][1]["spread"] > np.nanpercentile(res["signal"][2][:, 2], 95)
    finally:
        C.K_SHIFTS = old


def test_meta_mask_only_and_pipeline():
    from research.d5_meta import eligibility_meta, timing
    F, Y = rand_panel(T=60, M=200, seed=5, nan_frac=0.1)
    idx = pd.bdate_range("2018-01-02", periods=60)
    P = {5: {"dates": idx, "block": block_ids(idx), "T1": Y, "T2": Y.copy(), "F": {"X": F}}}
    m1 = eligibility_meta(P)
    P2 = {5: dict(P[5], T1=np.where(np.isfinite(Y), np.random.default_rng(9).normal(size=Y.shape), np.nan))}
    pd.testing.assert_frame_equal(m1, eligibility_meta(P2))           # Y 값을 바꿔도 메타 동일(마스크 전용)
    # 파이프라인(합성 세계) 무크래시
    from research.tests.test_synthetic import make_world
    from research.run_d3d4 import run
    from research.gate1_prep import prepare
    with tempfile.TemporaryDirectory() as tmp:
        D, U, parts, Fe, labels = run(*make_world(tmp), verbose=False)
        prep = prepare(D, U, Fe, labels)
        assert set(prep) == {5, 10, 20} and set(prep[5]["F"]) == set(Fe)
        eligibility_meta(prep); timing(prep, n_shifts=1)


def test_isolation():
    def imps(fn):
        tree = ast.parse(open(os.path.join(ROOT, fn), encoding="utf-8").read()); out = []
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom): out.append((n.module or "") + "|" + ",".join(a.name for a in n.names))
            if isinstance(n, ast.Import): out += [a.name for a in n.names]
        return " ".join(out)
    assert "features" not in imps("gate1.py") and "targets" not in imps("gate1.py")
    assert "features" not in imps("gate1_prep.py") and "features" not in imps("d5_meta.py")


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(ROOT))
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
    print("ALL PASS")
