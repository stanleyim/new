"""D5 본 실행 모듈 합성 검증: BH 보정, 사전등록 가드, 체크포인트 재개 동치, 심은 신호 vs 잡음,
T3 동치(직접 계산 대조), NaN(판정 불가) 경로, 지문 가드, 모듈 분리."""
import ast, os, sys, tempfile
import numpy as np
import pandas as pd
from research import config as C
from research import d5_run as R
from research.gate1 import block_ids, daily_stats, summarize, bh_reject

ROOT = os.path.dirname(os.path.dirname(__file__))


class small_k:
    def __init__(self, k=20): self.k = k
    def __enter__(self):
        self.old = C.K_SHIFTS; C.K_SHIFTS = self.k
        self.old_pre = dict(R.PREREG); R.PREREG["K_SHIFTS"] = self.k
    def __exit__(self, *a):
        C.K_SHIFTS = self.old; R.PREREG.clear(); R.PREREG.update(self.old_pre)


def make_prep(T=400, M=150, seed=11):
    rng = np.random.default_rng(seed)
    f = np.zeros((T, M)); f[0] = rng.normal(size=M)
    for t in range(1, T):
        f[t] = 0.97 * f[t - 1] + 0.25 * rng.normal(size=M)
    idx = pd.bdate_range("2018-01-02", periods=T)
    noise = rng.normal(size=(T, M))
    Y = 0.4 * f + noise                                  # MOM(+1): 신호 있음
    Y[rng.random((T, M)) < 0.1] = np.nan
    fm = np.where(np.isfinite(Y), f, f)
    fn = rng.normal(size=(T, M))                         # REV: 순수 잡음
    fnan = np.full((T, M), np.nan)                       # RISK: 전부 결측 -> 판정 불가
    T2 = pd.DataFrame(Y).rank(axis=1, pct=True).values
    prep = {}
    for h in (5, 10, 20):
        prep[h] = {"dates": idx, "block": block_ids(idx), "T1": Y.copy(), "T2": T2.copy(), "T1_L1": Y.copy(),
                   "F": {"REV": fn.copy(), "MOM": fm.copy(), "RISK": fnan.copy()}}
    return prep


def test_bh_adjust_and_prereg():
    rng = np.random.default_rng(0)
    for _ in range(200):
        p = rng.random(9) * rng.choice([0.05, 0.3, 1.0])
        adj = R.bh_adjust(p)
        assert ((adj <= 0.1) == bh_reject(p, 0.1)).all()
        assert (adj <= 1).all() and (adj >= p - 1e-12).all()
    R.check_prereg()
    old = C.K_SHIFTS; C.K_SHIFTS = 999
    try:
        try:
            R.check_prereg(); raise SystemError("가드 미작동")
        except AssertionError:
            pass
    finally:
        C.K_SHIFTS = old


def test_resume_equivalence_and_fingerprint():
    with small_k(20):
        prep = make_prep()
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            straight = R.null_unit(prep[5], 5, "MOM", "T1", a, chunk=10)
            try:
                R.null_unit(prep[5], 5, "MOM", "T1", b, chunk=10, stop_after_chunks=1); raise SystemError("중단 미작동")
            except R.StopForTest:
                pass
            assert np.load(os.path.join(b, "null_h5_MOM_T1.part.npy")).shape == (10, 4)
            resumed = R.null_unit(prep[5], 5, "MOM", "T1", b, chunk=10)
            np.testing.assert_allclose(straight, resumed, equal_nan=True, atol=0)
            assert not os.path.exists(os.path.join(b, "null_h5_MOM_T1.part.npy"))
            # 지문 가드: 다른 입력으로 같은 폴더 재사용 시 거부
            R.run_gate1(prep, a, chunk=10, log=lambda *x: None)
            prep2 = make_prep(seed=12)
            try:
                R.run_gate1(prep2, a, chunk=10, log=lambda *x: None); raise SystemError("지문 가드 미작동")
            except AssertionError:
                pass


def test_pipeline_planted_vs_noise_nan_and_t3():
    with small_k(20):
        prep = make_prep()
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            res, meta = R.run_gate1(prep, d1, chunk=10, log=lambda *x: None)
            df = res["df"]
            assert meta["trials"] == 27 and meta["families"] == 3 and meta["independent_IC_tests"] == 9
            mom = df[df.feature == "MOM"]
            assert mom["s1_IC"].all() and (mom["p_ic"] <= 0.05).all()          # 심은 신호 검출
            assert mom["s3_quant"].all(), mom[["target", "spread", "spread_thr", "mono", "mono_thr"]]
            assert df[df.feature == "RISK"]["판정불가"].all() and (df[df.feature == "RISK"]["판정"] == "판정불가").all()
            assert not df[df.feature == "REV"]["s3_quant"].all()                  # 잡음은 전부 통과하지 않음
            # 재현성: 새 폴더에서 같은 결과, 중단 후 재개 결과와도 동일
            res2, _ = R.run_gate1(prep, d2, chunk=7, log=lambda *x: None)
            pd.testing.assert_frame_equal(df, res2["df"])
            # T3 동치: T3를 직접 계산해 T1 보고값과 대조
            P = prep[5]; Y = P["T1"]
            Y3 = Y - np.nanmean(Y, axis=1, keepdims=True)
            ic, qm, _ = daily_stats(P["F"]["MOM"], Y3, True)
            r3 = summarize(ic, qm, P["block"], C.FEATURE_DIRECTION["MOM"], Y.shape[0])
            row = df[(df.feature == "MOM") & (df.h == 5) & (df.target == "T3")].iloc[0]
            for key, col in (("ic_mean", "ic_mean"), ("spread", "spread"), ("mono", "mono"), ("agree", "agree")):
                assert abs(r3[key] - row[col]) < 1e-9, key
            # 보고 출력 무크래시
            R.print_report(res, meta, out=lambda *x: None)


def test_isolation():
    tree = ast.parse(open(os.path.join(ROOT, "d5_run.py"), encoding="utf-8").read()); out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom): out.append((n.module or "") + "|" + ",".join(a.name for a in n.names))
        if isinstance(n, ast.Import): out += [a.name for a in n.names]
    s = " ".join(out)
    assert "features" not in s and "targets" not in s and "universe" not in s


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(ROOT))
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
    print("ALL PASS")
