"""TL-014: 외국인 보유비율 20거래일 변화(FOR_CHG20) Gate 1. 실데이터 실행은 Colab 전용.
FOR_CHG20(t) = R(t-1) - R(t-21), R = 100×보유수량/상장주식수(지분율 컬럼 미사용), 마스터 거래일 기준 위치 이동(1거래일 지연: t-1까지의 값만 사용).
상장주식수가 윈도우(일변화 구간 t-20..t-1) 안에서 1% 넘게 바뀌었거나 양 끝점 비교로 1% 넘게 달라졌으면 NaN. forward-fill 없음. 방향 +1(보유비율 증가 → 상승 기대) 고정.
Gate 1 규칙·상수·permutation은 D5와 동일(d5_run 재사용). 이 모듈은 features/targets를 import하지 않는다(기존 Feature는 인자로 받아 진단에만 사용)."""
import contextlib
import os
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from . import config as C
from . import d5_run as R
from .data_loader import norm_ticker
from .gate1 import daily_stats

FEATURE = "FOR_CHG20"
DIRECTION = +1
WIN = 20
LAG = 1
JUMP = 0.01
HS = (5, 10, 20)


@contextlib.contextmanager
def direction_ctx():
    old = C.FEATURE_DIRECTION.get(FEATURE)
    C.FEATURE_DIRECTION[FEATURE] = DIRECTION
    try:
        yield
    finally:
        if old is None:
            C.FEATURE_DIRECTION.pop(FEATURE, None)
        else:
            C.FEATURE_DIRECTION[FEATURE] = old


def build_for_chg20(fg, cal, columns):
    """fg: forgn(date,ticker,상장주식수,보유수량,...). cal: 마스터 거래일. columns: 가격 패널 종목(순서 유지). 반환 (cal×columns DataFrame, 진단 dict).
    위치 기반(마스터 거래일 행 수)으로 이동하며, 해당 날짜 값이 없으면 NaN(채우지 않음)."""
    cal = pd.DatetimeIndex(cal); columns = list(columns)
    d = fg[["date", "ticker", "상장주식수", "보유수량"]].copy()
    d["ticker"] = norm_ticker(d["ticker"]); d["date"] = pd.to_datetime(d["date"], errors="coerce")
    assert d["date"].notna().all(), "forgn 날짜 파싱 실패"
    assert not d.duplicated(["date", "ticker"]).any(), "forgn (date,ticker) 중복"
    d = d[d["ticker"].isin(set(columns)) & d["date"].isin(cal)]
    sh = d["상장주식수"].astype("float64"); hold = d["보유수량"].astype("float64")
    d = d.assign(S=sh.where(sh > 0), R=(100.0 * hold / sh).where(sh > 0))
    S = d.pivot(index="date", columns="ticker", values="S").reindex(index=cal, columns=columns)
    Rr = d.pivot(index="date", columns="ticker", values="R").reindex(index=cal, columns=columns)
    jump = ((S / S.shift(1) - 1).abs() > JUMP).astype(float)                      # d-1→d 변화 구간 플래그(두 값 모두 있을 때만)
    jwin = jump.shift(LAG).rolling(WIN, min_periods=WIN).sum() > 0               # 행 t: 변화 구간 d=t-20..t-1
    end = ((S.shift(LAG) / S.shift(LAG + WIN) - 1).abs() > JUMP)                  # 양 끝점(t-1, t-21) 비교
    contam = jwin | end
    raw = Rr.shift(LAG) - Rr.shift(LAG + WIN)
    out = raw.where(~contam)
    diag = {"유효 값": int(out.notna().sum().sum()), "원값 유효": int(raw.notna().sum().sum()), "오염으로 제외": int((raw.notna() & contam).sum().sum()),
            "forgn 행(패널 내)": len(d)}
    return out, diag


def check_risk_repro(prep_all, gate1_csv):
    """선행 조건: 같은 prep에서 기존 RISK IC(T1)가 D5 gate1_results.csv와 atol 1e-12 일치(입력·라벨·유니버스가 D5와 같음을 확인)."""
    ref = pd.read_csv(gate1_csv, encoding="utf-8-sig")
    ref = ref[(ref["feature"] == "RISK") & (ref["target"] == "T1")].set_index("h")
    for h in HS:
        r1 = R.observed(prep_all[h], "RISK")[0]
        assert abs(r1["ic_mean"] - ref.loc[h, "ic_mean"]) <= 1e-12, f"RISK IC 불일치 h={h}: {r1['ic_mean']} vs {ref.loc[h, 'ic_mean']}"


def only_feature(prep_all, feat_name=FEATURE):
    out = {}
    for h, P in prep_all.items():
        out[h] = {k: P[k] for k in ("dates", "block", "T1", "T2", "T1_L1")}
        out[h]["F"] = {feat_name: P["F"][feat_name]}
    return out


def _spearman_daily(A, B, min_n=C.GATE1_MIN_N):
    r = []
    for t in range(A.shape[0]):
        m = np.isfinite(A[t]) & np.isfinite(B[t])
        if m.sum() < min_n:
            continue
        a, b = rankdata(A[t][m]), rankdata(B[t][m])
        if a.std() > 0 and b.std() > 0:
            r.append(np.corrcoef(a, b)[0, 1])
    return float(np.mean(r)) if r else np.nan, len(r)


def diagnostics(prep_all, others, group, h=5):
    """판정 불변 사후 진단. others: 이름→(T×M 배열, h=5 신호일 정렬). 반환 dict(corr 표, group IC 표, 연도별 IC 표)."""
    P = prep_all[h]; Ff = P["F"][FEATURE]
    corr = []
    for k, v in others.items():
        c, n = _spearman_daily(Ff, v)
        corr.append({"비교 변수": k, "일별 순위상관 평균": c, "일수": n})
    g = np.asarray(group, dtype=object)
    grp_rows = []
    for name, keep in (("전체", np.ones(len(g), bool)), ("그룹 439", g == "439"), ("A+B", g != "439")):
        for hh in HS:
            Q = prep_all[hh]; Fm = np.where(keep[None, :], Q["F"][FEATURE], np.nan)
            Pm = {**Q, "F": {FEATURE: Fm}}
            r1 = R.observed(Pm, FEATURE)[0]
            grp_rows.append({"집단": name, "h": hh, "IC": r1["ic_mean"], "t": r1["ic_t"], "IC일수": r1["n_ic_days"]})
    yr_rows = []
    for hh in HS:
        Q = prep_all[hh]; ic = daily_stats(Q["F"][FEATURE], Q["T1"], True)[0] * DIRECTION
        y = pd.DatetimeIndex(Q["dates"]).year.values
        for yy in np.unique(y):
            m = (y == yy) & np.isfinite(ic)
            yr_rows.append({"h": hh, "연도": int(yy), "IC 평균": float(ic[m].mean()) if m.any() else np.nan, "IC 일수": int(m.sum())})
    return {"corr": pd.DataFrame(corr), "group": pd.DataFrame(grp_rows), "year": pd.DataFrame(yr_rows)}


def run_tl014(D, U, F, labels, fg, out_dir, gate1_csv, log=print):
    """①설계구간 확인 ②Feature 구성·진단 ③RISK 재현(선행조건) ④Gate 1(D5와 동일, FOR_CHG20 9 trial) ⑤사후 진단."""
    from .gate1_prep import prepare
    from .gate2_prep import dollar_volume_20
    R.check_prereg()
    cal = D["calendar"]
    assert cal.max() <= C.SIGNAL_END, "설계구간 밖 데이터 적재"
    cols = list(D["close"].columns)
    feat, fd = build_for_chg20(fg, cal, cols)
    log(f"FOR_CHG20 구성: 유효 {fd['유효 값']:,} (원값 {fd['원값 유효']:,}, 상장주식수 변동 오염 제외 {fd['오염으로 제외']:,}) | 패널 내 forgn 행 {fd['forgn 행(패널 내)']:,}")
    prep_all = prepare(D, U, {"RISK": F["RISK"], FEATURE: feat}, labels)
    for h, P in prep_all.items():
        d = pd.DatetimeIndex(P["dates"])
        assert d.min() >= C.SIGNAL_START and d.max() <= C.SIGNAL_END, f"설계구간 밖 신호일 h={h}"
    with direction_ctx():
        check_risk_repro(prep_all, gate1_csv)
        log("기존 RISK IC가 D5 gate1_results.csv와 일치 OK (입력·라벨·유니버스 동일)")
        prep = only_feature(prep_all)
        os.makedirs(out_dir, exist_ok=True)
        res, meta = R.run_gate1(prep, os.path.join(out_dir, "g1"), log=log)
        idx5 = pd.DatetimeIndex(prep_all[5]["dates"])
        DV = dollar_volume_20(D["close"], D["volume"], D["outlier"]); CL = D["close"].mask(D["outlier"])
        others = {k: F[k].where(U).loc[idx5, cols].values for k in ("MOM", "REV", "RISK", "ATTN", "LIQ", "ANCH")}
        others["거래대금20일평균"] = DV.where(U).loc[idx5, cols].values
        others["종가(가격 수준)"] = CL.where(U).loc[idx5, cols].values
        group = D["meta"]["group"].reindex(cols).values
        dg = diagnostics(prep_all, others, group, h=5)
    dg["corr"].to_csv(os.path.join(out_dir, "tl014_corr.csv"), index=False, encoding="utf-8-sig")
    dg["group"].to_csv(os.path.join(out_dir, "tl014_group_ic.csv"), index=False, encoding="utf-8-sig")
    dg["year"].to_csv(os.path.join(out_dir, "tl014_year_ic.csv"), index=False, encoding="utf-8-sig")
    return {"res": res, "meta": meta, "diag": dg, "fd": fd}


def print_report(o, gate1_csv=None, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 50)
    df = o["res"]["df"]; m = o["meta"]
    out("=== [Gate 1] FOR_CHG20 (독립 IC 검정 3개, T1·T3 동일) ===")
    a = df[df["target"] == "T1"][["feature", "h", "ic_mean", "ic_t", "p_ic", "bh_q", "s1_IC", "agree", "agree_thr", "s2_agree"]]
    out(a.round(4).to_string(index=False))
    out("\\n=== 분위 단계 (stage2 통과분) ===")
    b = df[df["s2_agree"]][["feature", "h", "target", "spread", "spread_thr", "mono", "mono_thr", "s3_quant", "판정"]]
    out(b.round(4).to_string(index=False) if len(b) else "stage2 통과 없음")
    out(f"\\n요약: trial {m['trials']} | family {m['families']} | 판정불가 {m['n_판정불가']} | stage1 {m['stage1_IC_BH']}/9 → stage2 {m['stage2_agree']}/9 → stage3 {m['stage3_quantile']}/9")
    ps = df[df["s3_quant"]]
    out("Gate 2 후보: " + (", ".join(f"{r.feature}-h{r.h}-{r.target}" for r in ps.itertuples()) if len(ps) else "없음"))
    out("\\n=== 진단(판정 불변): 기존 변수와의 일별 순위상관 평균 (h5 신호일) ==="); out(o["diag"]["corr"].round(4).to_string(index=False))
    out("\\n=== 진단: 집단별 IC (전체·그룹 439·A+B) ==="); out(o["diag"]["group"].round(4).to_string(index=False))
    out("\\n=== 진단: 연도별 IC ==="); out(o["diag"]["year"].pivot(index="연도", columns="h", values="IC 평균").round(4).to_string())
