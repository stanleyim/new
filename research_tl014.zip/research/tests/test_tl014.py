import os, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from research import config as C, d5_run as R, tl014 as Z
from research.gate1 import block_ids
from research.tests.test_synthetic import make_world

res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f, exc=AssertionError):
    try: f(); return False
    except exc: return True

t0 = time.time()
rng = np.random.default_rng(7)
ok("상수: 방향 +1·윈도우 20·지연 1·점프 1%", (Z.DIRECTION, Z.WIN, Z.LAG, Z.JUMP) == (1, 20, 1, 0.01) and Z.FEATURE == "FOR_CHG20")

# ---------- Feature 구성: 독립(브루트포스) 구현 대조 ----------
cal = pd.bdate_range("2020-01-01", periods=90)
tickers = ["000010", "000020", "000030", "00341A", "000050", "000060"]
def make_fg(seed=1):
    r = np.random.default_rng(seed); rows = []
    for tk in tickers:
        sh = 1_000_000.0; ratio = r.uniform(5, 30)
        for i, d in enumerate(cal):
            ratio = float(np.clip(ratio + r.normal(0, 0.3), 0.5, 60))
            if r.random() < 0.04: sh *= r.choice([0.5, 1.02, 1.5, 2.0])      # 주식수 변동(일부는 1% 초과)
            if r.random() < 0.05: continue                                    # 결측일
            rows.append({"date": d, "ticker": tk, "상장주식수": int(sh), "보유수량": int(sh * ratio / 100), "지분율": np.float16(ratio), "한도수량": int(sh), "한도소진률": np.float16(ratio)})
    return pd.DataFrame(rows)
fg = make_fg()
cols = tickers + ["999999"]                                                   # 999999는 forgn에 없음
feat, diag = Z.build_for_chg20(fg, cal, cols)
def brute(fg, cal, cols):
    f = fg.copy(); f["R"] = 100.0 * f["보유수량"] / f["상장주식수"]; f["S"] = f["상장주식수"].astype(float)
    Rd = {(r.ticker, r.date): r.R for r in f.itertuples()}; Sd = {(r.ticker, r.date): r.S for r in f.itertuples()}
    out = np.full((len(cal), len(cols)), np.nan)
    for j, tk in enumerate(cols):
        for p in range(len(cal)):
            if p - 21 < 0: continue
            a, b = (tk, cal[p - 1]), (tk, cal[p - 21])
            if a not in Rd or b not in Rd: continue
            bad = abs(Sd[a] / Sd[b] - 1) > 0.01
            for dd in range(p - 20, p):                                       # 변화 구간 d-1→d, d=t-20..t-1
                x, y = (tk, cal[dd]), (tk, cal[dd - 1])
                if x in Sd and y in Sd and abs(Sd[x] / Sd[y] - 1) > 0.01: bad = True
            if not bad: out[p, j] = Rd[a] - Rd[b]
    return out
bf = brute(fg, cal, cols)
ok("브루트포스 구현과 전 칸 일치", np.allclose(feat.values, bf, equal_nan=True, rtol=0, atol=1e-12) and np.isfinite(bf).sum() > 100)
ok("진단 카운트 = 유효 칸 수", diag["유효 값"] == int(np.isfinite(bf).sum()) and diag["오염으로 제외"] > 0)
ok("forgn에 없는 종목은 전부 NaN·열 순서 유지", feat.iloc[:, -1].isna().all() and list(feat.columns) == cols and feat.index.equals(cal))
# 지연·미래 비의존: 날짜 q 이후 forgn 값을 바꿔도 행 <= q 의 Feature 불변
q = 50; fg2 = fg.copy(); m = fg2["date"] >= cal[q]
fg2.loc[m, "보유수량"] = (fg2.loc[m, "보유수량"] * 0.5).astype(int); fg2.loc[m, "상장주식수"] = (fg2.loc[m, "상장주식수"] * 1.7).astype(int)
f2, _ = Z.build_for_chg20(fg2, cal, cols)
ok("미래 비의존: q 이후 데이터 변경 시 행 <= q 불변", np.array_equal(feat.values[:q + 1], f2.values[:q + 1], equal_nan=True))
ok("1일 지연: q 데이터 변경은 행 q+1부터만 영향", (not np.array_equal(feat.values[q + 1:q + 22], f2.values[q + 1:q + 22], equal_nan=True)))
# 지분율 컬럼 비의존·한도 컬럼 비의존
fg3 = fg.copy(); fg3["지분율"] = np.float16(1.0); fg3["한도수량"] = 1; fg3["한도소진률"] = np.float16(2.0)
ok("지분율·한도 컬럼 값과 무관", np.array_equal(Z.build_for_chg20(fg3, cal, cols)[0].values, feat.values, equal_nan=True))
# 정확값: 매일 +0.1%p, 주식수 불변 → 정확히 2.0
rows = [{"date": d, "ticker": "000010", "상장주식수": 1_000_000, "보유수량": int(1_000_000 * (10 + 0.1 * i) / 100 + 1e-6), "지분율": 0, "한도수량": 1, "한도소진률": 0} for i, d in enumerate(cal)]
fx, _ = Z.build_for_chg20(pd.DataFrame(rows), cal, ["000010"])
v = fx["000010"].dropna(); ok("정확값 +2.0%p·유효 시작 행 21", len(v) == len(cal) - 21 and np.allclose(v.values, 2.0, atol=2e-4) and fx["000010"].first_valid_index() == cal[21])
# 상장주식수 점프 윈도우: 정확히 t in [d+1, d+20]만 NaN
rows = [{"date": d, "ticker": "000010", "상장주식수": 1_000_000 if i < 40 else 2_000_000, "보유수량": 100_000 if i < 40 else 200_000, "지분율": 0, "한도수량": 1, "한도소진률": 0} for i, d in enumerate(cal)]
fj, _ = Z.build_for_chg20(pd.DataFrame(rows), cal, ["000010"]); nanpos = [p for p in range(21, len(cal)) if np.isnan(fj.iloc[p, 0])]
ok("점프일 d=40 → NaN 위치 41..60", nanpos == list(range(41, 61)))
# 상장주식수<=0·중복 거부·정렬 밖 날짜 무시
bad = pd.DataFrame(rows); bad.loc[10, "상장주식수"] = 0; fb, _ = Z.build_for_chg20(bad, cal, ["000010"])
ok("상장주식수 0 행 → 그 행 기반 값 NaN(위치 11·31)", np.isnan(fb.iloc[11, 0]) and np.isnan(fb.iloc[31, 0]))
ok("(date,ticker) 중복 거부", raises(lambda: Z.build_for_chg20(pd.concat([pd.DataFrame(rows), pd.DataFrame(rows).iloc[:1]]), cal, ["000010"])))
extra = pd.concat([pd.DataFrame(rows), pd.DataFrame([{"date": pd.Timestamp("2019-12-28"), "ticker": "000010", "상장주식수": 5, "보유수량": 1, "지분율": 0, "한도수량": 1, "한도소진률": 0}])])
ok("마스터 거래일 밖 forgn 날짜 무시", np.array_equal(Z.build_for_chg20(extra, cal, ["000010"])[0].values, fj.values, equal_nan=True))
# 티커 정규화: 정수형·문자형 모두 동일 종목
fi = pd.DataFrame(rows).assign(ticker=10); ok("정수 티커(10)도 '000010'으로 매칭", np.array_equal(Z.build_for_chg20(fi, cal, ["000010"])[0].values, fj.values, equal_nan=True))

# ---------- 방향 컨텍스트 ----------
ok("방향 컨텍스트 복원", Z.FEATURE not in C.FEATURE_DIRECTION)
with Z.direction_ctx(): inside = C.FEATURE_DIRECTION[Z.FEATURE]
ok("컨텍스트 안에서 +1, 밖에서 제거", inside == 1 and Z.FEATURE not in C.FEATURE_DIRECTION)
try:
    with Z.direction_ctx(): raise RuntimeError("x")
except RuntimeError: pass
ok("예외 시에도 복원", Z.FEATURE not in C.FEATURE_DIRECTION)

# ---------- Gate 1 배관(합성 prep) ----------
T, M = 400, 300
idx = pd.bdate_range("2018-01-02", periods=T)
class small_k:
    def __init__(self, k=20): self.k = k
    def __enter__(self):
        self.o = (C.K_SHIFTS, dict(R.PREREG)); C.K_SHIFTS = self.k; R.PREREG["K_SHIFTS"] = self.k
    def __exit__(self, *a):
        C.K_SHIFTS = self.o[0]; R.PREREG.clear(); R.PREREG.update(self.o[1])
def mkprep_all(sig_cols=None, signal=True, seed=3):
    r = np.random.default_rng(seed); s = r.normal(size=(T, M)); Y = (0.5 * s if signal else 0.0) + r.normal(size=(T, M)); Y[r.random((T, M)) < .05] = np.nan
    if sig_cols is not None: Y = np.where(sig_cols[None, :], Y, np.nan_to_num(Y) * 0 + r.normal(size=(T, M)))
    Y2 = pd.DataFrame(Y).rank(axis=1, pct=True).values
    Fv = np.where(np.ones((T, M), bool), s + 0.5 * r.normal(size=(T, M)), np.nan)             # +방향 신호
    return {h: {"dates": idx, "block": block_ids(idx), "T1": Y.copy(), "T2": Y2.copy(), "T1_L1": Y.copy(),
                "F": {"RISK": r.normal(size=(T, M)), Z.FEATURE: Fv.copy()}} for h in (5, 10, 20)}
pa = mkprep_all()
po = Z.only_feature(pa)
ok("only_feature: F={FOR_CHG20}만·Target 동일 객체", all(list(po[h]["F"]) == [Z.FEATURE] and po[h]["T1"] is pa[h]["T1"] for h in po))
with small_k(20), Z.direction_ctx():
    r1, m1 = R.run_gate1(po, os.path.join(tempfile.mkdtemp(), "o"), log=lambda *_: None)
ok("family 1·trial 9·독립 IC 3", m1["families"] == 1 and m1["trials"] == 9 and set(r1["df"]["feature"]) == {Z.FEATURE})
ok("+방향 신호 검출: IC>0·stage1 존재", (r1["df"]["ic_mean"] > 0).all() and r1["df"]["s1_IC"].any())
pn = mkprep_all(signal=False)
with small_k(20), Z.direction_ctx():
    r0, m0 = R.run_gate1(Z.only_feature(pn), os.path.join(tempfile.mkdtemp(), "o"), log=lambda *_: None)
ok("신호 없으면 stage1 불통과", m0["stage1_IC_BH"] == 0)
ok("방향 미설정이면 중단(KeyError)", raises(lambda: R.observed(po[5], Z.FEATURE), KeyError))
# RISK 재현 선행조건
tdir = tempfile.mkdtemp(); csv = os.path.join(tdir, "g1.csv")
rows_ = [{"feature": "RISK", "h": h, "target": "T1", "ic_mean": R.observed(pa[h], "RISK")[0]["ic_mean"]} for h in (5, 10, 20)]
pd.DataFrame(rows_).to_csv(csv, index=False, encoding="utf-8-sig")
Z.check_risk_repro(pa, csv); ok("RISK 재현: 일치 시 통과", True)
b = pd.DataFrame(rows_); b["ic_mean"] += 1e-9; bp = os.path.join(tdir, "b.csv"); b.to_csv(bp, index=False)
ok("RISK 재현: 1e-9 불일치 중단", raises(lambda: Z.check_risk_repro(pa, bp)))

# ---------- 진단 ----------
grp = np.random.default_rng(5).choice(["439", "A", "B"], size=M, p=[0.3, 0.2, 0.5])
r = np.random.default_rng(11); s = r.normal(size=(T, M))
pg = {h: {**pa[h]} for h in pa}
for h in pg:
    Fv = np.where((grp == "439")[None, :], s, r.normal(size=(T, M))); Yv = np.where((grp == "439")[None, :], 0.6 * s, 0.0) + r.normal(size=(T, M))
    pg[h] = {**pa[h], "T1": Yv, "T2": pd.DataFrame(Yv).rank(axis=1, pct=True).values, "T1_L1": Yv.copy(), "F": {"RISK": r.normal(size=(T, M)), Z.FEATURE: Fv}}
with Z.direction_ctx():
    dg = Z.diagnostics(pg, {"자기자신": pg[5]["F"][Z.FEATURE].copy(), "독립": r.normal(size=(T, M))}, grp, h=5)
cr = dg["corr"].set_index("비교 변수")["일별 순위상관 평균"]
ok("진단 상관: 자기 자신 ≈ 1·독립 ≈ 0", cr["자기자신"] > 0.999 and abs(cr["독립"]) < 0.05)
gi = dg["group"].set_index(["집단", "h"])["IC"]
ok("집단별 IC: 신호를 439에만 심으면 439 > 전체 > A+B ≈ 0", all(gi[("그룹 439", h)] > gi[("전체", h)] > gi[("A+B", h)] and abs(gi[("A+B", h)]) < 0.05 for h in (5, 10, 20)))
ok("연도별 IC 표: h 3 × 연도", set(dg["year"]["h"]) == {5, 10, 20} and len(dg["year"]) == 3 * len(np.unique(idx.year)))

# ---------- 오케스트레이션 스모크(합성 월드) ----------
from research.run_d3d4 import run
from research.gate1_prep import prepare
class small_min:
    def __enter__(self):
        self.o = (C.GATE1_MIN_N, dict(R.PREREG)); C.GATE1_MIN_N = 5; R.PREREG["GATE1_MIN_N"] = 5
    def __exit__(self, *a):
        C.GATE1_MIN_N = self.o[0]; R.PREREG.clear(); R.PREREG.update(self.o[1])
import research.gate1 as G1
with tempfile.TemporaryDirectory() as tmp:
    paths = make_world(tmp)
    D, U, parts, Fw, lab = run(*paths, verbose=False)
    calw = D["calendar"]; colsw = list(D["close"].columns); rw = np.random.default_rng(2); rows = []
    for tk in colsw:
        ratio = 10.0
        for d in calw:
            ratio += rw.normal(0, 0.2); rows.append({"date": d, "ticker": tk, "상장주식수": 1_000_000, "보유수량": int(10_000 * max(ratio, 1)), "지분율": 0, "한도수량": 1, "한도소진률": 0})
    fgw = pd.DataFrame(rows)
    with small_k(20), small_min():
        pw = prepare(D, U, {"RISK": Fw["RISK"]}, lab)
        ref = os.path.join(tempfile.mkdtemp(), "g1.csv")
        with Z.direction_ctx():
            pd.DataFrame([{"feature": "RISK", "h": h, "target": "T1", "ic_mean": R.observed(pw[h], "RISK")[0]["ic_mean"]} for h in (5, 10, 20)]).to_csv(ref, index=False, encoding="utf-8-sig")
        msgs = []
        o = Z.run_tl014(D, U, Fw, lab, fgw, os.path.join(tempfile.mkdtemp(), "o"), ref, log=msgs.append)
    ok("스모크: RISK 재현 OK 로그·결과 구조", any("RISK IC가 D5" in m for m in msgs) and o["meta"]["families"] == 1 and set(o["res"]["df"]["feature"]) == {Z.FEATURE})
    ok("스모크: 진단 3종 생성", len(o["diag"]["corr"]) == 8 and len(o["diag"]["group"]) == 9 and len(o["diag"]["year"]) > 0)
    Z.print_report(o, out=lambda s: None); ok("print_report 동작", True)
    ok("스모크 후 방향·상수 복원", Z.FEATURE not in C.FEATURE_DIRECTION and C.K_SHIFTS == 1000 and C.GATE1_MIN_N == 50)
    late_fg = fgw.copy()
    ok("중복 forgn 거부(오케스트레이션)", raises(lambda: Z.run_tl014(D, U, Fw, lab, pd.concat([fgw, fgw.iloc[:1]]), tempfile.mkdtemp(), ref, log=lambda *_: None)))

src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tl014.py"), encoding="utf-8").read()
ok("features/targets 모듈 import 없음", all(s_ not in src for s_ in ("import features", "import targets", "from .features", "from .targets", "from . import features", "from . import targets")))
fails = [n for n, c in res if not c]
print(f"test_tl014: {len(res) - len(fails)}/{len(res)} PASS ({time.time()-t0:.0f}s)" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
