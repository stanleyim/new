import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from research import config as C, d5_run as R, tl009 as X
from research.gate1 import block_ids

rng = np.random.default_rng(9)
res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f):
    try: f(); return False
    except AssertionError: return True

# 1) 상위 1/3 마스크: 수기 계산·결측·동률·일별 독립·단조 불변
DV6 = np.array([[10., 20, 30, 40, 50, 60]])
m6, d6 = X.top_tercile_mask(DV6, min_n=3)                 # n=6 → q=ceil(rank/2) → 순위 5,6이 q=3
ok("수기: n=6 상위 2개(40이 아니라 50·60)", m6[0].tolist() == [False, False, False, False, True, True] and d6.loc[0, "n_high"] == 2)
DV150 = np.arange(1., 151.)[None, :]
m150, _ = X.top_tercile_mask(DV150)                       # 순위 101~150(50개), 100번은 q=2
ok("수기: n=150 경계(순위 100=제외, 101=포함)", m150[0].sum() == 50 and (not m150[0, 99]) and m150[0, 100])
T, Mn = 80, 300
DV = np.exp(rng.normal(20, 1.5, (T, Mn)))
DVn = DV.copy(); DVn[5, :40] = np.nan; DVn[6, :40] = -1.0; DVn[7, :40] = 0.0
mk, dg = X.top_tercile_mask(DVn)
ok("NaN·음수·0 제외(n_dv=260)", (dg.loc[5:7, "n_dv"] == 260).all() and not mk[5:8, :40].any())
ok("상위 비율≈1/3", abs(dg["n_high"].sum() / dg["n_dv"].sum() - 1 / 3) < 0.01)
ok("상위가 하위보다 DV 큼(일별)", all(DV[t][mk[t]].min() >= np.sort(DV[t])[int(0.6 * Mn)] for t in range(T) if mk[t].any()))
Dsmall = DV[:, :100].copy()
ms, ds = X.top_tercile_mask(Dsmall)
ok("n<150이면 그날 전부 False", (not ms.any()) and (ds["n_dv"] == 100).all() and (ds["n_high"] == 0).all())
mm, _ = X.top_tercile_mask(np.log(DV) * 3 + 7)
ok("DV 단조변환 불변", np.array_equal(mm, X.top_tercile_mask(DV)[0]))
DV2 = DV.copy(); DV2[40:] = np.exp(rng.normal(20, 1.5, (T - 40, Mn)))
ok("일별 독립(미래 행 변경이 과거 마스크 불변)", np.array_equal(X.top_tercile_mask(DV2)[0][:40], X.top_tercile_mask(DV)[0][:40]))
Dt = DV.copy(); Dt[0, :] = 1.0                            # 전부 동률 → 같은 평균순위 → 같은 분위(전부 q=2: ceil(3*0.5)=2)
mt, dt_ = X.top_tercile_mask(Dt)
ok("전부 동률이면 상위 1/3 없음(동률은 같은 분위)", (not mt[0].any()) and dt_.loc[0, "n_high"] == 0)

# 2) build_hi_prep: F만 마스킹, Target 불변, Feature 3개만, 형상 검사
T2_, M2 = 400, 300
idx = pd.bdate_range("2018-01-02", periods=T2_)
cal = pd.bdate_range("2017-06-01", "2023-03-01")
cols = [f"S{i}" for i in range(M2)]
DVd = pd.DataFrame(np.exp(rng.normal(20, 1.5, (len(cal), M2))), index=cal, columns=cols)
rdv = DVd.loc[idx].rank(axis=1, pct=True).values
hi_true = rdv > 2 / 3 + 1e-9
def mkF(): return {k: rng.normal(size=(T2_, M2)) for k in ("REV", "MOM", "RISK", "ATTN", "LIQ", "ANCH")}
def mkprep(F, Y):
    Y2 = pd.DataFrame(Y).rank(axis=1, pct=True).values
    return {h: {"dates": idx, "block": block_ids(idx), "T1": Y.copy(), "T2": Y2.copy(), "T1_L1": Y.copy(), "F": {k: v.copy() for k, v in F.items()}} for h in (5, 10, 20)}
F0 = mkF(); Y0 = rng.normal(size=(T2_, M2)); Y0[rng.random((T2_, M2)) < .05] = np.nan
p0 = mkprep(F0, Y0)
ph, dgs = X.build_hi_prep(p0, DVd)
ok("Feature 3개만(REV·RISK·ATTN)", all(list(ph[h]["F"]) == ["REV", "RISK", "ATTN"] for h in ph))
ok("Target 배열 불변", all(np.array_equal(ph[h][k], p0[h][k], equal_nan=True) for h in ph for k in ("T1", "T2", "T1_L1")))
okm = all((np.isfinite(ph[5]["F"][k]) == (np.isfinite(F0[k]) & (dgs[5]["n_high"].values[:, None] > 0) & (X.top_tercile_mask(DVd.loc[idx].values)[0]))).all() for k in X.FEATS)
ok("상위 1/3 종목에서만 유한(마스크 일치)", okm)
ok("상위 값은 원본 그대로", np.array_equal(ph[5]["F"]["REV"][hi_true], F0["REV"][hi_true]))
ok("형상 불일치 중단", raises(lambda: X.build_hi_prep(p0, DVd.iloc[:, :10])))
ok("진단 표", len(X.summarize_filter(dgs)) == 3 and abs(X.summarize_filter(dgs)["상위1/3 비율"].mean() - 1 / 3) < 0.01)

# 3) 필터 전 재현 검사
tdir = tempfile.mkdtemp(); csv = os.path.join(tdir, "g1.csv")
rows = [{"feature": k, "h": h, "target": "T1", "ic_mean": R.observed(p0[h], k)[0]["ic_mean"]} for h in p0 for k in X.FEATS]
pd.DataFrame(rows).to_csv(csv, index=False, encoding="utf-8-sig")
X.check_unfiltered(p0, csv); ok("필터 전 IC 일치 시 통과", True)
bad = pd.read_csv(csv); bad["ic_mean"] += 1e-9; bad.to_csv(csv, index=False)
ok("1e-9 불일치 시 중단", raises(lambda: X.check_unfiltered(p0, csv)))
pd.DataFrame(rows).to_csv(csv, index=False, encoding="utf-8-sig")

# 4) T1·T2 IC 동일(사전등록 문구: Target 재계산 없이 순위 단조) — 상위 1/3 부분집합에서도 성립
a1 = R.observed(ph[5], "REV")[0]["ic_mean"]; tmp = dict(ph[5]); tmp["T1"] = ph[5]["T2"]
ok("부분집합 IC: T1=T2(단조 불변)", abs(R.observed(tmp, "REV")[0]["ic_mean"] - a1) <= 1e-12)

# 5) 종단(K 축소): 신호가 상위 1/3에만 있으면 검출, 하위에만 있으면 미검출
class small_k:
    def __init__(self, k=20): self.k = k
    def __enter__(self):
        self.old = C.K_SHIFTS; C.K_SHIFTS = self.k; self.o2 = dict(R.PREREG); R.PREREG["K_SHIFTS"] = self.k
    def __exit__(self, *a):
        C.K_SHIFTS = self.old; R.PREREG.clear(); R.PREREG.update(self.o2)
def endtoend(sig_region, name):
    F = mkF(); s = rng.normal(size=(T2_, M2))
    reg = hi_true if sig_region == "hi" else ~hi_true
    for k, sgn in (("REV", -1), ("RISK", -1), ("ATTN", -1)):
        F[k] = np.where(reg, sgn * s, rng.normal(size=(T2_, M2)))                  # 가설 방향(값이 작을수록 상승)에 맞춘 신호
    Y = np.where(reg, 0.5 * s, 0.0) + rng.normal(size=(T2_, M2)); Y[rng.random((T2_, M2)) < .05] = np.nan
    p = mkprep(F, Y)
    rws = [{"feature": k, "h": h, "target": "T1", "ic_mean": R.observed(p[h], k)[0]["ic_mean"]} for h in p for k in X.FEATS]
    c = os.path.join(tempfile.mkdtemp(), "g.csv"); pd.DataFrame(rws).to_csv(c, index=False, encoding="utf-8-sig")
    msgs = []
    with small_k(20):
        r, meta, fdf, mdf = X.run_tl009(p, DVd, os.path.join(tempfile.mkdtemp(), "o"), c, log=msgs.append)
    return r, meta, fdf, mdf, msgs, c
r1, m1, f1, md1, ms1, c1 = endtoend("hi", "hi")
ok("로그: 필터 전 일치", any("일치 OK" in m for m in ms1))
ok("family 3·trial 27·독립 IC 9", m1["families"] == 3 and m1["trials"] == 27 and m1["independent_IC_tests"] == 9 and set(r1["df"]["feature"]) == set(X.FEATS))
ok("방향 설정 불변(config 그대로)", C.FEATURE_DIRECTION["REV"] == -1 and C.FEATURE_DIRECTION["RISK"] == -1 and C.FEATURE_DIRECTION["ATTN"] == -1)
ok("상위 1/3에 심은 신호 검출(IC>0·stage1 존재)", (r1["df"]["ic_mean"] > 0).all() and r1["df"]["s1_IC"].any())
ok("판정 불가 메타 표(9행, 평가가능 비율>0.5)", len(md1) == 9 and (md1["평가가능 비율"] > 0.5).all())
X.print_report(r1, m1, f1, md1, c1, out=lambda s: None); ok("print_report 동작", True)
r2, m2, *_ = endtoend("lo", "lo")
ok("하위 2/3에만 신호면 필터 후 stage1 불통과", m2["stage1_IC_BH"] == 0)

# 6) 모듈 분리: tl009는 features/targets를 import하지 않는다
src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tl009.py"), encoding="utf-8").read()
ok("features/targets import 없음", "import features" not in src and "import targets" not in src and "from .features" not in src and "from .targets" not in src and "from . import features" not in src and "from . import targets" not in src)

fails = [n for n, c in res if not c]
print(f"test_tl009: {len(res) - len(fails)}/{len(res)} PASS" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
