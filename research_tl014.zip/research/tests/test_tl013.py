import os, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from research import config as C, gate2_run as G2, near_run as N, g2_hedge as H, tl011 as Z, tl013 as W
from research.tests.test_gate2 import synth_prep
from research.tests.test_synthetic import make_world

res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f):
    try: f(); return False
    except AssertionError: return True

t0 = time.time()
M = 300
grp = np.random.default_rng(5).choice(["439", "A", "B"], size=M, p=[0.3, 0.2, 0.5]); keep = Z.keep_mask(grp)
ok("후보 = RISK h20 하나", W.CANDS == [("RISK", 20)])

def scenario(region):
    reg = (keep if region == "ab" else ~keep)[None, :]; rr = np.random.default_rng(21)
    q = synth_prep(T=1150, M=M, seed=11)
    for h, P in q["h"].items():
        s = np.log1p(P["T1"]); s = np.where(np.isfinite(s), s, 0.0); s = s / s.std()
        P["F"] = {"REV": rr.normal(size=s.shape), "RISK": np.where(reg, -(0.6 * s + rr.normal(size=s.shape)), rr.normal(size=s.shape)), "ATTN": rr.normal(size=s.shape), "LIQ": rr.normal(size=s.shape)}
    return q
N_ROWS = synth_prep(T=1150, M=M, seed=11)["O"].shape[0]
cal = pd.bdate_range("2018-01-02", periods=N_ROWS)
def write_idx(const=False, seed=2):
    t = tempfile.mkdtemp(); rg = np.random.default_rng(seed); rows = []
    for n in ("KOSPI200", "KOSDAQ", "KOSPI"):
        px = np.full(len(cal), 100.0) if const else 100 * np.cumprod(1 + rg.normal(0, .01, len(cal)))
        rows.append(pd.DataFrame({"date": cal, "index": n, "종가": px}))
    d = pd.concat(rows)
    for y in range(cal[0].year, cal[-1].year + 1): d[d["date"].dt.year == y].to_parquet(f"{t}/idx_{y}.parquet")
    return t
def refs(p):
    d = tempfile.mkdtemp(); g2 = os.path.join(d, "g2.csv"); t11 = os.path.join(d, "t11.csv")
    N.eval_df(p, G2.CANDS, N.null_dummy).to_csv(g2, index=False, encoding="utf-8-sig")
    N.eval_df(Z.mask_g2(p, keep), Z.CANDS3, N.null_dummy).to_csv(t11, index=False, encoding="utf-8-sig")
    return d, g2, t11
def run(region, pit, p=None, g2=None, t11=None, log=None):
    p = scenario(region) if p is None else p
    if g2 is None: d, g2, t11 = refs(p)
    out = os.path.join(tempfile.mkdtemp(), "o"); msgs = []
    o = W.run_tl013(p, grp, cal, pit, g2, t11, out, log=msgs.append if log is None else log); o["out"] = out
    return p, o, msgs

pit = write_idx()
p1, o1, ms1 = run("ab", pit)
r1 = o1["df"].iloc[0]
ok("로그: 재현 3종 OK(전 유니버스·A+B·헤지 내 Q5 재현)", sum("일치 OK" in m for m in ms1) == 2 and any("재현 OK RISK h=20" in m for m in ms1))
ok("결과 1행 RISK h20", len(o1["df"]) == 1 and r1["feature"] == "RISK" and r1["h"] == 20)
ok("A+B에 심은 edge: ①헤지후 일평균>0", bool(r1["조건1_일평균>0"]) and r1["헤지후_일평균"] > 0)
p2, o2, _ = run("439", pit)
e1 = abs(o1["ctrl"]["Q5-풀 일평균(헤지후, 비헤지)"][1]); e2 = abs(o2["ctrl"]["Q5-풀 일평균(헤지후, 비헤지)"][1])
ok("439에만 심은 edge: A+B의 Q5−풀 초과(비헤지)가 신호 있는 쪽의 1/5 미만", e2 < e1 / 5)
_dm = pd.DataFrame([{"통과": False, "조건1_일평균>0": True, "조건2_MDD감소": False, "조건3_두구간양": False}])
_dp = pd.DataFrame([{"통과": True, "조건1_일평균>0": True, "조건2_MDD감소": True, "조건3_두구간양": True}])
ok("decide: 실패 시 '완전 종료'·실패 조건 명시", "완전 종료" in W.decide(_dm) and "②MDD감소" in W.decide(_dm) and "③두구간양" in W.decide(_dm) and "①" not in W.decide(_dm))
ok("decide: 통과 시 '확증 아님'", "확증 아님" in W.decide(_dp))
ok("검정력: 신호 있는 쪽 헤지후 일평균 > 없는 쪽", r1["헤지후_일평균"] > o2["df"].iloc[0]["헤지후_일평균"])
ok("통과 판정 문구에 '확증 아님' 명시", (not bool(r1["통과"])) or "확증 아님" in o1["verdict"])
# 지수 수익률 0이면 헤지후 = 비헤지(배관 검증)
pz = write_idx(const=True)
_, oz, _ = run("ab", pz, p=p1)
ok("지수 수익률 0 → 헤지후 일평균 = 비헤지 일평균", abs(oz["df"].iloc[0]["헤지후_일평균"] - oz["df"].iloc[0]["비헤지_일평균"]) < 1e-15 and abs(oz["df"].iloc[0]["평균β_KOSPI200"]) < 1e-9)
# 풀 대조·파일
c = o1["ctrl"]
ok("풀 대조 진단 값 유한", all(np.isfinite(c[k]) for k in ("풀_비헤지_일평균", "풀_헤지후_일평균", "풀_헤지후_Sharpe", "풀_헤지후_MDD")))
ok("풀 대조: Q5−풀 일평균(비헤지) = 비헤지 Q5 − 비헤지 풀", abs(c["Q5-풀 일평균(헤지후, 비헤지)"][1] - (r1["비헤지_일평균"] - c["풀_비헤지_일평균"])) < 1e-15)
ok("결과 파일 생성", all(os.path.exists(os.path.join(o1["out"], f)) for f in ("tl013_hedge_results.csv", "tl013_pool_control.csv")))
W.print_report(o1, out=lambda s: None); ok("print_report 동작", True)

# 선행 조건 실패 시 헤지 결과 미산출
d, g2, t11 = refs(p1)
b = pd.read_csv(t11, encoding="utf-8-sig"); b.loc[(b.feature == "RISK") & (b.h == 20), "Q5_CAGR"] *= (1 + 1e-6); bt = os.path.join(d, "bt.csv"); b.to_csv(bt, index=False, encoding="utf-8-sig")
m3 = []
def bad1(): W.run_tl013(p1, grp, cal, pit, g2, bt, tempfile.mkdtemp(), log=m3.append)
ok("TL-011 불일치 시 중단·헤지 미평가", raises(bad1) and not any("재현 OK RISK h=20" in m for m in m3))
bg = pd.read_csv(g2, encoding="utf-8-sig"); bg.loc[0, "평균E_gross(트랜치,h일)"] += 1e-9; bgp = os.path.join(d, "bg.csv"); bg.to_csv(bgp, index=False, encoding="utf-8-sig")
m4 = []
ok("gate2_results.csv 불일치 시 중단·A+B 재현 미시작", raises(lambda: W.run_tl013(p1, grp, cal, pit, bgp, t11, tempfile.mkdtemp(), log=m4.append)) and not any("A+B" in m for m in m4))
late = {"O": p1["O"], "Clf": p1["Clf"], "h": {h: {**P, "dates": pd.DatetimeIndex(P["dates"]) + pd.DateOffset(years=6)} for h, P in p1["h"].items()}}
ok("설계구간 밖 신호일 거부", raises(lambda: W.run_tl013(late, grp, cal, pit, g2, t11, tempfile.mkdtemp(), log=lambda *_: None)))
ok("캘린더 길이 불일치 거부", raises(lambda: W.run_tl013(p1, grp, cal[:-5], pit, g2, t11, tempfile.mkdtemp(), log=lambda *_: None)))
ok("그룹 439 없음 거부", raises(lambda: W.run_tl013(p1, np.array(["A"] * M, dtype=object), cal, pit, g2, t11, tempfile.mkdtemp(), log=lambda *_: None)))

# 로더~라벨 실제 경로(합성 월드): 캘린더·그룹 형상
with tempfile.TemporaryDirectory() as tmp:
    pw, gw, cw, iw = W.build_design(make_world(tmp), label="w")
    ok("build_design: 캘린더 길이 = 패널 행 수·상한 2022-12-30 이내", len(cw) == pw["O"].shape[0] and cw.max() <= N.DESIGN[1] and len(gw) == pw["O"].shape[1])
    ok("build_design: 그룹 라벨 {439,A,B}만", set(gw.tolist()) <= {"439", "A", "B"} and "439" in set(gw.tolist()))
    ok("build_design: 기간 컨텍스트 복원", (C.SIGNAL_START, C.SIGNAL_END) == (N.DESIGN[0], N.DESIGN[1]))
ok("사전등록 상수 복원", C.K_SHIFTS == 1000 and C.G2_COST_RT == 0.00206 and len(G2.CANDS) == 11)
src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tl013.py"), encoding="utf-8").read()
ok("features/targets import 없음", all(s not in src for s in ("import features", "import targets", "from .features", "from .targets", "from . import features", "from . import targets")))
fails = [n for n, c in res if not c]
print(f"test_tl013: {len(res) - len(fails)}/{len(res)} PASS ({time.time()-t0:.0f}s)" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
