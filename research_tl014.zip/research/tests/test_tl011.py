import os, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from research import config as C, d5_run as R, gate2_run as G2, near_run as N, tl011 as Z
from research.gate1 import block_ids
from research.tests.test_gate2 import synth_prep

res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f):
    try: f(); return False
    except AssertionError: return True

ok("후보 3개 = RISK h5·h10·h20", Z.CANDS3 == [("RISK", 5), ("RISK", 10), ("RISK", 20)] and Z.HS == (5, 10, 20))
ok("방향 설정 불변(RISK=-1)", C.FEATURE_DIRECTION["RISK"] == -1)

# 1) keep_mask
M = 300
grp = np.random.default_rng(5).choice(["439", "A", "B"], size=M, p=[0.3, 0.2, 0.5])
keep = Z.keep_mask(grp)
ok("keep = 그룹 439 제외", (keep == (grp != "439")).all() and keep.sum() + (grp == "439").sum() == M)
ok("알 수 없는 라벨 거부", raises(lambda: Z.keep_mask(np.array(["439", "A", "X"]))))
ok("439 없음/전부 439 거부", raises(lambda: Z.keep_mask(np.array(["A", "B"]))) and raises(lambda: Z.keep_mask(np.array(["439", "439"]))))

# 2) 합성 prep(Gate 2: synth_prep, Gate 1: 수기 구성)
p2 = synth_prep(T=1150, M=M, seed=11)
T1_, rng = 400, np.random.default_rng(9)
idx1 = pd.bdate_range("2018-01-02", periods=T1_)
def mkprep1(F, Y):
    Y2 = pd.DataFrame(Y).rank(axis=1, pct=True).values
    return {h: {"dates": idx1, "block": block_ids(idx1), "T1": Y.copy(), "T2": Y2.copy(), "T1_L1": Y.copy(), "F": {k: v.copy() for k, v in F.items()}} for h in (5, 10, 20)}
def noiseF(): return {k: rng.normal(size=(T1_, M)) for k in ("REV", "MOM", "RISK", "ATTN", "LIQ", "ANCH")}
Y0 = rng.normal(size=(T1_, M)); Y0[rng.random((T1_, M)) < .05] = np.nan
p1 = mkprep1(noiseF(), Y0)
snap1 = {h: p1[h]["F"]["RISK"].copy() for h in p1}
snap2 = {h: p2["h"][h]["F"]["RISK"].copy() for h in p2["h"]}

m1, m2 = Z.mask_g1(p1, keep), Z.mask_g2(p2, keep)
ok("G1: F={RISK}만·439 열 NaN·A+B 열 원본", all(list(m1[h]["F"]) == ["RISK"] and not np.isfinite(m1[h]["F"]["RISK"][:, ~keep]).any() and np.array_equal(m1[h]["F"]["RISK"][:, keep], snap1[h][:, keep]) for h in m1))
ok("G2: F={RISK}만·439 열 NaN·A+B 열 원본", all(list(m2["h"][h]["F"]) == ["RISK"] and not np.isfinite(m2["h"][h]["F"]["RISK"][:, ~keep]).any() and np.array_equal(m2["h"][h]["F"]["RISK"][:, keep], snap2[h][:, keep]) for h in m2["h"]))
ok("Target·status·DV·tpos·O·Clf 불변(동일 객체)", all(m1[h][k] is p1[h][k] for h in m1 for k in ("T1", "T2", "T1_L1", "dates", "block")) and all(m2["h"][h][k] is p2["h"][h][k] for h in m2["h"] for k in ("T1", "status", "DV", "tpos", "dates", "block")) and m2["O"] is p2["O"] and m2["Clf"] is p2["Clf"])
ok("입력 prep 불변", all(np.array_equal(p1[h]["F"]["RISK"], snap1[h]) for h in p1) and all(np.array_equal(p2["h"][h]["F"]["RISK"], snap2[h]) for h in p2["h"]) and all(len(p1[h]["F"]) == 6 for h in p1))
ok("종목 수 불일치 거부", raises(lambda: Z.mask_g1(p1, keep[:10])) and raises(lambda: Z.mask_g2(p2, keep[:10])))

# 3) NaN 마스킹 ≡ 열 제거 (핵심 정확성): Gate 1 IC·Gate 2 경로가 A+B 열만 남긴 prep과 동일
sl1 = {h: {**{k: p1[h][k] for k in ("dates", "block")}, **{k: p1[h][k][:, keep] for k in ("T1", "T2", "T1_L1")}, "F": {"RISK": snap1[h][:, keep]}} for h in p1}
same1 = all(R.observed(m1[h], "RISK")[0]["ic_mean"] == R.observed(sl1[h], "RISK")[0]["ic_mean"] for h in m1)
ok("G1: 마스킹 IC = 열 제거 IC(정확 동일)", same1)
sl2 = {"O": p2["O"][:, keep], "Clf": p2["Clf"][:, keep], "h": {h: {**{k: P[k] for k in ("dates", "block", "tpos")}, **{k: P[k][:, keep] for k in ("T1", "status", "DV")}, "F": {"RISK": snap2[h][:, keep]}} for h, P in p2["h"].items()}}
a = N.eval_df(m2, Z.CANDS3, N.null_dummy); b = N.eval_df(sl2, Z.CANDS3, N.null_dummy)
ok("G2: 마스킹 경로 = 열 제거 경로(REPL_COLS 전부)", not N.check_replication(a, b))

# 4) 선행 조건
td = tempfile.mkdtemp(); c1 = os.path.join(td, "g1.csv"); c2 = os.path.join(td, "g2.csv")
rows = [{"feature": "RISK", "h": h, "target": "T1", "ic_mean": R.observed(p1[h], "RISK")[0]["ic_mean"]} for h in (5, 10, 20)]
pd.DataFrame(rows).to_csv(c1, index=False, encoding="utf-8-sig")
refdf = N.eval_df(p2, G2.CANDS, N.null_dummy); refdf.to_csv(c2, index=False, encoding="utf-8-sig")
Z.check_unfiltered_g1(p1, c1); ok("G1 선행조건: 제외 전 일치 시 통과", True)
ok("G1 선행조건: 제외 후 prep이면 중단", raises(lambda: Z.check_unfiltered_g1({h: {**p1[h], "F": m1[h]["F"]} for h in p1}, c1)))
bad = pd.DataFrame(rows); bad["ic_mean"] += 1e-9; bp = os.path.join(td, "b1.csv"); bad.to_csv(bp, index=False)
ok("G1 선행조건: 1e-9 불일치 중단", raises(lambda: Z.check_unfiltered_g1(p1, bp)))
ok("G2 선행조건: 제외 전 일치 시 통과(RISK 3개 선별)", Z.check_unfiltered_g2(p2, c2) == 3)
ok("G2 선행조건: 제외 후 prep이면 중단", raises(lambda: Z.check_unfiltered_g2(m2, c2)))
b2 = refdf.copy(); b2.loc[(b2.feature == "RISK") & (b2.h == 10), "평균E_gross(트랜치,h일)"] += 1e-9; b2p = os.path.join(td, "b2.csv"); b2.to_csv(b2p, index=False, encoding="utf-8-sig")
ok("G2 선행조건: 1e-9 불일치 중단", raises(lambda: Z.check_unfiltered_g2(p2, b2p)))
ok("G2 선행조건: 후보 누락 중단", raises(lambda: Z.check_unfiltered_g2(p2, (lambda d: (d[~((d.feature == "RISK") & (d.h == 20))].to_csv(os.path.join(td, "m.csv"), index=False, encoding="utf-8-sig"), os.path.join(td, "m.csv"))[1])(refdf))))

# 5) 종료 규칙(decide) 수기 대조
def g1df(passh):
    r = []
    for h in (5, 10, 20):
        for t in ("T1", "T2", "T3"):
            r.append({"feature": "RISK", "h": h, "target": t, "s3_quant": (h in passh and t == "T2"), "판정불가": False})
    return pd.DataFrame(r)
def g2df(s1h, E=None, unj=()):
    E = E or {5: 0.002, 10: 0.003, 20: 0.005}
    return pd.DataFrame([{"feature": "RISK", "h": h, "평균E_gross(트랜치,h일)": E[h], "s1_초과BH": h in s1h, "판정불가": h in unj, "s2_블록": True, "s3_절대순수익>0": False,
                          "판정": "실패"} for h in (5, 10, 20)])
d, v = Z.decide(g1df({5, 10, 20}), g2df({5, 10, 20}))
ok("전부 충족 → 생존 3·'반증 실패' 문구·자동 진행 없음 명시", d["생존"].tolist() == [True] * 3 and "반증 실패" in v and "자동 진행 없음" in v)
d, v = Z.decide(g1df(set()), g2df({5, 10, 20}))
ok("Gate 1 전부 실패 → 종료", not d["생존"].any() and "종료" in v)
d, v = Z.decide(g1df({5, 10, 20}), g2df(set()))
ok("Gate 2 ① 전부 실패 → 종료", not d["생존"].any() and "종료" in v)
d, v = Z.decide(g1df({5, 10, 20}), g2df({5, 10, 20}, E={5: -0.001, 10: 0.003, 20: -0.002}))
ok("평균 E<=0이면 ①이 True여도 비생존(h10만 생존)", d["생존"].tolist() == [False, True, False])
d, v = Z.decide(g1df({20}), g2df({10, 20}))
ok("h별 교집합(Gate1 h20만·Gate2 h10·h20 → h20만 생존)", d["생존"].tolist() == [False, False, True] and "[20]" in v)
d, v = Z.decide(g1df({5, 10, 20}), g2df({5, 10, 20}, unj=(10,)))
ok("판정불가 포함 → 판정 보류 문구·해당 h 비생존", "판정불가" in v and d["생존"].tolist() == [True, False, True])
d, v = Z.decide(g1df({5, 10, 20}), g2df({5, 10, 20}, E={5: np.nan, 10: 0.003, 20: 0.005}))
ok("평균 E가 NaN이면 비생존", d["생존"].tolist() == [False, True, True])

# 6) 종단(K 축소): 신호가 A+B에만 있으면 생존, 439에만 있으면 종료
class small_k:
    def __init__(self, k=20): self.k = k
    def __enter__(self):
        self.o = (C.K_SHIFTS, dict(R.PREREG), dict(G2.PREREG2)); C.K_SHIFTS = self.k; R.PREREG["K_SHIFTS"] = self.k; G2.PREREG2["K_SHIFTS"] = self.k
    def __exit__(self, *a):
        C.K_SHIFTS = self.o[0]; R.PREREG.clear(); R.PREREG.update(self.o[1]); G2.PREREG2.clear(); G2.PREREG2.update(self.o[2])
def scenario(region):
    reg = (keep if region == "ab" else ~keep)[None, :]
    rr = np.random.default_rng(21)
    q2 = synth_prep(T=1150, M=M, seed=11)
    for h, P in q2["h"].items():
        s = np.log1p(P["T1"]); s = np.where(np.isfinite(s), s, 0.0); s = s / s.std()
        P["F"] = {"REV": rr.normal(size=s.shape), "RISK": np.where(reg, -(0.6 * s + rr.normal(size=s.shape)), rr.normal(size=s.shape)), "ATTN": rr.normal(size=s.shape), "LIQ": rr.normal(size=s.shape)}
    s1 = rr.normal(size=(T1_, M)); Y = np.where(reg, 0.5 * s1, 0.0) + rr.normal(size=(T1_, M)); Y[rr.random((T1_, M)) < .05] = np.nan
    F = noiseF(); F["RISK"] = np.where(reg, -s1, rr.normal(size=(T1_, M)))
    return mkprep1(F, Y), q2
px = lambda p: {h: p["Clf"][p["h"][h]["tpos"]] for h in (5, 10, 20)}
def run_sc(region):
    a, b = scenario(region); d = tempfile.mkdtemp(); msgs = []
    ca = os.path.join(d, "a.csv"); cb = os.path.join(d, "b.csv")
    pd.DataFrame([{"feature": "RISK", "h": h, "target": "T1", "ic_mean": R.observed(a[h], "RISK")[0]["ic_mean"]} for h in (5, 10, 20)]).to_csv(ca, index=False, encoding="utf-8-sig")
    N.eval_df(b, G2.CANDS, N.null_dummy).to_csv(cb, index=False, encoding="utf-8-sig")
    with small_k(20):
        o = Z.run_tl011(a, b, os.path.join(d, "o"), ca, cb, px(b), grp, log=msgs.append)
    return a, b, d, ca, cb, o, msgs
t0 = time.time()
a1, b1, d1, ca1, cb1, o1, ms1 = run_sc("ab")
ok("로그: 선행조건 2종 OK", sum("일치 OK" in m for m in ms1) == 2)
ok("Gate 1 family 1·trial 9·독립 IC 3", o1["meta1"]["families"] == 1 and o1["meta1"]["trials"] == 9 and set(o1["res1"]["df"]["feature"]) == {"RISK"})
ok("Gate 2 후보 3행·RISK만", len(o1["df2"]) == 3 and set(o1["df2"]["feature"]) == {"RISK"} and o1["meta2"]["후보"] == 3)
ok("A+B에 심은 신호: Gate 1 stage1 존재·IC>0", o1["res1"]["df"]["s1_IC"].any() and (o1["res1"]["df"]["ic_mean"] > 0).all())
ok("A+B에 심은 신호: 생존 h 1개 이상(종료 아님)", o1["dec"]["생존"].any() and "종료" not in o1["verdict"])
ok("결과 파일 생성", all(os.path.exists(os.path.join(d1, "o", f)) for f in ("tl011_pool_diag.csv", "tl011_decision.csv", "tl011_vs_full.csv", "g1/gate1_results.csv", "g2/gate2_results.csv", "g2/diag/g2_diag_year.csv")))
ok("Q5 절대순수익 = Q5 gross − 0.00206", np.allclose(o1["df2"]["Q5절대순수익(트랜치,h일)"], o1["df2"]["Q5평균_gross(트랜치,h일)"] - C.G2_COST_RT, atol=1e-15))
ok("진단 기준값 = Gate 2 평균E", all(abs(o1["dres"][(r.feature, r.h)]["base"]["평균E"] - r["평균E_gross(트랜치,h일)"]) < 1e-15 for _, r in o1["df2"].iterrows()))
ok("진단 Q5 구성에 그룹 439 비중 0", all(float(r["comp"].set_index("항목").loc["그룹 439 비중", "Q5"]) == 0.0 for r in o1["dres"].values()))
ok("pool_diag: A+B 비율 ≈ 0.7, 439 + A + B = 전체", abs(o1["pool"]["A+B 비율"].mean() - keep.mean()) < 0.02 and np.allclose(o1["pool"]["그룹 439"] + o1["pool"]["그룹 A"] + o1["pool"]["그룹 B"], o1["pool"]["일평균 RISK 유효(전체)"]))
Z.print_report(o1, out=lambda s: None); ok("print_report 동작", True)
with small_k(20):
    o1b = Z.run_tl011(a1, b1, os.path.join(d1, "o"), ca1, cb1, px(b1), grp, log=lambda *_: None)
pd.testing.assert_frame_equal(o1["df2"], o1b["df2"]); pd.testing.assert_frame_equal(o1["dec"], o1b["dec"]); ok("체크포인트 재실행 동일", True)

a2, b2_, d2, ca2, cb2, o2, ms2 = run_sc("439")
ok("439에만 신호: 제외 후 생존 없음·종료 판정", (not o2["dec"]["생존"].any()) and "종료" in o2["verdict"])
ok("439에만 신호: 제외 후 평균E ≤ 제외 전의 1/3(검정력 확인)", all(o2["df2"].set_index("h").loc[h, "평균E_gross(트랜치,h일)"] < N.eval_df(b2_, Z.CANDS3, N.null_dummy).set_index("h").loc[h, "평균E_gross(트랜치,h일)"] / 3 for h in (5, 10, 20)))

# 7) 안전장치
late = {"O": b1["O"], "Clf": b1["Clf"], "h": {h: {**P, "dates": pd.DatetimeIndex(P["dates"]) + pd.DateOffset(years=6)} for h, P in b1["h"].items()}}
ok("설계구간 밖 신호일 거부", raises(lambda: Z.run_tl011(a1, late, tempfile.mkdtemp(), ca1, cb1, px(b1), grp, log=lambda *_: None)))
old = C.G2_COST_RT; C.G2_COST_RT = 0.003
ok("사전등록 상수 변경 거부(Gate 1 시작 전)", raises(lambda: Z.run_tl011(a1, b1, tempfile.mkdtemp(), ca1, cb1, px(b1), grp, log=lambda *_: None)))
C.G2_COST_RT = old
ok("patched CANDS 복원(11개)", len(G2.CANDS) == 11)
ok("사전등록 상수 복원(K_SHIFTS=1000)", C.K_SHIFTS == 1000 and R.PREREG["K_SHIFTS"] == 1000 and G2.PREREG2["K_SHIFTS"] == 1000)

# 8) 모듈 분리
src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tl011.py"), encoding="utf-8").read()
ok("features/targets import 없음", all(s not in src for s in ("import features", "import targets", "from .features", "from .targets", "from . import features", "from . import targets")))

fails = [n for n, c in res if not c]
print(f"test_tl011: {len(res) - len(fails)}/{len(res)} PASS ({time.time()-t0:.0f}s)" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
