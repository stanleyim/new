import os, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from research import config as C, gate2_run as G2, near_run as N, tl011 as Z, tl012 as Y
from research.tests.test_gate2 import synth_prep
from research.tests.test_near import make_prep
from research.tests.test_synthetic import make_world

res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f):
    try: f(); return False
    except AssertionError: return True

t0 = time.time()
M = 300
grp = np.random.default_rng(5).choice(["439", "A", "B"], size=M, p=[0.3, 0.2, 0.5]); keep = Z.keep_mask(grp)
ok("후보 2개 = RISK h10·h20(TL-011 Gate 2 최종 통과)", Y.CANDS2 == [("RISK", 10), ("RISK", 20)])

def near_prep(region, seed=3, T=480):
    p = make_prep(T=T, M=M, seed=seed); rr = np.random.default_rng(seed + 100)
    reg = None if region == "none" else ((keep if region == "ab" else ~keep)[None, :])
    for h, P in p["h"].items():
        P["F"]["RISK"] = rr.normal(size=(T, M)); P["F"]["RISK"][rr.random((T, M)) < 0.05] = np.nan
        if reg is not None:
            P["T1"] = P["T1"] + np.where(reg, -0.02 * np.nan_to_num(P["F"]["RISK"]), 0.0)   # 방향 -1: 값이 작을수록 상승
    return p
pd_ = synth_prep(T=1150, M=M, seed=11)
tdir = tempfile.mkdtemp(); g2csv = os.path.join(tdir, "g2.csv"); t11csv = os.path.join(tdir, "t11.csv")
N.eval_df(pd_, G2.CANDS, N.null_dummy).to_csv(g2csv, index=False, encoding="utf-8-sig")
refAB = N.eval_df(Z.mask_g2(pd_, keep), Z.CANDS3, N.null_dummy); refAB.to_csv(t11csv, index=False, encoding="utf-8-sig")
px = lambda p: {h: p["Clf"][p["h"][h]["tpos"]] for h in (5, 10, 20)}

# 1) 선행 조건 검사기
ok("설계 A+B 재현: 일치 시 통과(2행 선별)", len(Y.check_design_vs_tl011(Z.mask_g2(pd_, keep), t11csv)) == 2)
ok("설계 A+B 재현: 마스킹 안 한 prep이면 중단", raises(lambda: Y.check_design_vs_tl011(pd_, t11csv)))
b = refAB.copy(); b.loc[(b.feature == "RISK") & (b.h == 20), "평균E_gross(트랜치,h일)"] += 1e-9; bp = os.path.join(tdir, "b.csv"); b.to_csv(bp, index=False, encoding="utf-8-sig")
ok("설계 A+B 재현: 1e-9 불일치 중단", raises(lambda: Y.check_design_vs_tl011(Z.mask_g2(pd_, keep), bp)))
mp = os.path.join(tdir, "m.csv"); refAB[refAB.h != 10].to_csv(mp, index=False, encoding="utf-8-sig")
ok("설계 A+B 재현: 후보 누락 중단", raises(lambda: Y.check_design_vs_tl011(Z.mask_g2(pd_, keep), mp)))

# 2) 종단: 신호가 A+B에만 → 통과 / 439에만 → 실패. 근접 결과가 설계 선행조건 뒤에만 계산됨.
def run(region, seed=3, near_csv=None, g2=g2csv, t11=t11csv, pdn=None):
    pn = near_prep(region, seed) if pdn is None else pdn; msgs = []; out = os.path.join(tempfile.mkdtemp(), "o")
    o = Y.run_tl012(pd_, grp, pn, grp, px(pn), g2, t11, out, ref_near_csv=near_csv, log=msgs.append)
    o["out"] = out
    return pn, o, msgs
pn1, o1, ms1 = run("ab")
df1 = o1["df"]
ok("후보 2행(RISK h10·h20)·판정불가 0", len(df1) == 2 and set(df1["h"]) == {10, 20} and set(df1["feature"]) == {"RISK"} and o1["meta"]["판정불가"] == 0)
ok("로그 순서: 설계 재현 2종 OK → 근접 평가 시작", [i for i, m in enumerate(ms1) if "일치 OK" in m] == [0, 1] and ms1[2].startswith("근접 평가 시작"))
ok("A+B에 심은 edge: 2개 통과", (df1["판정"] == "통과").all())
ok("null 이동량 수 = 허용 이동량 전부(T-79=401 안팎)", all(abs(n - (len(N.all_shifts(480)))) == 0 for n in df1["이동량 수"]) and df1["이동량 수"].iloc[0] > 300)
ok("Q5절대순수익 = Q5 gross − 0.00206", np.allclose(df1["Q5절대순수익(트랜치,h일)"], df1["Q5평균_gross(트랜치,h일)"] - C.G2_COST_RT, atol=1e-15))
ok("NEAR_CANDS 복원(5개)·사전등록 상수 불변", len(N.NEAR_CANDS) == 5 and C.G2_COST_RT == 0.00206)
ok("진단 구성: Q5의 그룹 439 비중 0", all(float(r["comp"].set_index("항목").loc["그룹 439 비중", "Q5"]) == 0.0 for r in o1["dres"].values()))
ok("결과·진단 파일 생성", all(os.path.exists(os.path.join(o1["out"], f)) for f in ("tl012_near_results.csv", "diag/g2_diag_comp.csv", "diag/g2_diag_year.csv", "diag/g2_diag_conc.csv")))
pn2, o2, _ = run("439")
ok("439에만 심은 edge: 제외 후 통과 없음", (o2["df"]["판정"] != "통과").all())
ok("검정력: 신호 있는 쪽 평균E ≥ 신호 없는 쪽 ×3", (o1["df"]["평균E_gross(트랜치,h일)"].values > 3 * np.abs(o2["df"]["평균E_gross(트랜치,h일)"].values)).all())

# 3) 병기표(전 유니버스 근접 csv)
full = N.judge(N.eval_df(pn1, Y.CANDS2, N.null_all)); fcsv = os.path.join(tdir, "near_ref.csv"); full.to_csv(fcsv, index=False, encoding="utf-8-sig")
_, o3, _ = run("ab", near_csv=fcsv)
c3 = o3["cmp"]
ok("병기표 2행·A+B 열 = 결과·전체 열 = ref csv", len(c3) == 2 and all(abs(c3.loc[i, "평균E_gross(트랜치,h일)|A+B"] - o3["df"].set_index(["feature", "h"]).loc[(c3.loc[i, "feature"], c3.loc[i, "h"]), "평균E_gross(트랜치,h일)"]) < 1e-15 for i in c3.index))
Y.print_report(o3, out=lambda s: None); ok("print_report 동작", True)

# 4) 안전장치: 선행 조건 실패 시 근접 미계산·구간 밖 신호일·상수 변경 거부
msgs = []
def bad_run():
    try: Y.run_tl012(pd_, grp, pn1, grp, px(pn1), g2csv, bp, os.path.join(tempfile.mkdtemp(), "o"), log=msgs.append)
    except AssertionError: raise
ok("TL-011 불일치 시 중단·근접 평가 미시작", raises(bad_run) and not any("근접 평가 시작" in m for m in msgs))
badg2 = pd.read_csv(g2csv, encoding="utf-8-sig"); badg2.loc[0, "평균E_gross(트랜치,h일)"] += 1e-9; bg = os.path.join(tdir, "bg.csv"); badg2.to_csv(bg, index=False, encoding="utf-8-sig")
msgs2 = []
def bad_run2():
    Y.run_tl012(pd_, grp, pn1, grp, px(pn1), bg, t11csv, os.path.join(tempfile.mkdtemp(), "o"), log=msgs2.append)
ok("gate2_results.csv 불일치 시 중단·근접 평가 미시작", raises(bad_run2) and not any("근접 평가" in m for m in msgs2))
ok("근접 구간 밖 신호일 거부", raises(lambda: Y.run_tl012(pd_, grp, pd_, grp, px(pd_), g2csv, t11csv, tempfile.mkdtemp(), log=lambda *_: None)))
old = C.G2_COST_RT; C.G2_COST_RT = 0.003
ok("사전등록 상수 변경 거부", raises(lambda: Y.run_tl012(pd_, grp, pn1, grp, px(pn1), g2csv, t11csv, tempfile.mkdtemp(), log=lambda *_: None)))
C.G2_COST_RT = old
ok("그룹 439 없음 거부", raises(lambda: Y.run_tl012(pd_, grp, pn1, np.array(["A"] * M, dtype=object), px(pn1), g2csv, t11csv, tempfile.mkdtemp(), log=lambda *_: None)))
ok("patched 복원 후 NEAR_CANDS 5개·K_SHIFTS 1000", len(N.NEAR_CANDS) == 5 and C.K_SHIFTS == 1000)

# 5) 로더~라벨 실제 경로(합성 월드): 그룹 라벨·종가 형상·기간 상한
with tempfile.TemporaryDirectory() as tmp:
    paths = make_world(tmp)
    pw, gw, pxw, iw = Y.build_prep_g(paths, (pd.Timestamp("2022-07-01"), pd.Timestamp("2023-02-28")), "w")
    ok("build_prep_g: 그룹 라벨 길이 = 종목 수·라벨 {439,A}", len(gw) == pw["O"].shape[1] and set(gw.tolist()) <= {"439", "A", "B"} and "439" in set(gw.tolist()))
    ok("build_prep_g: 종가 형상 = T1 형상", all(pxw[h].shape == pw["h"][h]["T1"].shape for h in (5, 10, 20)))
    cut, gc, _, _ = Y.build_prep_g(paths, (pd.Timestamp("2022-07-01"), pd.Timestamp("2022-12-30")), "c")
    ok("build_prep_g: 상한 이후 미적재", cut["O"].shape[0] == len(pd.bdate_range("2017-01-02", "2022-12-30")) and (C.SIGNAL_START, C.SIGNAL_END) == (N.DESIGN[0], N.DESIGN[1]))

src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tl012.py"), encoding="utf-8").read()
ok("features/targets import 없음", all(s not in src for s in ("import features", "import targets", "from .features", "from .targets", "from . import features", "from . import targets")))
fails = [n for n, c in res if not c]
print(f"test_tl012: {len(res) - len(fails)}/{len(res)} PASS ({time.time()-t0:.0f}s)" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
