import os, sys, copy, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, pandas as pd
from scipy.stats import rankdata
from research import config as C, gate2 as G, gate2_run as G2, near_run as N, tl009 as X, tl010 as Z
from research.tests.test_gate2 import synth_prep

res = []
def ok(n, c): res.append((n, bool(c)))
def raises(f):
    try: f(); return False
    except AssertionError: return True

# 0) 후보 6개 = TL-009 Gate 1 통과 12 trial의 (Feature,h) 집합(수기 목록 대조)
tl009_pass = ["REV-h5-T2", "REV-h10-T2", "RISK-h5-T1", "RISK-h5-T2", "RISK-h5-T3", "RISK-h10-T1", "RISK-h10-T2", "RISK-h10-T3",
              "RISK-h20-T1", "RISK-h20-T2", "RISK-h20-T3", "ATTN-h5-T2"]
exp = {(s.split("-")[0], int(s.split("-")[1][1:])) for s in tl009_pass}
ok("후보 6개 = TL-009 통과 12 trial의 (Feature,h)", set(Z.CANDS6) == exp and len(Z.CANDS6) == 6 and len(tl009_pass) == 12)
ok("방향 설정 불변(REV·RISK·ATTN = -1)", all(C.FEATURE_DIRECTION[k] == -1 for k in ("REV", "RISK", "ATTN")))

# 합성 세계(M=300 → 상위 1/3 약 100종목, 일별 거래대금)
M = 300
prep = synth_prep(T=1150, M=M, seed=11)
idx = prep["h"][5]["dates"]
rng = np.random.default_rng(3)
DVu = pd.DataFrame(np.exp(rng.normal(20, 1.5, (len(idx), M))), index=idx, columns=range(M))
hi_mask = X.top_tercile_mask(DVu.values)[0]
snap = {h: {k: v.copy() for k, v in prep["h"][h]["F"].items()} for h in prep["h"]}

# 1) build_hi_prep_g2: F만 마스킹, 나머지 불변, 입력 불변
ph, dgs = Z.build_hi_prep_g2(prep, DVu)
ok("Feature 3개만(REV·RISK·ATTN)", all(list(ph["h"][h]["F"]) == ["REV", "RISK", "ATTN"] for h in ph["h"]))
ok("상위 1/3에서만 유한·값은 원본 그대로", all(np.array_equal(ph["h"][h]["F"][k], np.where(hi_mask, snap[h][k], np.nan), equal_nan=True) for h in ph["h"] for k in Z.FEATS))
ok("T1·status·DV·tpos·O·Clf 불변(동일 객체)", all(ph["h"][h][k] is prep["h"][h][k] for h in ph["h"] for k in ("T1", "status", "DV", "tpos", "dates", "block")) and ph["O"] is prep["O"] and ph["Clf"] is prep["Clf"])
ok("입력 prep 불변", all(np.array_equal(prep["h"][h]["F"][k], snap[h][k], equal_nan=True) for h in prep["h"] for k in snap[h]))
ok("형상 불일치 중단", raises(lambda: Z.build_hi_prep_g2(prep, DVu.iloc[:, :10])))

# 2) 선택은 라벨과 무관: T1·status 교란에도 필터 후 F·풀·Q5 동일 / 필터는 거래대금만 사용
prep_pert = {"O": prep["O"], "Clf": prep["Clf"], "h": {h: {**P, "T1": np.random.default_rng(1).normal(size=P["T1"].shape), "status": np.ones_like(P["status"])} for h, P in prep["h"].items()}}
php, _ = Z.build_hi_prep_g2(prep_pert, DVu)
same = True
for h in (5, 10, 20):
    for k in Z.FEATS:
        a = G.select_masks(ph["h"][h]["F"][k], -1); b = G.select_masks(php["h"][h]["F"][k], -1)
        same &= all(np.array_equal(x, y) for x, y in zip(a, b))
ok("T1·status 교란해도 풀·Q5 동일(라벨 비의존)", same)
pool, q5, dayok = G.select_masks(ph["h"][10]["F"]["RISK"], -1)
ok("풀 ⊆ 상위 1/3, Q5 ⊆ 풀", (~pool | hi_mask).all() and (~q5 | pool).all())
frac = q5.sum() / pool.sum()
ok("Q5 ≈ 풀의 20%", 0.19 < frac < 0.23)
ok("풀 일평균 약 100(=300/3)", 95 < pool.sum(1)[dayok].mean() < 105)

# 3) 독립 구현 수기 대조: 상위 1/3·Q5 규칙·E를 별도 코드(정수 올림)로 재계산 → gate2.evaluate 평균E·Q5 절대순수익과 일치
def indep(Fh, T1, DVv, d):
    Tn = Fh.shape[0]; E = np.full(Tn, np.nan); mqs = np.full(Tn, np.nan)
    for t in range(Tn):
        v = DVv[t]; okv = np.isfinite(v) & (v > 0); n = int(okv.sum())
        if n < 150: continue
        r2 = np.rint(2 * rankdata(v[okv])).astype(np.int64)
        hi = np.zeros(len(v), bool); hi[np.where(okv)[0][-(-(3 * r2) // (2 * n)) == 3]] = True
        s = d * np.where(hi, Fh[t], np.nan); m = np.isfinite(s); nn = int(m.sum())
        if nn < 50: continue
        r2 = np.rint(2 * rankdata(s[m])).astype(np.int64)
        q = -(-(5 * r2) // (2 * nn))
        Q = np.zeros(len(v), bool); Q[np.where(m)[0][q == 5]] = True
        y = T1[t]; fq = Q & np.isfinite(y); fp = m & np.isfinite(y)
        if fq.sum() > 0 and fp.sum() > 0:
            mqs[t] = y[fq].mean(); E[t] = mqs[t] - y[fp].mean()
    return E, mqs
for (k, h) in (("RISK", 10), ("REV", 5), ("ATTN", 5)):
    P0 = prep["h"][h]
    E_i, mq_i = indep(P0["F"][k], P0["T1"], DVu.loc[P0["dates"]].values, -1)
    r = N.eval_df(ph, [(k, h)], N.null_dummy).iloc[0]
    ok(f"독립 구현 일치 {k} h{h}: 평균E·Q5절대순수익", abs(np.nanmean(E_i) - r["평균E_gross(트랜치,h일)"]) < 1e-12 and abs((np.nanmean(mq_i) - C.G2_COST_RT) - r["Q5절대순수익(트랜치,h일)"]) < 1e-12 and int(np.isfinite(E_i).sum()) == r["평가일"])

# 4) check_unfiltered: 필터 전 재현
tdir = tempfile.mkdtemp(); ref_csv = os.path.join(tdir, "gate2_results.csv")
ref_df = N.eval_df(prep, G2.CANDS, N.null_dummy)
ref_df.to_csv(ref_csv, index=False, encoding="utf-8-sig")
ok("필터 전 재현 일치 시 통과(6개 선별)", Z.check_unfiltered(prep, ref_csv) == 6)
bad = ref_df.copy(); bad.loc[(bad.feature == "RISK") & (bad.h == 10), "평균E_gross(트랜치,h일)"] += 1e-9
bp = os.path.join(tdir, "bad.csv"); bad.to_csv(bp, index=False, encoding="utf-8-sig")
ok("1e-9 불일치 시 중단", raises(lambda: Z.check_unfiltered(prep, bp)))
miss = ref_df[~((ref_df.feature == "ATTN") & (ref_df.h == 5))]; mp = os.path.join(tdir, "miss.csv"); miss.to_csv(mp, index=False, encoding="utf-8-sig")
ok("후보 누락 시 중단", raises(lambda: Z.check_unfiltered(prep, mp)))
ok("필터 후 prep으로는 필터 전 재현이 깨짐(검사가 필터 유무를 구분)", raises(lambda: Z.check_unfiltered(ph, ref_csv)))

# 5) 종단: 신호가 상위 1/3에만 있으면 통과, 하위에만 있으면 미통과. 같은 폴더 재실행 동일.
def scenario(region):
    p = synth_prep(T=1150, M=M, seed=11)
    rr = np.random.default_rng(21); reg = hi_mask if region == "hi" else ~hi_mask
    for h, P in p["h"].items():
        s = np.log1p(P["T1"]); s = np.where(np.isfinite(s), s, 0.0); s = s / s.std()
        for k in ("REV", "RISK"):
            P["F"][k] = np.where(reg, -(0.6 * s + rr.normal(size=s.shape)), rr.normal(size=s.shape))   # 방향 -1이므로 -score
    return p
px = lambda p: {h: p["Clf"][p["h"][h]["tpos"]] for h in (5, 10, 20)}
grp = np.random.default_rng(5).choice(["439", "A", "B"], size=M, p=[0.2, 0.2, 0.6])
def run_sc(region):
    p = scenario(region); d = tempfile.mkdtemp(); msgs = []
    rc = os.path.join(d, "ref.csv"); N.eval_df(p, G2.CANDS, N.null_dummy).to_csv(rc, index=False, encoding="utf-8-sig")
    out = Z.run_tl010(p, DVu, os.path.join(d, "o"), rc, px(p), grp, log=msgs.append)
    return p, d, rc, out, msgs
p1, d1, rc1, (df1, m1, f1, dr1, c1), ms1 = run_sc("hi")
ok("후보 6행·판정불가 0·family=Feature 3(REV2·RISK3·ATTN1)", len(df1) == 6 and m1["후보"] == 6 and m1["판정불가"] == 0 and df1.groupby("feature").size().to_dict() == {"ATTN": 1, "REV": 2, "RISK": 3})
ok("로그: 필터 전 재현 OK", any("일치 OK" in m for m in ms1))
ok("상위 1/3에 심은 신호 검출: REV·RISK 5개 통과", (df1[df1.feature.isin(["REV", "RISK"])]["판정"] == "통과").all())
ok("신호 없는 ATTN은 미통과", (df1[df1.feature == "ATTN"]["판정"] != "통과").all())
ok("Q5절대순수익 = Q5 gross − 0.00206", np.allclose(df1["Q5절대순수익(트랜치,h일)"], df1["Q5평균_gross(트랜치,h일)"] - C.G2_COST_RT, atol=1e-15))
ok("결과 파일 생성", all(os.path.exists(os.path.join(d1, "o", f)) for f in ("gate2_results.csv", "gate2_summary.json", "tl010_vs_unfiltered.csv", "tl010_filter_diag.csv", "diag/g2_diag_comp.csv", "diag/g2_diag_conc.csv", "diag/g2_diag_year.csv", "diag/g2_diag_terc.csv")))
df1b = Z.run_tl010(p1, DVu, os.path.join(d1, "o"), rc1, px(p1), grp, log=lambda *_: None)[0]
pd.testing.assert_frame_equal(df1, df1b); ok("체크포인트 재실행 동일", True)
ok("진단 기준값 = Gate 2 평균E·Q5절대순수익", all(abs(dr1[(r.feature, r.h)]["base"]["평균E"] - r["평균E_gross(트랜치,h일)"]) < 1e-15 and abs(dr1[(r.feature, r.h)]["base"]["Q5절대순수익"] - r["Q5절대순수익(트랜치,h일)"]) < 1e-12 for _, r in df1.iterrows()))
ok("진단 6후보", set(dr1) == set(Z.CANDS6))
ref1 = pd.read_csv(rc1, encoding="utf-8-sig").set_index(["feature", "h"])
ok("병기표 6행·전유니버스 열 = ref csv 값·상위1/3 열 = 결과", len(c1) == 6 and all(abs(c1.loc[i, "평균E_gross(트랜치,h일)|전유니버스"] - ref1.loc[(c1.loc[i, "feature"], c1.loc[i, "h"]), "평균E_gross(트랜치,h일)"]) < 1e-15 and abs(c1.loc[i, "평균E_gross(트랜치,h일)|상위1/3"] - df1.set_index(["feature", "h"]).loc[(c1.loc[i, "feature"], c1.loc[i, "h"]), "평균E_gross(트랜치,h일)"]) < 1e-15 for i in c1.index))
Z.print_report(df1, m1, f1, c1, dr1, out=lambda s: None); ok("print_report 동작", True)
p2, d2, rc2, (df2, m2, *_), ms2 = run_sc("lo")
# 신호 없는 풀에서의 우연 통과는 명목 오류율 안에서 가능(이 시드에서 RISK h20 1건 관찰, p=0.015 → 검정 보정은 family 내부 BH뿐). 결정적 구조 검증은 아래 평균E 격차·hi-only 5/5 통과·p값 분리로 한다.
ok("하위 2/3에만 신호면 필터 후 통과 ≤1/6(우연 통과 허용)·RISK h5·h10·REV 전부 미통과", (df2["판정"] == "통과").sum() <= 1 and (df2[~df2.set_index(["feature", "h"]).index.isin([("RISK", 20)])]["판정"] != "통과").all())
ok("신호 위치별 p값 분리: hi-only 최대 p < lo-only REV·RISK 최소 p", df1[df1.feature.isin(["REV", "RISK"])]["p_E"].max() < df2[df2.feature.isin(["REV", "RISK"])]["p_E"].min())
ok("신호 위치별 평균E 격차(hi > lo ×3 이상)", df1[df1.feature == "RISK"]["평균E_gross(트랜치,h일)"].mean() > 3 * df2[df2.feature == "RISK"]["평균E_gross(트랜치,h일)"].mean())

# 6) 안전장치: 설계구간 밖 신호일·사전등록 상수 변경·지문 불일치 거부
late = {"O": p1["O"], "Clf": p1["Clf"], "h": {h: {**P, "dates": pd.DatetimeIndex(P["dates"]) + pd.DateOffset(years=6)} for h, P in p1["h"].items()}}
ok("설계구간 밖 신호일 거부", raises(lambda: Z.run_tl010(late, DVu, tempfile.mkdtemp(), rc1, px(p1), grp, log=lambda *_: None)))
old = C.G2_COST_RT; C.G2_COST_RT = 0.003
ok("사전등록 상수 변경 거부", raises(lambda: Z.run_tl010(p1, DVu, tempfile.mkdtemp(), rc1, px(p1), grp, log=lambda *_: None)))
C.G2_COST_RT = old
ok("다른 입력으로 같은 폴더 사용 거부(지문)", raises(lambda: Z.run_tl010(p2, DVu, os.path.join(d1, "o"), rc2, px(p2), grp, log=lambda *_: None)))
ok("patched CANDS 복원(11개)", len(G2.CANDS) == 11)

# 7) 모듈 분리
src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tl010.py"), encoding="utf-8").read()
ok("features/targets import 없음", all(s not in src for s in ("import features", "import targets", "from .features", "from .targets", "from . import features", "from . import targets")))

fails = [n for n, c in res if not c]
print(f"test_tl010: {len(res) - len(fails)}/{len(res)} PASS" + (f" FAIL={fails}" if fails else " ALL PASS"))
sys.exit(1 if fails else 0)
