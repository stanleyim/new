"""TL-009: 고거래대금 상위 1/3 유니버스에서 REV·RISK·ATTN Gate 1. 실데이터 실행은 Colab 전용.
날짜별 유니버스(U) ∧ 거래대금 20일평균 유효(유한, >0) 종목의 평균순위 기반 3분위 중 최상위(q=3)만 Feature를 남긴다.
필터는 Feature·Target과 무관(거래대금만 사용, T 시점 후행 20일)이며 Target(T1~T3)은 재계산하지 않는다(전 유니버스 기준 유지).
Gate 1 규칙·상수·permutation은 D5와 동일(d5_run 재사용). 이 모듈은 features/targets를 import하지 않는다."""
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from . import config as C
from . import d5_run as R
from . import d5_meta as M

FEATS = ("REV", "RISK", "ATTN")        # 사전등록: MOM·ANCH(가설 반대 부호 실패)·LIQ(TL-008 종료) 제외
N_TERCILES = 3
MIN_DV_N = N_TERCILES * C.GATE1_MIN_N   # 150: 그날 거래대금 유효 유니버스가 이보다 적으면 그날 결측(실제로는 약 2,000)


def top_tercile_mask(DV, min_n=MIN_DV_N):
    """DV: T×M(유니버스 밖·이상치는 NaN). 반환 mask(T×M bool)와 일별 진단 DataFrame(n_dv, n_high).
    q = ceil(3*평균순위/n) 정수 연산(동률은 같은 분위), q==3이 상위 1/3. n_dv < min_n이면 그날 전부 False."""
    DV = np.asarray(DV, float)
    T, Mn = DV.shape
    mask = np.zeros((T, Mn), bool)
    rows = []
    for t in range(T):
        v = DV[t]
        ok = np.isfinite(v) & (v > 0)
        n = int(ok.sum())
        nh = 0
        if n >= min_n:
            r2 = np.rint(2 * rankdata(v[ok])).astype(np.int64)
            q = np.clip((N_TERCILES * r2 + 2 * n - 1) // (2 * n), 1, N_TERCILES)
            hi = np.zeros(Mn, bool); hi[np.where(ok)[0][q == N_TERCILES]] = True
            mask[t] = hi; nh = int(hi.sum())
        rows.append((t, n, nh))
    return mask, pd.DataFrame(rows, columns=["row", "n_dv", "n_high"])


def build_hi_prep(prep, DVu):
    """prep: gate1_prep.prepare 결과(전 Feature). DVu: 캘린더×종목 DataFrame(유니버스 밖·이상치 NaN, 열은 prep과 같은 순서).
    반환 h→같은 구조에 F={REV,RISK,ATTN}(상위 1/3 외 NaN)만 있는 prep, h→진단 DataFrame. T1·T2·T1_L1은 그대로."""
    out, diags = {}, {}
    for h, P in prep.items():
        idx = P["dates"]
        dv = DVu.loc[idx].values
        shp = next(iter(P["F"].values())).shape
        assert dv.shape == shp, f"거래대금 형상 불일치 h={h}: {dv.shape} vs {shp}"
        mask, diag = top_tercile_mask(dv)
        diag.index = idx
        out[h] = {k: P[k] for k in ("dates", "block", "T1", "T2", "T1_L1")}
        out[h]["F"] = {k: np.where(mask, P["F"][k], np.nan) for k in FEATS}
        diags[h] = diag
    return out, diags


def check_unfiltered(prep, gate1_csv):
    """선행 조건: 필터 전 prep에서 REV·RISK·ATTN IC 평균이 D5 gate1_results.csv(T1 행)와 일치해야 한다(atol 1e-12)."""
    ref = pd.read_csv(gate1_csv, encoding="utf-8-sig")
    ref = ref[ref["target"] == "T1"].set_index(["feature", "h"])
    for h in sorted(prep):
        for k in FEATS:
            r1 = R.observed(prep[h], k)[0]
            exp = ref.loc[(k, h), "ic_mean"]
            assert abs(r1["ic_mean"] - exp) <= 1e-12, f"원본 {k} IC 불일치 h={h}: {r1['ic_mean']} vs {exp}"


def summarize_filter(diags):
    rows = []
    for h, d in sorted(diags.items()):
        ok = d["n_high"] > 0
        rows.append({"h": h, "신호일": len(d), "필터 적용일": int(ok.sum()), "일평균 거래대금 유효 유니버스": float(d.loc[ok, "n_dv"].mean()),
                     "일평균 상위1/3 종목": float(d.loc[ok, "n_high"].mean()),
                     "상위1/3 비율": float((d.loc[ok, "n_high"] / d.loc[ok, "n_dv"]).mean())})
    return pd.DataFrame(rows)


def run_tl009(prep, DVu, out_dir, gate1_csv, log=print):
    """①필터 전 재현 ②필터·판정 불가 메타(마스크만) ③Gate 1(D5와 동일 규칙, family=Feature 3개, 27 trial)."""
    check_unfiltered(prep, gate1_csv)
    log("필터 전 REV·RISK·ATTN IC가 D5 gate1_results.csv와 일치 OK")
    prep_hi, diags = build_hi_prep(prep, DVu)
    fdf = summarize_filter(diags)
    meta_df = M.eligibility_meta(prep_hi)
    res, meta = R.run_gate1(prep_hi, out_dir, log=log)
    return res, meta, fdf, meta_df


def print_report(res, meta, fdf, meta_df, gate1_csv, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 50)
    out("=== 필터 구성 진단(성과 무관) ==="); out(fdf.round(4).to_string(index=False))
    out("\n=== 판정 불가 메타(마스크만) ==="); out(meta_df.to_string(index=False))
    df = res["df"]
    out("\n=== TL-009 Gate 1 (독립 IC 검정 9개, T1·T3 동일) ===")
    a = df[df["target"] == "T1"][["feature", "h", "ic_mean", "ic_t", "p_ic", "bh_q", "s1_IC", "agree", "agree_thr", "s2_agree"]]
    out(a.round(4).to_string(index=False))
    out("\n=== 분위 단계 (stage2 통과분) ===")
    b = df[df["s2_agree"]][["feature", "h", "target", "spread", "spread_thr", "mono", "mono_thr", "s3_quant", "판정"]]
    out(b.round(4).to_string(index=False) if len(b) else "stage2 통과 없음")
    ref = pd.read_csv(gate1_csv, encoding="utf-8-sig")
    ref = ref[ref["target"] == "T1"].set_index(["feature", "h"])
    cmp_ = a.set_index(["feature", "h"])[["ic_mean"]].rename(columns={"ic_mean": "상위1/3_IC"})
    cmp_["전유니버스_IC(D5)"] = [ref.loc[i, "ic_mean"] for i in cmp_.index]
    cmp_["비율"] = cmp_["상위1/3_IC"] / cmp_["전유니버스_IC(D5)"]
    out("\n=== 전 유니버스(D5) 대비 IC (정보용, 판정 불변) ==="); out(cmp_.round(4).to_string())
    out(f"\n요약: trial {meta['trials']} | family {meta['families']} | 독립 IC 검정 {meta['independent_IC_tests']} | 판정불가 {meta['n_판정불가']} | "
        f"stage1 {meta['stage1_IC_BH']}/27 → stage2 {meta['stage2_agree']}/27 → stage3 {meta['stage3_quantile']}/27")
    ps = df[df["s3_quant"]]
    out("Gate 2 후보: " + (", ".join(f"{r.feature}-h{r.h}-{r.target}" for r in ps.itertuples()) if len(ps) else "없음"))
