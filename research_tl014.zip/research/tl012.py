"""TL-012: RISK h10·h20, 그룹 439 제외(A+B) 유니버스의 2023~24 근접 검증. 실데이터 실행은 Colab 전용.
TL-005 근접 검증 코드(near_run)를 그대로 재사용한다: 같은 파이프라인, null=허용 이동량 전부(TL-005 승인), 판정 ①초과 E p+family BH ②블록 양비율≥null 95th ③Q5 비용 후 절대순수익>0.
차이는 그룹 439의 RISK 값을 NaN으로 만든다는 것뿐(풀=A+B ∧ RISK 유효). 2023~24 결과는 선행조건(설계구간 재현 2종)이 모두 충족된 뒤에만 계산한다.
이 모듈은 features/targets를 import하지 않는다."""
import os
import numpy as np
import pandas as pd
from . import config as C
from . import gate2_run as G2
from . import near_run as N
from . import g2_diag as DG
from . import tl011 as Z

CANDS2 = [("RISK", 10), ("RISK", 20)]       # 사전등록: TL-011 Gate 2 최종 통과 h만(h5는 ③ 실패로 제외), 변경 불가


def build_prep_g(paths, window, label=""):
    """near_run.build_prep과 같은 경로 + 종목별 그룹 라벨·신호일 종가(진단용). 반환 (prep, group, px_by_h, info)."""
    from .run_d3d4 import run
    from .gate2_prep import prepare_g2, dollar_volume_20
    with N.period(*window):
        D, U, parts, F, labels = run(*paths, verbose=False)
        assert D["calendar"].max() <= window[1], "데이터 상한 초과 적재"
        DV = dollar_volume_20(D["close"], D["volume"], D["outlier"])
        prep = prepare_g2(D, U, F, labels, DV, list(N.HORIZONS))
        cl = D["close"].values
        px = {h: cl[prep["h"][h]["tpos"]] for h in prep["h"]}
        group = D["meta"]["group"].reindex(D["close"].columns).values
        assert len(group) == cl.shape[1] and all(isinstance(g, str) for g in group), "그룹 라벨 누락·형상 불일치"
        info = {"label": label, "calendar": f"{D['calendar'].min().date()}~{D['calendar'].max().date()}",
                "신호일": {h: len(prep["h"][h]["dates"]) for h in N.HORIZONS},
                "그룹별 종목 수": pd.Series(group).value_counts().to_dict()}
    return prep, group, px, info


def check_design_vs_tl011(prep_masked, tl011_csv):
    """선행 조건 2: 설계구간 A+B(439 제외) RISK h10·h20 경로가 TL-011 g2/gate2_results.csv와 일치(REPL_COLS, rtol 1e-9·atol 1e-12)."""
    ref = pd.read_csv(tl011_csv, encoding="utf-8-sig")
    want = set(CANDS2)
    ref2 = ref[[(r.feature, int(r.h)) in want for r in ref.itertuples()]]
    assert len(ref2) == len(CANDS2), f"TL-011 결과에 RISK h10·h20이 모두 있어야 함: {len(ref2)}"
    new = N.eval_df(prep_masked, CANDS2, N.null_dummy)
    bad = N.check_replication(new, ref2)
    assert not bad, f"TL-011 설계구간 A+B 재현 실패 -> TL-012 중단(2023~24 미계산): {bad[:12]}"
    return ref2


def compare_near_full(df, near_csv):
    """정보용(판정 불변): A+B 근접 결과 vs 전 유니버스 근접 결과(TL-005 new_near_out/near_results.csv)."""
    ref = pd.read_csv(near_csv, encoding="utf-8-sig").set_index(["feature", "h"])
    rows = []
    for r in df.itertuples():
        k = (r.feature, r.h)
        row = {"feature": r.feature, "h": r.h}
        for c in ("평균E_gross(트랜치,h일)", "초과연환산(=E×252/h)", "Q5절대순수익(트랜치,h일)", "Q5_CAGR", "break_even_절대_bp"):
            row[f"{c}|A+B"] = float(df.loc[r.Index, c]); row[f"{c}|전체(TL-005)"] = float(ref.loc[k, c])
        rows.append(row)
    return pd.DataFrame(rows)


def run_tl012(prep_d, grp_d, prep_n, grp_n, px_n, ref_g2_csv, ref_tl011_csv, out_dir, ref_near_csv=None, log=print):
    """①설계구간 전 유니버스 11후보 재현(gate2_results.csv) ②설계구간 A+B 재현(TL-011) ③근접 구간 검사 ④근접 평가(허용 이동량 전부) ⑤사후 진단."""
    N.replicate_design(prep_d, ref_g2_csv)
    log("설계구간 전 유니버스 11후보 경로가 gate2_results.csv와 일치 OK")
    keep_d = Z.keep_mask(grp_d)
    md = Z.mask_g2(prep_d, keep_d)
    ref2 = check_design_vs_tl011(md, ref_tl011_csv)
    log("설계구간 A+B(439 제외) RISK h10·h20 경로가 TL-011 결과와 일치 OK")
    keep_n = Z.keep_mask(grp_n)
    for h in N.HORIZONS:
        d = pd.DatetimeIndex(prep_n["h"][h]["dates"])
        assert d.min() >= N.NEAR[0] and d.max() <= N.NEAR[1], "근접 구간 밖 신호일"
    mn = Z.mask_g2(prep_n, keep_n)
    assert all(not np.isfinite(P["F"]["RISK"][:, ~keep_n]).any() for P in mn["h"].values()), "그룹 439 열에 유한 Feature 잔존"
    os.makedirs(out_dir, exist_ok=True)
    log("근접 평가 시작(2023~24, 허용 이동량 전부)")
    with N.patched(N, "NEAR_CANDS", CANDS2):
        df, meta = N.run_near(mn, log=log)
    dres = DG.run_diag(mn, px_n, grp_n, cands=CANDS2, log=log)
    DG.save_report(dres, os.path.join(out_dir, "diag"))
    cmp_ = compare_near_full(df, ref_near_csv) if ref_near_csv and os.path.exists(ref_near_csv) else None
    df.to_csv(os.path.join(out_dir, "tl012_near_results.csv"), index=False, encoding="utf-8-sig")
    if cmp_ is not None:
        cmp_.to_csv(os.path.join(out_dir, "tl012_vs_full_near.csv"), index=False, encoding="utf-8-sig")
    return {"df": df, "meta": meta, "design_ab": ref2, "dres": dres, "cmp": cmp_}


def print_report(o, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 60)
    N.print_report(o["df"], o["meta"], o["design_ab"], out)
    if o["cmp"] is not None:
        out("\\n=== 병기: A+B vs 전 유니버스 근접(TL-005) (정보용, 판정 불변; 풀 정의가 다름) ==="); out(o["cmp"].round(4).T.to_string(header=False))
    out("\\n=== Q5 구성(그룹 비중) ===")
    for (k, h), r in o["dres"].items():
        c = r["comp"].set_index("항목")
        out(f"[{k} h={h}] " + ", ".join(f"{n} Q5 {float(c.loc[n, 'Q5']):.3f} / 풀 {float(c.loc[n, '풀']):.3f}" for n in ("그룹 439 비중", "그룹 A 비중", "그룹 B 비중")))
    out("\\n(집중도·연도별·3분위는 Drive diag/*.csv)")
