"""TL-011: RISK edge의 '그룹 439 의존' 반증 진단. 실데이터 실행은 Colab 전용.
그룹 439(현재 유동성 유니버스 439종목)를 Feature에서 제외(NaN)하고, 나머지 A+B 종목만으로 RISK(h5·h10·h20)를 D5 Gate 1(전 규칙 동일)과
Gate 2(TL-004와 동일 구조: 방향 정렬 Q5 동일가중 롱, 일별 트랜치, 왕복 0.206% 트랜치마다 전액, 풀=A+B ∧ RISK 유효 동일가중)로 재검정한다.
사전등록 종료 규칙: h별 생존 = [Gate 1 통과(어느 Target이든 stage3 통과)] ∧ [Gate 2 ① 초과 E p + family 내부 BH q 통과] ∧ [평균 E>0].
생존 h가 하나도 없으면 RISK 계열 종료. 생존 h가 있어도 자동 진행 없음(별도 승인·2023~24 확인 필수). Gate 2 ②③은 병기(판정 불변).
이 모듈은 features/targets를 import하지 않는다. NaN 마스킹은 열 제거와 동치(테스트로 검증)."""
import os
import numpy as np
import pandas as pd
from . import config as C
from . import d5_run as R
from . import gate2_run as G2
from . import near_run as N
from . import g2_diag as DG

FEATURE = "RISK"
HS = (5, 10, 20)
CANDS3 = [("RISK", 5), ("RISK", 10), ("RISK", 20)]     # 사전등록, 변경 불가
DROP = "439"


def keep_mask(group):
    """group: 종목별 그룹 라벨('439'|'A'|'B'). 반환 keep(True=A+B)."""
    g = np.asarray(group, dtype=object)
    assert set(g.tolist()) <= {"439", "A", "B"}, f"알 수 없는 그룹 라벨: {sorted(set(g.tolist()) - {'439', 'A', 'B'})}"
    keep = g != DROP
    assert keep.any() and (~keep).any(), "그룹 439와 A+B가 모두 존재해야 함"
    return keep


def mask_g1(prep, keep):
    """Gate 1 prep(h→{dates,block,T1,T2,T1_L1,F}) → F={RISK}만, 그룹 439 열 NaN. Target 배열은 그대로(동일 객체). 입력 불변."""
    out = {}
    for h, P in prep.items():
        F = P["F"][FEATURE]
        assert F.shape[1] == len(keep), f"종목 수 불일치 h={h}: {F.shape[1]} vs {len(keep)}"
        out[h] = {k: P[k] for k in ("dates", "block", "T1", "T2", "T1_L1")}
        out[h]["F"] = {FEATURE: np.where(keep[None, :], F, np.nan)}
    return out


def mask_g2(prep, keep):
    """Gate 2 prep({O,Clf,h→{...,F}}) → F={RISK}만, 그룹 439 열 NaN. 나머지 배열은 그대로(동일 객체). 입력 불변."""
    out = {"O": prep["O"], "Clf": prep["Clf"], "h": {}}
    for h, P in prep["h"].items():
        F = P["F"][FEATURE]
        assert F.shape[1] == len(keep), f"종목 수 불일치 h={h}: {F.shape[1]} vs {len(keep)}"
        Q = {k: v for k, v in P.items() if k != "F"}
        Q["F"] = {FEATURE: np.where(keep[None, :], F, np.nan)}
        out["h"][h] = Q
    return out


def check_unfiltered_g1(prep, gate1_csv):
    """선행 조건 1: 제외 전 prep의 RISK IC 평균(T1)이 D5 gate1_results.csv와 일치(atol 1e-12)."""
    ref = pd.read_csv(gate1_csv, encoding="utf-8-sig")
    ref = ref[(ref["feature"] == FEATURE) & (ref["target"] == "T1")].set_index("h")
    for h in HS:
        r1 = R.observed(prep[h], FEATURE)[0]
        assert abs(r1["ic_mean"] - ref.loc[h, "ic_mean"]) <= 1e-12, f"원본 RISK IC 불일치 h={h}: {r1['ic_mean']} vs {ref.loc[h, 'ic_mean']}"


def check_unfiltered_g2(prep, ref_csv):
    """선행 조건 2: 제외 전 prep으로 RISK 후보 3개를 평가한 결정적 열(REPL_COLS)이 gate2_results.csv와 일치(rtol 1e-9·atol 1e-12)."""
    ref = pd.read_csv(ref_csv, encoding="utf-8-sig")
    want = set(CANDS3)
    ref3 = ref[[(r.feature, int(r.h)) in want for r in ref.itertuples()]]
    assert len(ref3) == len(CANDS3), f"gate2_results.csv에 RISK 후보 3개가 모두 있어야 함: {len(ref3)}"
    new = N.eval_df(prep, CANDS3, N.null_dummy)
    bad = N.check_replication(new, ref3)
    assert not bad, f"제외 전 Gate 2 재현 실패 -> TL-011 중단: {bad[:12]}"
    return len(ref3)


def pool_diag(prep_g2, keep, group):
    """제외 전 RISK 유효 종목 수(일평균): 전체·그룹 439·A·B (성과 무관 진단)."""
    g = np.asarray(group, dtype=object)
    rows = []
    for h in HS:
        F = prep_g2["h"][h]["F"][FEATURE]
        ok = np.isfinite(F)
        rows.append({"h": h, "신호일": F.shape[0], "일평균 RISK 유효(전체)": float(ok.sum(1).mean()),
                     "그룹 439": float(ok[:, g == "439"].sum(1).mean()), "그룹 A": float(ok[:, g == "A"].sum(1).mean()),
                     "그룹 B": float(ok[:, g == "B"].sum(1).mean()), "A+B 비율": float(ok[:, keep].sum(1).mean() / ok.sum(1).mean())})
    return pd.DataFrame(rows)


def decide(g1_df, g2_df):
    """사전등록 종료 규칙 적용. 반환 (h별 표, 판정 문자열). 판정불가(Gate 1 또는 Gate 2)가 있으면 해당 h는 '판정불가'로 표시하고 생존으로 세지 않는다."""
    rows = []
    for h in HS:
        a = g1_df[(g1_df["feature"] == FEATURE) & (g1_df["h"] == h)]
        r = g2_df[(g2_df["feature"] == FEATURE) & (g2_df["h"] == h)].iloc[0]
        unj = bool(a["판정불가"].any()) or bool(r["판정불가"])
        g1 = bool(a["s3_quant"].any())
        e = float(r["평균E_gross(트랜치,h일)"])
        g2a = bool(r["s1_초과BH"]) and np.isfinite(e) and e > 0
        rows.append({"h": h, "Gate1통과(어느 Target이든)": g1, "Gate2①(초과E BH)": bool(r["s1_초과BH"]), "평균E>0": bool(np.isfinite(e) and e > 0),
                     "생존": (g1 and g2a and not unj), "판정불가": unj, "Gate2 ②블록": bool(r["s2_블록"]), "Gate2 ③절대순수익>0": bool(r["s3_절대순수익>0"]),
                     "Gate2 최종": r["판정"]})
    d = pd.DataFrame(rows)
    surv = d.loc[d["생존"], "h"].tolist()
    if d["판정불가"].any():
        verdict = "판정불가 포함 — 결과 해석 전 원인 확인(종료·생존 판정 보류)"
    elif surv:
        verdict = f"생존 h={surv}: 439 의존 반증 실패(A+B에서도 RISK 신호 유지). 자동 진행 없음 — 별도 승인·2023~24 확인 필수"
    else:
        verdict = "생존 h 없음: RISK 계열 종료(재시도·기준 완화 금지)"
    return d, verdict


def compare_full(g1_df, g2_df, gate1_csv, gate2_csv):
    """정보용(판정 불변): A+B vs 전 유니버스(D5 gate1_results.csv T1 행·gate2_results.csv)."""
    r1 = pd.read_csv(gate1_csv, encoding="utf-8-sig"); r1 = r1[(r1["feature"] == FEATURE) & (r1["target"] == "T1")].set_index("h")
    r2 = pd.read_csv(gate2_csv, encoding="utf-8-sig"); r2 = r2[r2["feature"] == FEATURE].set_index("h")
    a1 = g1_df[(g1_df["feature"] == FEATURE) & (g1_df["target"] == "T1")].set_index("h")
    b2 = g2_df.set_index("h")
    rows = []
    for h in HS:
        rows.append({"h": h, "IC(A+B)": float(a1.loc[h, "ic_mean"]), "IC(전체,D5)": float(r1.loc[h, "ic_mean"]),
                     "평균E(A+B)": float(b2.loc[h, "평균E_gross(트랜치,h일)"]), "평균E(전체)": float(r2.loc[h, "평균E_gross(트랜치,h일)"]),
                     "초과연환산(A+B)": float(b2.loc[h, "초과연환산(=E×252/h)"]), "초과연환산(전체)": float(r2.loc[h, "초과연환산(=E×252/h)"]),
                     "Q5절대순수익(A+B)": float(b2.loc[h, "Q5절대순수익(트랜치,h일)"]), "Q5절대순수익(전체)": float(r2.loc[h, "Q5절대순수익(트랜치,h일)"])})
    return pd.DataFrame(rows)


def run_tl011(prep1, prep2, out_dir, gate1_csv, gate2_csv, px_by_h, group, log=print):
    """①선행조건 2종(제외 전 재현) ②제외·진단 ③Gate 1(D5와 동일, family=RISK 9개) ④Gate 2(RISK 3후보) ⑤사후 진단 ⑥종료 규칙 적용."""
    R.check_prereg(); G2.check_prereg(G2.PREREG2)          # 사전등록 상수 변경 시 Gate 1(장시간) 시작 전에 중단
    for h, P in prep2["h"].items():
        d = pd.DatetimeIndex(P["dates"])
        assert d.min() >= C.SIGNAL_START and d.max() <= C.SIGNAL_END, f"설계구간 밖 신호일 h={h}"
    keep = keep_mask(group)
    check_unfiltered_g1(prep1, gate1_csv)
    log("제외 전 RISK IC가 D5 gate1_results.csv와 일치 OK")
    n = check_unfiltered_g2(prep2, gate2_csv)
    log(f"제외 전 RISK Gate 2 경로가 gate2_results.csv와 일치 OK (후보 {n}개)")
    pdg = pool_diag(prep2, keep, group)
    p1, p2 = mask_g1(prep1, keep), mask_g2(prep2, keep)
    assert all(not np.isfinite(P["F"][FEATURE][:, ~keep]).any() for P in p1.values()), "Gate 1: 그룹 439 열에 유한 Feature 잔존"
    assert all(not np.isfinite(P["F"][FEATURE][:, ~keep]).any() for P in p2["h"].values()), "Gate 2: 그룹 439 열에 유한 Feature 잔존"
    os.makedirs(out_dir, exist_ok=True)
    res1, meta1 = R.run_gate1(p1, os.path.join(out_dir, "g1"), log=log)
    with N.patched(G2, "CANDS", CANDS3):
        df2, meta2 = G2.run_gate2(p2, os.path.join(out_dir, "g2"), None, log=log)
    dres = DG.run_diag(p2, px_by_h, group, cands=CANDS3, log=log)
    DG.save_report(dres, os.path.join(out_dir, "g2", "diag"))
    dec, verdict = decide(res1["df"], df2)
    cmp_ = compare_full(res1["df"], df2, gate1_csv, gate2_csv)
    pdg.to_csv(os.path.join(out_dir, "tl011_pool_diag.csv"), index=False, encoding="utf-8-sig")
    dec.to_csv(os.path.join(out_dir, "tl011_decision.csv"), index=False, encoding="utf-8-sig")
    cmp_.to_csv(os.path.join(out_dir, "tl011_vs_full.csv"), index=False, encoding="utf-8-sig")
    return {"res1": res1, "meta1": meta1, "df2": df2, "meta2": meta2, "dres": dres, "dec": dec, "verdict": verdict, "cmp": cmp_, "pool": pdg}


def print_report(o, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 60)
    out("=== 제외 전 RISK 유효 종목 구성(일평균, 성과 무관) ==="); out(o["pool"].round(3).to_string(index=False))
    df = o["res1"]["df"]
    out("\\n=== [Gate 1] RISK, 그룹 439 제외 (독립 IC 검정 3개, T1·T3 동일) ===")
    a = df[df["target"] == "T1"][["feature", "h", "ic_mean", "ic_t", "p_ic", "bh_q", "s1_IC", "agree", "agree_thr", "s2_agree"]]
    out(a.round(4).to_string(index=False))
    out("\\n=== 분위 단계 (stage2 통과분) ===")
    b = df[df["s2_agree"]][["feature", "h", "target", "spread", "spread_thr", "mono", "mono_thr", "s3_quant", "판정"]]
    out(b.round(4).to_string(index=False) if len(b) else "stage2 통과 없음")
    m = o["meta1"]
    out(f"Gate 1 요약: trial {m['trials']} | family {m['families']} | 판정불가 {m['n_판정불가']} | stage1 {m['stage1_IC_BH']}/9 → stage2 {m['stage2_agree']}/9 → stage3 {m['stage3_quantile']}/9")
    out("\\n=== [Gate 2] RISK, 그룹 439 제외 (풀=A+B ∧ RISK 유효) ===")
    G2.print_report(o["df2"], o["meta2"], out)
    out("\\n=== [사전등록 종료 규칙 적용] ==="); out(o["dec"].to_string(index=False)); out("판정: " + o["verdict"])
    out("\\n=== 병기: A+B vs 전 유니버스 (정보용, 판정 불변; 풀 정의가 다름) ==="); out(o["cmp"].round(4).T.to_string(header=False))
    out("\\n===== 연도별 E (A+B) =====")
    for (k, h), r in o["dres"].items():
        out(f"\\n[{k} h={h}]"); out(r["year"].round(4).to_string(index=False))
    out("\\n(구성·집중도·3분위는 Drive g2/diag/*.csv)")
