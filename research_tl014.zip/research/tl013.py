"""TL-013: RISK h20, 그룹 439 제외(A+B) 유니버스의 Q5 롱 + 지수 베타 헤지(설계구간 2018~22만). 실데이터 실행은 Colab 전용.
TL-006과 같은 코드·규칙(g2_hedge 재사용): β=직전 120거래일 OLS(KOSPI200·KOSDAQ 동시)·20거래일 갱신, 판정 ①헤지후 일평균>0 ②헤지후 MDD 절대값<비헤지 ③2018-19·2020-22 각각 일평균>0.
비헤지 Q5 경로는 비용 0.206%(트랜치마다 전액)를 이미 반영한다. 헤지 비용(베이시스·롤·증거금·지수 비거래 수단)은 미반영이며 헤지거래금액 대비 break-even bp로 보조 보고한다.
이 모듈은 features/targets를 import하지 않는다."""
import os
import numpy as np
import pandas as pd
from . import config as C
from . import near_run as N
from . import g2_hedge as H
from . import g2_hedge_near as X
from . import tl011 as Z
from . import tl012 as Y

CANDS = [("RISK", 20)]      # 사전등록, 변경 불가(h10은 왕복 비용 부담이 약 2배라 사전 제외)


def build_design(paths, window=None, label=""):
    """설계구간 prep + 종목 그룹 + 마스터 캘린더. 반환 (prep, group, cal, info)."""
    from .run_d3d4 import run
    from .gate2_prep import prepare_g2, dollar_volume_20
    window = N.DESIGN if window is None else window
    with N.period(*window):
        D, U, parts, F, labels = run(*paths, verbose=False)
        assert D["calendar"].max() <= window[1], "데이터 상한 초과 적재"
        DV = dollar_volume_20(D["close"], D["volume"], D["outlier"])
        prep = prepare_g2(D, U, F, labels, DV, list(N.HORIZONS))
        cal = pd.DatetimeIndex(D["open"].index)
        assert cal.equals(pd.DatetimeIndex(D["calendar"])) and prep["O"].shape[0] == len(cal), "캘린더·패널 불일치"
        group = D["meta"]["group"].reindex(D["close"].columns).values
        assert len(group) == prep["O"].shape[1] and all(isinstance(g, str) for g in group), "그룹 라벨 누락·형상 불일치"
        info = {"label": label, "calendar": f"{cal.min().date()}~{cal.max().date()}",
                "신호일": {h: len(prep["h"][h]["dates"]) for h in N.HORIZONS},
                "그룹별 종목 수": pd.Series(group).value_counts().to_dict()}
    return prep, group, cal, info


def decide(df):
    r = df.iloc[0]
    if bool(r["통과"]):
        return "통과: 지수 베타 헤지 후에도 설계구간에서 ①②③ 충족(확증 아님, 별도 승인·독립 구간 계획 필요)"
    fails = [n for n, k in (("①일평균>0", "조건1_일평균>0"), ("②MDD감소", "조건2_MDD감소"), ("③두구간양", "조건3_두구간양")) if not bool(r[k])]
    return "실패(" + ", ".join(fails) + "): RISK 계열 완전 종료(재시도·기준 완화 금지)"


def run_tl013(prep, group, cal, pit_dir, ref_g2_csv, ref_tl011_csv, out_dir, log=print):
    """①설계구간 전 유니버스 11후보 재현 ②설계구간 A+B 재현(TL-011) ③헤지 평가(g2_hedge.run_hedge, Q5 CAGR·Sharpe·MDD가 TL-011 결과와 일치해야 함)
    ④보조 진단: A+B 풀(동일가중) 경로 동일 헤지(판정 불변)."""
    assert len(cal) == prep["O"].shape[0], f"캘린더 길이 불일치: {len(cal)} vs {prep['O'].shape[0]}"
    for h, P in prep["h"].items():
        d = pd.DatetimeIndex(P["dates"])
        assert d.min() >= C.SIGNAL_START and d.max() <= C.SIGNAL_END, f"설계구간 밖 신호일 h={h}"
    N.replicate_design(prep, ref_g2_csv)
    log("설계구간 전 유니버스 11후보 경로가 gate2_results.csv와 일치 OK")
    keep = Z.keep_mask(group)
    md = Z.mask_g2(prep, keep)
    Y.check_design_vs_tl011(md, ref_tl011_csv)
    log("설계구간 A+B(439 제외) RISK 경로가 TL-011 결과와 일치 OK")
    ridx = H.load_idx_returns(pit_dir, cal)
    years = np.asarray(cal.year)
    df = H.run_hedge(md, ridx, years, ref_tl011_csv, cands=CANDS, log=log)
    rq, rp, a, b = X.q5_paths(md, "RISK", 20)
    pool = H.hedge_eval(rp, ridx, a, b, years)
    ctrl = {"풀_비헤지_일평균": pool["비헤지_일평균"], "풀_헤지후_일평균": pool["헤지후_일평균"], "풀_비헤지_Sharpe": pool["비헤지_Sharpe"],
            "풀_헤지후_Sharpe": pool["헤지후_Sharpe"], "풀_비헤지_MDD": pool["비헤지_MDD"], "풀_헤지후_MDD": pool["헤지후_MDD"],
            "풀_평균β_KOSPI200": pool["평균β_KOSPI200"], "풀_평균β_KOSDAQ": pool["평균β_KOSDAQ"]}
    ctrl["Q5-풀 일평균(헤지후, 비헤지)"] = (float(df.iloc[0]["헤지후_일평균"] - pool["헤지후_일평균"]), float(df.iloc[0]["비헤지_일평균"] - pool["비헤지_일평균"]))
    os.makedirs(out_dir, exist_ok=True)
    o = df.copy(); o["연도별(헤지후,비헤지)"] = o["연도별(헤지후,비헤지)"].astype(str)
    o.to_csv(os.path.join(out_dir, "tl013_hedge_results.csv"), index=False, encoding="utf-8-sig")
    pd.DataFrame([{k: (str(v) if isinstance(v, tuple) else v) for k, v in ctrl.items()}]).to_csv(os.path.join(out_dir, "tl013_pool_control.csv"), index=False, encoding="utf-8-sig")
    return {"df": df, "ctrl": ctrl, "verdict": decide(df)}


def print_report(o, out=print):
    H.print_report(o["df"], out)
    c = o["ctrl"]
    out("\\n=== 보조 진단(판정 불변): A+B 풀 동일가중 경로에 같은 헤지 적용 ===")
    out(f"  풀 일평균 비헤지 {c['풀_비헤지_일평균']:.6f} → 헤지후 {c['풀_헤지후_일평균']:.6f} | Sharpe {c['풀_비헤지_Sharpe']:.3f} → {c['풀_헤지후_Sharpe']:.3f} | MDD {c['풀_비헤지_MDD']:.4f} → {c['풀_헤지후_MDD']:.4f}")
    out(f"  풀 평균β KOSPI200 {c['풀_평균β_KOSPI200']:.3f} KOSDAQ {c['풀_평균β_KOSDAQ']:.3f}")
    out(f"  Q5 − 풀 일평균: 헤지후 {c['Q5-풀 일평균(헤지후, 비헤지)'][0]:.6f} | 비헤지 {c['Q5-풀 일평균(헤지후, 비헤지)'][1]:.6f}")
    out("\\n판정: " + o["verdict"])
