"""TL-010: Gate 2(비용 포함 롱온리 Q5 트랜치) — TL-009 상위 1/3(거래대금 20일평균) 유니버스, 후보 6개. 실데이터 실행은 Colab 전용.
필터(tl009.top_tercile_mask)는 거래대금만 사용하고 Feature·Target 값을 쓰지 않는다. 필터 후 Feature(상위 1/3 외 NaN)를 gate2 선택 규칙에 그대로 넣으면
풀 = 상위 1/3 ∧ Feature 유효, Q5 = 풀 내 방향 정렬 상위 20%가 된다(선택은 라벨을 쓰지 않음). 판정·null·비용·경로는 gate2_run을 그대로 재사용한다.
이 모듈은 features/targets를 import하지 않는다."""
import os
import numpy as np
import pandas as pd
from . import config as C
from . import gate2_run as G2
from . import near_run as N
from . import tl009 as X
from . import g2_diag as DG

# 사전등록 후보(TL-009 Gate 1 통과 12 trial → (Feature,h) 6개; T1·T2·T3는 Q5 포트폴리오가 같아 하나로 본다), 변경 불가
CANDS6 = [("REV", 5), ("REV", 10), ("RISK", 5), ("RISK", 10), ("RISK", 20), ("ATTN", 5)]
FEATS = X.FEATS
CMP_COLS = ["평균E_gross(트랜치,h일)", "초과연환산(=E×252/h)", "Q5절대순수익(트랜치,h일)", "break_even_절대_bp", "Q5_CAGR", "Q5_Sharpe", "Q5_MDD"]


def build_hi_prep_g2(prep, DVu):
    """prep: gate2_prep.prepare_g2 결과. DVu: 캘린더×종목(유니버스 밖·이상치 NaN, 열은 prep과 같은 순서).
    반환 (prep_hi, diags): h별 F={REV,RISK,ATTN}(상위 1/3 외 NaN), 나머지(T1·status·DV·tpos 등)와 O·Clf는 그대로. 입력 prep은 변경하지 않는다."""
    out = {"O": prep["O"], "Clf": prep["Clf"], "h": {}}
    diags = {}
    for h, P in prep["h"].items():
        idx = P["dates"]
        dv = DVu.loc[idx].values
        shp = next(iter(P["F"].values())).shape
        assert dv.shape == shp, f"거래대금 형상 불일치 h={h}: {dv.shape} vs {shp}"
        mask, diag = X.top_tercile_mask(dv)
        diag.index = idx
        Q = {k: v for k, v in P.items() if k != "F"}
        Q["F"] = {k: np.where(mask, P["F"][k], np.nan) for k in FEATS}
        out["h"][h] = Q
        diags[h] = diag
    return out, diags


def check_unfiltered(prep, ref_csv):
    """선행 조건: 필터를 끈 prep으로 후보 6개를 평가한 결정적 열(REPL_COLS)이 gate2_results.csv와 일치해야 한다(rtol 1e-9·atol 1e-12). 불일치 시 중단."""
    ref = pd.read_csv(ref_csv, encoding="utf-8-sig")
    want = set(CANDS6)
    ref6 = ref[[(r.feature, int(r.h)) in want for r in ref.itertuples()]]
    assert len(ref6) == len(CANDS6), f"gate2_results.csv에 후보 6개가 모두 있어야 함: {len(ref6)}"
    new = N.eval_df(prep, CANDS6, N.null_dummy)
    bad = N.check_replication(new, ref6)
    assert not bad, f"필터 전 Gate 2 재현 실패 -> TL-010 중단: {bad[:12]}"
    return len(ref6)


def compare_with_unfiltered(df, ref_csv):
    """정보용(판정 불변): 상위 1/3 결과 vs 전 유니버스 Gate 2(gate2_results.csv). 풀 정의가 달라 직접 비교에는 한계가 있다."""
    ref = pd.read_csv(ref_csv, encoding="utf-8-sig").set_index(["feature", "h"])
    rows = []
    for r in df.itertuples():
        row = {"feature": r.feature, "h": r.h}
        for c in CMP_COLS:
            row[f"{c}|상위1/3"] = float(getattr(df.loc[r.Index], c))
            row[f"{c}|전유니버스"] = float(ref.loc[(r.feature, r.h), c])
        rows.append(row)
    return pd.DataFrame(rows)


def run_tl010(prep, DVu, out_dir, ref_csv, px_by_h, group, log=print):
    """①설계구간 신호일 확인 ②필터 전 재현(선행조건) ③상위 1/3 필터 진단(마스크만) ④Gate 2(gate2_run 재사용, 후보 6개, family=Feature)
    ⑤사후 진단(g2_diag: Q5 구성·상위 종목 제외·연도별 E·상위 1/3 내부 3분위; 판정 불변)."""
    for h, P in prep["h"].items():
        d = pd.DatetimeIndex(P["dates"])
        assert d.min() >= C.SIGNAL_START and d.max() <= C.SIGNAL_END, f"설계구간 밖 신호일 h={h}"
    n = check_unfiltered(prep, ref_csv)
    log(f"필터 전 경로가 gate2_results.csv와 일치 OK (후보 {n}개, 결정적 열 REPL_COLS)")
    prep_hi, diags = build_hi_prep_g2(prep, DVu)
    fdf = X.summarize_filter(diags)
    with N.patched(G2, "CANDS", CANDS6):
        df, meta = G2.run_gate2(prep_hi, out_dir, None, log=log)
    dres = DG.run_diag(prep_hi, px_by_h, group, cands=CANDS6, log=log)
    DG.save_report(dres, os.path.join(out_dir, "diag"))
    cmp_ = compare_with_unfiltered(df, ref_csv)
    cmp_.to_csv(os.path.join(out_dir, "tl010_vs_unfiltered.csv"), index=False, encoding="utf-8-sig")
    fdf.to_csv(os.path.join(out_dir, "tl010_filter_diag.csv"), index=False, encoding="utf-8-sig")
    return df, meta, fdf, dres, cmp_


def print_report(df, meta, fdf, cmp_, dres, out=print):
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 60)
    out("=== 필터 구성 진단(성과 무관) ==="); out(fdf.round(4).to_string(index=False))
    G2.print_report(df, meta, out)
    out("\\n=== 병기: 상위 1/3 vs 전 유니버스 Gate 2 (정보용, 판정 불변; 풀 정의가 다름) ===")
    out(cmp_.round(4).T.to_string(header=False))
    for tag, title in (("comp", "Q5 구성 vs 풀(풀=상위 1/3, 분위=상위 1/3 내부 3분위)"), ("conc", "기여 집중도·절단 민감도(사후 스트레스, 판정 불변)"),
                       ("year", "연도별 E")):
        out(f"\\n===== {title} =====")
        for (k, h), r in dres.items():
            out(f"\\n[{k} h={h}]"); out(r[tag].round(4).to_string(index=False))
            if tag == "conc":
                out({a: (round(b, 4) if isinstance(b, float) else b) for a, b in r["conc_meta"].items()})
    out("\\n(상위 1/3 내부 3분위별 Q5 절대 순수익은 Drive diag/g2_diag_terc.csv)")
