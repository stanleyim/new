"""D3/D4 고정 상수 (승인된 확정안). 결과를 보고 바꾸지 않는다."""
import pandas as pd

INPUT_START = pd.Timestamp("2017-01-02")   # 가격·거래량 Feature 계산 입력 전용 시작
SIGNAL_START = pd.Timestamp("2018-01-02")  # 설계구간 신호일 시작
SIGNAL_END = pd.Timestamp("2022-12-30")    # 데이터 상한: 이후 행은 로드 단계에서 폐기
HORIZONS = (5, 10, 20)
UNIV_WINDOW = 20        # T 포함 직전 20거래일
UNIV_MIN_VALID = 15     # 그중 유효거래일 15일 이상
MIN_VALID_FRAC = 0.8    # 윈도우 통계 Feature: 유효 관측 비율 하한 (구현 세부, 전 Feature 동일, 튜닝 금지)

# 원인 미확정 이상치 4행: 해당 종목의 Feature 룩백/라벨 윈도우를 NaN 처리
OUTLIER_ROWS = {
    "124500": ["2014-12-22", "2014-12-23"],
    "232680": ["2021-06-17"],
    "033790": ["2023-03-30"],
}

# 가설 방향(+1: 값이 클수록 상승 기대). Gate 1 검정에서 사용, 여기서는 기록만.
FEATURE_DIRECTION = {"REV": -1, "MOM": +1, "RISK": -1, "ATTN": -1, "LIQ": +1, "ANCH": +1}
# 이상치 마스킹용 룩백 길이(해당 종목 윈도우에 이상치 행 포함 시 NaN)
FEATURE_SPAN = {"REV": 6, "MOM": 61, "RISK": 61, "ATTN": 60, "LIQ": 21, "ANCH": 120}
